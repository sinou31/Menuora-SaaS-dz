import { useEffect, useRef } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Order } from '../types/database.types';
import { useToast } from './useToast';

interface RealtimeOrdersOptions {
  restaurantId: string | undefined;
  onNewOrder?: (order: Order) => void;
  onOrderUpdated?: (order: Order) => void;
  /** Show a toast when a new order arrives (default: true). */
  notify?: boolean;
}

export function useRealtimeOrders({
  restaurantId,
  onNewOrder,
  onOrderUpdated,
  notify = true
}: RealtimeOrdersOptions) {
  const { toast } = useToast();

  // Keep the latest callbacks in refs so inline callbacks passed by the caller
  // do not tear down and re-create the realtime channel on every render.
  const onNewOrderRef = useRef(onNewOrder);
  const onOrderUpdatedRef = useRef(onOrderUpdated);
  const notifyRef = useRef(notify);
  const toastRef = useRef(toast);

  useEffect(() => {
    onNewOrderRef.current = onNewOrder;
    onOrderUpdatedRef.current = onOrderUpdated;
    notifyRef.current = notify;
    toastRef.current = toast;
  });

  useEffect(() => {
    if (!isSupabaseConfigured || !restaurantId) return;

    // Unique topic per subscriber so several components can listen at once.
    const topic = `restaurant-orders-${restaurantId}-${Math.random().toString(36).slice(2, 8)}`;

    const channel = supabase
      .channel(topic)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'orders',
          filter: `restaurant_id=eq.${restaurantId}`
        },
        (payload) => {
          const newOrder = payload.new as Order;
          if (notifyRef.current) {
            toastRef.current('وصل طلب جديد للمطعم!', 'info');
          }
          onNewOrderRef.current?.(newOrder);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `restaurant_id=eq.${restaurantId}`
        },
        (payload) => {
          onOrderUpdatedRef.current?.(payload.new as Order);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [restaurantId]);
}
