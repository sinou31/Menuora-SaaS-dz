
import React, { useState } from 'react';
import {
  Mail,
  Lock,
  LogIn,
  Plus,
  Eye,
  EyeOff,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { isValidEmail } from '../../utils/validators';
import { useToast } from '../../hooks/useToast';

interface LoginPageProps {
  onNavigateRegister: () => void;
  onNavigateForgotPassword: () => void;
  onSuccessLogin: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onNavigateRegister,
  onNavigateForgotPassword,
  onSuccessLogin,
}) => {
  const { signIn } = useAuth();
  const { error: toastError, success: toastSuccess } = useToast();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const normalizedEmail = email.trim();

    if (!isValidEmail(normalizedEmail)) {
      toastError('يرجى إدخال بريد إلكتروني صحيح');
      return;
    }

    if (!password) {
      toastError('يرجى إدخال كلمة المرور');
      return;
    }

    setLoading(true);

    try {
      const { error } = await signIn(normalizedEmail, password);

      if (error) {
        const message = error.message ?? '';

        if (message.includes('Invalid login credentials')) {
          toastError('البريد الإلكتروني أو كلمة المرور غير صحيحة');
        } else if (message.includes('Email not confirmed')) {
          toastError(
            'يرجى تأكيد بريدك الإلكتروني أولاً عبر الرابط المرسل إلى صندوق الوارد',
          );
        } else {
          toastError(message || 'تعذر تسجيل الدخول، يرجى المحاولة مجددًا');
        }

        return;
      }

      toastSuccess('تم تسجيل الدخول بنجاح');
      onSuccessLogin();
    } catch (err: unknown) {
      toastError(
        err instanceof Error
          ? err.message
          : 'حدث خطأ أثناء تسجيل الدخول',
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <main
      dir="rtl"
      className="relative isolate flex min-h-screen items-center justify-center overflow-hidden bg-[#e8ebf0] px-4 py-10 text-[#343a46]"
      style={{
        fontFamily: 'Tajawal, Cairo, sans-serif',
        backgroundImage:
          'radial-gradient(circle at 50% 45%, #f4f5f8 0%, #e8ebf0 65%, #e2e6ed 100%)',
      }}
    >
      {/* Decorative background circles */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-12 top-16 -z-10 h-40 w-40 rounded-full sm:right-[8%] sm:top-[12%] sm:h-48 sm:w-48"
        style={{
          background: 'linear-gradient(145deg, #f5f7fa, #dfe3ea)',
          boxShadow: '12px 12px 28px #cbd0d9, -12px -12px 28px #ffffff',
        }}
      />

      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-10 bottom-16 -z-10 h-28 w-28 rounded-full sm:bottom-[12%] sm:left-[10%] sm:h-36 sm:w-36"
        style={{
          background: 'linear-gradient(145deg, #f5f7fa, #dfe3ea)',
          boxShadow: '10px 10px 24px #cbd0d9, -10px -10px 24px #ffffff',
        }}
      />

      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-[12%] top-[38%] -z-10 h-10 w-10 rounded-full sm:right-[22%] sm:h-14 sm:w-14"
        style={{
          background: '#e8ebf0',
          boxShadow: '6px 6px 14px #cbd0d9, -6px -6px 14px #ffffff',
        }}
      />

      {/* Login card */}
      <section
        className="relative w-full max-w-[410px] rounded-[32px] p-6 sm:p-9"
        style={{
          background: 'linear-gradient(145deg, #eef0f5, #e4e7ed)',
          boxShadow: '14px 14px 32px #cbd0d9, -14px -14px 32px #ffffff',
        }}
      >
        {/* Brand */}
        <div className="mb-7 text-center">
          <div
            className="mx-auto mb-4 flex h-[76px] w-[76px] items-center justify-center rounded-full"
            style={{
              background: 'linear-gradient(145deg, #eef1f6, #e1e5ec)',
              boxShadow: '7px 7px 16px #cbd0d9, -7px -7px 16px #ffffff',
            }}
          >
            <div
              className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#e8edf7] text-[#2878d0]"
              style={{
                boxShadow:
                  'inset 3px 3px 6px #d0d7e2, inset -3px -3px 6px #ffffff',
              }}
            >
              <Lock size={24} strokeWidth={2.5} />
            </div>
          </div>

          <p className="mb-1 text-[11px] font-extrabold tracking-[0.28em] text-[#3476b9]">
            MENUORA
          </p>

          <h1 className="text-2xl font-extrabold tracking-tight text-[#343a46] sm:text-[27px]">
            مرحبًا بعودتك
          </h1>

          <p className="mt-2 text-sm leading-6 text-[#858b98]">
            سجّل الدخول لمتابعة إدارة مطعمك
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Email */}
          <div>
            <label
              htmlFor="login-email"
              className="mb-2 block text-xs font-semibold text-[#737b89]"
            >
              البريد الإلكتروني
            </label>

            <div
              className="flex min-h-[54px] items-center gap-3 rounded-2xl px-4 transition-all duration-200 focus-within:ring-2 focus-within:ring-[#6ba8e5]/50"
              style={{
                background: '#e9ecf2',
                boxShadow:
                  'inset 5px 5px 10px #d1d5de, inset -5px -5px 10px #ffffff',
              }}
            >
              <Mail size={18} className="shrink-0 text-[#8d96a5]" />

              <input
                id="login-email"
                type="email"
                name="email"
                autoComplete="email"
                required
                placeholder="name@restaurant.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="min-w-0 flex-1 border-0 bg-transparent py-3 text-sm text-[#343a46] outline-none placeholder:text-[#a0a6b1]"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label
              htmlFor="login-password"
              className="mb-2 block text-xs font-semibold text-[#737b89]"
            >
              كلمة المرور
            </label>

            <div
              className="flex min-h-[54px] items-center gap-3 rounded-2xl px-4 transition-all duration-200 focus-within:ring-2 focus-within:ring-[#6ba8e5]/50"
              style={{
                background: '#e9ecf2',
                boxShadow:
                  'inset 5px 5px 10px #d1d5de, inset -5px -5px 10px #ffffff',
              }}
            >
              <Lock size={18} className="shrink-0 text-[#8d96a5]" />

              <input
                id="login-password"
                type={showPassword ? 'text' : 'password'}
                name="password"
                autoComplete="current-password"
                required
                placeholder="أدخل كلمة المرور"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="min-w-0 flex-1 border-0 bg-transparent py-3 text-sm text-[#343a46] outline-none placeholder:text-[#a0a6b1]"
              />

              <button
                type="button"
                onClick={() => setShowPassword((current) => !current)}
                aria-label={
                  showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'
                }
                aria-pressed={showPassword}
                className="shrink-0 rounded-lg p-1 text-[#8d96a5] transition hover:text-[#2878d0] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#6ba8e5]"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {/* Forgot password */}
          <div className="flex justify-end px-1 pt-1 text-xs">
            <button
              type="button"
              onClick={onNavigateForgotPassword}
              className="font-semibold text-[#3476b9] transition hover:text-[#205d98] hover:underline"
            >
              نسيت كلمة المرور؟
            </button>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="flex min-h-[54px] w-full items-center justify-center gap-2 rounded-2xl px-4 text-sm font-extrabold text-[#3476b9] transition duration-200 hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-60"
            style={{
              background: 'linear-gradient(145deg, #eef1f6, #e1e5ec)',
              boxShadow: '6px 6px 13px #cbd0d9, -6px -6px 13px #ffffff',
            }}
          >
            {loading ? (
              <>
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-[#3476b9] border-t-transparent" />
                جارٍ تسجيل الدخول...
              </>
            ) : (
              <>
                <LogIn size={18} />
                تسجيل الدخول
              </>
            )}
          </button>
        </form>

        {/* Register */}
        <div className="mt-7 border-t border-[#d7dbe3] pt-6 text-center">
          <p className="mb-4 text-xs text-[#858b98]">
            ليس لديك حساب مطعم بعد؟
          </p>

          <button
            type="button"
            onClick={onNavigateRegister}
            className="mx-auto inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold text-[#3476b9] transition duration-200 hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#6ba8e5]"
            style={{
              background: 'linear-gradient(145deg, #eef1f6, #e1e5ec)',
              boxShadow: '5px 5px 10px #cbd0d9, -5px -5px 10px #ffffff',
            }}
          >
            <Plus size={18} />
            أنشئ حساب مطعمك
          </button>
        </div>

        {/* Trust indicator */}
        <div className="mt-6 flex items-center justify-center gap-2 text-[11px] text-[#969daa]">
          <ShieldCheck size={15} className="text-[#5795ce]" />
          <span>تسجيل دخول آمن عبر Menuora</span>
        </div>
      </section>

      <p className="absolute bottom-3 left-0 right-0 text-center text-[10px] text-[#a0a6b1]">
        © {new Date().getFullYear()} Menuora — جميع الحقوق محفوظة
      </p>
    </main>
  );
};
