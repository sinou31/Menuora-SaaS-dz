
import React, { useState, useEffect } from 'react';
import {
  MailCheck,
  RefreshCw,
  ArrowRight,
  ShieldCheck,
  Mail,
  CheckCircle2,
} from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useToast } from '../../hooks/useToast';
import { Button } from '../../components/Button';

interface VerifyEmailPageProps {
  email: string;
  onNavigateLogin: () => void;
}

export const VerifyEmailPage: React.FC<VerifyEmailPageProps> = ({
  email,
  onNavigateLogin,
}) => {
  const { success, error: toastError } = useToast();

  const [countdown, setCountdown] = useState(60);
  const [canResend, setCanResend] = useState(false);
  const [isResending, setIsResending] = useState(false);

  useEffect(() => {
    if (countdown <= 0) {
      setCanResend(true);
      return;
    }

    const timer = window.setTimeout(() => {
      setCountdown((current) => current - 1);
    }, 1000);

    return () => window.clearTimeout(timer);
  }, [countdown]);

  const handleResend = async () => {
    if (!canResend || isResending) return;

    if (!email.trim()) {
      toastError('لم يتم العثور على البريد الإلكتروني');
      return;
    }

    if (!isSupabaseConfigured) {
      toastError('خدمة المصادقة غير مهيأة حاليًا');
      return;
    }

    setIsResending(true);

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: email.trim(),
      });

      if (error) throw error;

      success('تمت إعادة إرسال رابط التفعيل بنجاح');
      setCountdown(60);
      setCanResend(false);
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : 'تعذر إعادة إرسال الرابط';

      toastError(message || 'تعذر إعادة إرسال الرابط');
    } finally {
      setIsResending(false);
    }
  };

  return (
    <div
      dir="rtl"
      className="flex min-h-screen items-center justify-center bg-[#E8EDF5] px-4 py-10 text-[#26334A]"
    >
      <div className="w-full max-w-md">
        {/* Brand */}
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[22px] bg-[#E8EDF5] text-[#4776D0] shadow-[8px_8px_18px_#c6cbd2,-8px_-8px_18px_#ffffff]">
            <ShieldCheck className="h-8 w-8" />
          </div>

          <h1 className="text-2xl font-black tracking-tight">Menuora</h1>
          <p className="mt-2 text-sm text-[#7C899E]">
            خطوة واحدة تفصلك عن حسابك
          </p>
        </div>

        {/* Main card */}
        <div className="rounded-[30px] border border-white/70 bg-[#E8EDF5] p-6 text-center shadow-[12px_12px_30px_#c6cbd2,-12px_-12px_30px_#ffffff] sm:p-9">
          <div className="relative mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-[26px] bg-[#E8EDF5] text-[#4776D0] shadow-[inset_5px_5px_10px_#c6cbd2,inset_-5px_-5px_10px_#ffffff]">
            <MailCheck className="h-9 w-9" />

            <span className="absolute -bottom-1 -left-1 flex h-7 w-7 items-center justify-center rounded-full border-2 border-[#E8EDF5] bg-emerald-500 text-white">
              <CheckCircle2 className="h-4 w-4" />
            </span>
          </div>

          <h2 className="text-xl font-extrabold sm:text-2xl">
            تأكيد البريد الإلكتروني
          </h2>

          <p className="mt-3 text-sm leading-7 text-[#7C899E]">
            أرسلنا رابط تفعيل إلى بريدك الإلكتروني. افتح الرسالة واضغط على
            الرابط لتأكيد حسابك والبدء في إدارة قائمة طعام مطعمك.
          </p>

          {/* Email display */}
          <div className="my-6 rounded-2xl bg-[#E8EDF5] p-4 shadow-[inset_4px_4px_8px_#c6cbd2,inset_-4px_-4px_8px_#ffffff]">
            <div className="mb-2 flex items-center justify-center gap-2 text-xs text-[#7C899E]">
              <Mail className="h-4 w-4" />
              <span>رابط التفعيل مرسل إلى</span>
            </div>

            <p
              className="break-all text-sm font-bold text-[#4776D0]"
              dir="ltr"
            >
              {email || 'بريدك الإلكتروني'}
            </p>
          </div>

          {/* Instructions */}
          <div className="mb-6 rounded-2xl border border-white/70 bg-white/30 p-4 text-right">
            <p className="mb-3 text-sm font-bold text-[#52627B]">
              ماذا عليك أن تفعل؟
            </p>

            <div className="space-y-3 text-xs leading-6 text-[#7C899E]">
              <div className="flex items-start gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-[#E8EDF5] font-bold text-[#4776D0] shadow-[3px_3px_6px_#c6cbd2,-3px_-3px_6px_#ffffff]">
                  1
                </span>
                <p>افتح صندوق الوارد في بريدك الإلكتروني.</p>
              </div>

              <div className="flex items-start gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-[#E8EDF5] font-bold text-[#4776D0] shadow-[3px_3px_6px_#c6cbd2,-3px_-3px_6px_#ffffff]">
                  2
                </span>
                <p>ابحث عن رسالة التفعيل من Menuora.</p>
              </div>

              <div className="flex items-start gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-[#E8EDF5] font-bold text-[#4776D0] shadow-[3px_3px_6px_#c6cbd2,-3px_-3px_6px_#ffffff]">
                  3
                </span>
                <p>اضغط على رابط التأكيد، وتحقق من مجلد الرسائل غير المرغوب فيها إن لم تجد الرسالة.</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button
              variant="secondary"
              className="w-full"
              disabled={!canResend || isResending}
              loading={isResending}
              onClick={handleResend}
              icon={<RefreshCw className="h-4 w-4" />}
            >
              {isResending
                ? 'جارٍ إرسال الرابط...'
                : canResend
                  ? 'إعادة إرسال رابط التفعيل'
                  : `إعادة الإرسال بعد ${countdown} ثانية`}
            </Button>

            {!canResend && (
              <p className="text-xs text-[#8B96A8]">
                يمكنك طلب رابط جديد عند انتهاء العد التنازلي.
              </p>
            )}

            <Button
              variant="ghost"
              className="w-full text-sm text-[#718099]"
              onClick={onNavigateLogin}
            >
              <ArrowRight className="ml-2 h-4 w-4" />
              العودة إلى تسجيل الدخول
            </Button>
          </div>
        </div>

        <p className="mt-6 text-center text-xs leading-6 text-[#8B96A8]">
          بريدك الإلكتروني يساعدنا على حماية حسابك وتأمين الوصول إليه.
        </p>
      </div>
    </div>
  );
};
