
import React, { useState } from 'react';
import {
  User,
  Mail,
  Phone,
  Lock,
  Store,
  MapPin,
  ArrowRight,
  ArrowLeft,
  Plus,
  Eye,
  EyeOff,
  ShieldCheck,
  Check,
  ClipboardCheck,
} from 'lucide-react';

import { useAuth } from '../../hooks/useAuth';
import {
  evaluatePasswordStrength,
  isValidEmail,
  isValidPhone,
} from '../../utils/validators';
import { useToast } from '../../hooks/useToast';

interface RegisterPageProps {
  onNavigateLogin: () => void;
  onNavigateVerifyEmail: (email: string) => void;
  onSuccessRegistered: () => void;
}

const neumorphicCard = {
  background: 'linear-gradient(145deg, #eef1f6, #e2e6ed)',
  boxShadow: '9px 9px 20px #cbd0d9, -9px -9px 20px #ffffff',
};

const neumorphicInput = {
  background: '#e9ecf2',
  boxShadow:
    'inset 4px 4px 8px #d1d5de, inset -4px -4px 8px #ffffff',
};

export const RegisterPage: React.FC<RegisterPageProps> = ({
  onNavigateLogin,
  onNavigateVerifyEmail,
  onSuccessRegistered,
}) => {
  const { signUp } = useAuth();
  const { error: toastError, success: toastSuccess } = useToast();

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    restaurantName: '',
    city: '',
    address: '',
    description: '',
  });

  const pwdStrength = evaluatePasswordStrength(formData.password);

  const updateField = (
    field: keyof typeof formData,
    value: string
  ) => {
    setFormData((previous) => ({
      ...previous,
      [field]: value,
    }));
  };

  const handleNextStep1 = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.fullName.trim()) {
      toastError('يرجى إدخال اسمك الكامل');
      return;
    }

    if (!isValidEmail(formData.email)) {
      toastError('يرجى إدخال بريد إلكتروني صالح');
      return;
    }

    if (formData.phone && !isValidPhone(formData.phone)) {
      toastError('يرجى إدخال رقم هاتف صحيح');
      return;
    }

    if (pwdStrength.score < 2) {
      toastError(
        'كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على أرقام وأحرف'
      );
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toastError('كلمتا المرور غير متطابقتين');
      return;
    }

    setStep(2);
  };

  const handleNextStep2 = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.restaurantName.trim()) {
      toastError('يرجى إدخال اسم المطعم أو المقهى');
      return;
    }

    setStep(3);
  };

  const handleFinalSubmit = async () => {
    if (loading) return;

    setLoading(true);

    try {
      const { error, needsEmailVerification } = await signUp({
        email: formData.email,
        password: formData.password,
        fullName: formData.fullName,
        phone: formData.phone,
        restaurantName: formData.restaurantName,
        city: formData.city,
        address: formData.address,
        description: formData.description,
      });

      if (error) {
        toastError(error.message || 'فشل التسجيل');
        return;
      }

      toastSuccess('تم تسجيل حساب المطعم بنجاح!');

      if (needsEmailVerification) {
        onNavigateVerifyEmail(formData.email);
      } else {
        onSuccessRegistered();
      }
    } catch (err: unknown) {
      toastError(
        err instanceof Error
          ? err.message
          : 'حدث خطأ غير متوقع'
      );
    } finally {
      setLoading(false);
    }
  };

  const steps = [
    { number: 1, label: 'الحساب', icon: User },
    { number: 2, label: 'المطعم', icon: Store },
    { number: 3, label: 'التأكيد', icon: ClipboardCheck },
  ];

  const fieldClass =
    'w-full min-w-0 border-0 bg-transparent py-3 text-sm text-[#343a46] outline-none placeholder:text-[#a0a6b1]';

  const labelClass =
    'mb-2 block text-xs font-semibold text-[#737b89]';

  const inputWrapperClass =
    'flex min-h-[52px] items-center gap-3 rounded-2xl px-4 transition-all duration-200 focus-within:ring-2 focus-within:ring-[#6ba8e5]/50';

  const primaryButtonClass =
    'flex min-h-[52px] items-center justify-center gap-2 rounded-2xl px-4 text-sm font-extrabold text-[#3476b9] transition duration-200 hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-60';

  const secondaryButtonClass =
    'flex min-h-[50px] items-center justify-center gap-2 rounded-2xl px-4 text-sm font-bold text-[#737b89] transition duration-200 hover:-translate-y-0.5 disabled:opacity-60';

  return (
    <main
      dir="rtl"
      className="relative isolate flex min-h-screen items-center justify-center overflow-hidden bg-[#e8ebf0] px-4 py-8 text-[#343a46] sm:py-12"
      style={{
        fontFamily: 'Tajawal, Cairo, sans-serif',
        backgroundImage:
          'radial-gradient(circle at 50% 45%, #f4f5f8 0%, #e8ebf0 65%, #e2e6ed 100%)',
      }}
    >
      {/* Decorative background */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-16 top-12 -z-10 h-40 w-40 rounded-full sm:right-[8%] sm:top-[10%] sm:h-48 sm:w-48"
        style={neumorphicCard}
      />

      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-12 bottom-16 -z-10 h-32 w-32 rounded-full sm:bottom-[10%] sm:left-[8%] sm:h-40 sm:w-40"
        style={neumorphicCard}
      />

      <section
        className="relative w-full max-w-[490px] rounded-[30px] p-5 sm:rounded-[34px] sm:p-9"
        style={neumorphicCard}
      >
        {/* Progress */}
        <div className="mb-7">
          <div className="mb-4 flex items-center justify-between gap-2">
            {steps.map(({ number, label, icon: Icon }) => {
              const active = step === number;
              const completed = step > number;

              return (
                <div
                  key={number}
                  className="flex flex-1 flex-col items-center gap-2"
                >
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-full transition-all duration-300 ${
                      active || completed
                        ? 'text-[#3476b9]'
                        : 'text-[#a0a6b1]'
                    }`}
                    style={
                      active
                        ? {
                            background:
                              'linear-gradient(145deg, #eef1f6, #e1e5ec)',
                            boxShadow:
                              'inset 4px 4px 8px #cbd0d9, inset -4px -4px 8px #ffffff',
                          }
                        : completed
                          ? {
                              background: '#e5edf6',
                              boxShadow:
                                '3px 3px 7px #cbd0d9, -3px -3px 7px #ffffff',
                            }
                          : {
                              background: '#e9ecf2',
                              boxShadow:
                                '3px 3px 7px #d1d5de, -3px -3px 7px #ffffff',
                            }
                    }
                  >
                    {completed ? (
                      <Check size={18} strokeWidth={2.5} />
                    ) : (
                      <Icon size={18} />
                    )}
                  </div>

                  <span
                    className={`text-[11px] ${
                      active || completed
                        ? 'font-extrabold text-[#3476b9]'
                        : 'font-medium text-[#939aa7]'
                    }`}
                  >
                    {number}. {label}
                  </span>
                </div>
              );
            })}
          </div>

          <div
            className="h-2 overflow-hidden rounded-full"
            style={{
              background: '#e5e8ef',
              boxShadow:
                'inset 3px 3px 6px #d1d5de, inset -3px -3px 6px #ffffff',
            }}
          >
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${(step / 3) * 100}%`,
                background:
                  'linear-gradient(90deg, #6ba8e5, #3476b9)',
                boxShadow: '0 0 8px #6ba8e555',
              }}
            />
          </div>
        </div>

        {/* Brand */}
        <header className="mb-7 text-center">
          <div
            className="mx-auto mb-4 flex h-[68px] w-[68px] items-center justify-center rounded-full"
            style={{
              background:
                'linear-gradient(145deg, #eef1f6, #e1e5ec)',
              boxShadow:
                '7px 7px 15px #cbd0d9, -7px -7px 15px #ffffff',
            }}
          >
            <div
              className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#e8edf7] text-[#3476b9]"
              style={{
                boxShadow:
                  'inset 3px 3px 6px #d0d7e2, inset -3px -3px 6px #ffffff',
              }}
            >
              {step === 1 ? (
                <User size={23} />
              ) : step === 2 ? (
                <Store size={23} />
              ) : (
                <ClipboardCheck size={23} />
              )}
            </div>
          </div>

          <p className="mb-1 text-[11px] font-extrabold tracking-[0.28em] text-[#3476b9]">
            MENUORA
          </p>

          <h1 className="text-xl font-extrabold tracking-tight text-[#343a46] sm:text-2xl">
            {step === 1
              ? 'أنشئ حسابك'
              : step === 2
                ? 'بيانات مطعمك'
                : 'راجع بياناتك'}
          </h1>

          <p className="mt-2 text-xs leading-6 text-[#858b98] sm:text-sm">
            {step === 1
              ? 'ابدأ رحلتك نحو إدارة مطعمك بذكاء'
              : step === 2
                ? 'أخبرنا المزيد عن مطعمك أو مقهاك'
                : 'تأكد من صحة المعلومات قبل إنشاء الحساب'}
          </p>
        </header>

        {/* Step 1: Account */}
        {step === 1 && (
          <form onSubmit={handleNextStep1} className="space-y-4">
            <div>
              <label htmlFor="register-name" className={labelClass}>
                الاسم الكامل
              </label>
              <div
                className={inputWrapperClass}
                style={neumorphicInput}
              >
                <User
                  size={18}
                  className="shrink-0 text-[#8d96a5]"
                />
                <input
                  id="register-name"
                  name="fullName"
                  autoComplete="name"
                  required
                  placeholder="مثال: أحمد عبد الله"
                  value={formData.fullName}
                  onChange={(e) =>
                    updateField('fullName', e.target.value)
                  }
                  className={fieldClass}
                />
              </div>
            </div>

            <div>
              <label htmlFor="register-email" className={labelClass}>
                البريد الإلكتروني
              </label>
              <div
                className={inputWrapperClass}
                style={neumorphicInput}
              >
                <Mail
                  size={18}
                  className="shrink-0 text-[#8d96a5]"
                />
                <input
                  id="register-email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  placeholder="name@restaurant.com"
                  value={formData.email}
                  onChange={(e) =>
                    updateField('email', e.target.value)
                  }
                  className={fieldClass}
                />
              </div>
            </div>

            <div>
              <label htmlFor="register-phone" className={labelClass}>
                رقم الهاتف (اختياري)
              </label>
              <div
                className={inputWrapperClass}
                style={neumorphicInput}
              >
                <Phone
                  size={18}
                  className="shrink-0 text-[#8d96a5]"
                />
                <input
                  id="register-phone"
                  name="phone"
                  type="tel"
                  autoComplete="tel"
                  placeholder="+213 555 12 34 56"
                  value={formData.phone}
                  onChange={(e) =>
                    updateField('phone', e.target.value)
                  }
                  className={fieldClass}
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="register-password"
                className={labelClass}
              >
                كلمة المرور
              </label>
              <div
                className={inputWrapperClass}
                style={neumorphicInput}
              >
                <Lock
                  size={18}
                  className="shrink-0 text-[#8d96a5]"
                />
                <input
                  id="register-password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  required
                  placeholder="أنشئ كلمة مرور قوية"
                  value={formData.password}
                  onChange={(e) =>
                    updateField('password', e.target.value)
                  }
                  className={fieldClass}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={
                    showPassword
                      ? 'إخفاء كلمة المرور'
                      : 'إظهار كلمة المرور'
                  }
                  className="shrink-0 text-[#8d96a5] hover:text-[#3476b9]"
                >
                  {showPassword ? (
                    <EyeOff size={18} />
                  ) : (
                    <Eye size={18} />
                  )}
                </button>
              </div>

              {formData.password && (
                <div className="mt-3">
                  <div className="mb-2 flex items-center justify-between text-[11px]">
                    <span className="text-[#858b98]">
                      مستوى الأمان
                    </span>
                    <span className={`font-bold ${pwdStrength.color}`}>
                      {pwdStrength.label === 'strong'
                        ? 'قوية'
                        : pwdStrength.label === 'medium'
                          ? 'متوسطة'
                          : 'ضعيفة'}
                    </span>
                  </div>
                  <div
                    className="h-1.5 overflow-hidden rounded-full"
                    style={neumorphicInput}
                  >
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${Math.max(
                          0,
                          Math.min(100, (pwdStrength.score / 4) * 100)
                        )}%`,
                        background:
                          pwdStrength.score >= 3
                            ? '#3a9b72'
                            : pwdStrength.score >= 2
                              ? '#d5a43c'
                              : '#d96b6b',
                      }}
                    />
                  </div>
                </div>
              )}
            </div>

            <div>
              <label
                htmlFor="register-confirm-password"
                className={labelClass}
              >
                تأكيد كلمة المرور
              </label>
              <div
                className={inputWrapperClass}
                style={neumorphicInput}
              >
                <Lock
                  size={18}
                  className="shrink-0 text-[#8d96a5]"
                />
                <input
                  id="register-confirm-password"
                  name="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  required
                  placeholder="أعد كتابة كلمة المرور"
                  value={formData.confirmPassword}
                  onChange={(e) =>
                    updateField('confirmPassword', e.target.value)
                  }
                  className={fieldClass}
                />
                <button
                  type="button"
                  onClick={() =>
                    setShowConfirmPassword((v) => !v)
                  }
                  aria-label={
                    showConfirmPassword
                      ? 'إخفاء كلمة المرور'
                      : 'إظهار كلمة المرور'
                  }
                  className="shrink-0 text-[#8d96a5] hover:text-[#3476b9]"
                >
                  {showConfirmPassword ? (
                    <EyeOff size={18} />
                  ) : (
                    <Eye size={18} />
                  )}
                </button>
              </div>

              {formData.confirmPassword && (
                <p
                  className={`mt-2 text-[11px] ${
                    formData.password === formData.confirmPassword
                      ? 'text-[#338b68]'
                      : 'text-[#c45c68]'
                  }`}
                >
                  {formData.password === formData.confirmPassword
                    ? 'كلمتا المرور متطابقتان'
                    : 'كلمتا المرور غير متطابقتين'}
                </p>
              )}
            </div>

            <button
              type="submit"
              className={`${primaryButtonClass} mt-5 w-full`}
              style={neumorphicCard}
            >
              متابعة بيانات المطعم
              <ArrowLeft size={18} />
            </button>
          </form>
        )}

        {/* Step 2: Restaurant */}
        {step === 2 && (
          <form onSubmit={handleNextStep2} className="space-y-4">
            <div>
              <label
                htmlFor="restaurant-name"
                className={labelClass}
              >
                اسم المطعم أو المقهى
              </label>
              <div
                className={inputWrapperClass}
                style={neumorphicInput}
              >
                <Store
                  size={18}
                  className="shrink-0 text-[#8d96a5]"
                />
                <input
                  id="restaurant-name"
                  name="restaurantName"
                  autoComplete="organization"
                  required
                  placeholder="مثال: مطعم شرفة الأصالة"
                  value={formData.restaurantName}
                  onChange={(e) =>
                    updateField('restaurantName', e.target.value)
                  }
                  className={fieldClass}
                />
              </div>
            </div>

            <div>
              <label htmlFor="restaurant-city" className={labelClass}>
                المدينة
              </label>
              <div
                className={inputWrapperClass}
                style={neumorphicInput}
              >
                <MapPin
                  size={18}
                  className="shrink-0 text-[#8d96a5]"
                />
                <input
                  id="restaurant-city"
                  name="city"
                  autoComplete="address-level2"
                  placeholder="مثال: وهران"
                  value={formData.city}
                  onChange={(e) =>
                    updateField('city', e.target.value)
                  }
                  className={fieldClass}
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="restaurant-address"
                className={labelClass}
              >
                العنوان
              </label>
              <div
                className={inputWrapperClass}
                style={neumorphicInput}
              >
                <MapPin
                  size={18}
                  className="shrink-0 text-[#8d96a5]"
                />
                <input
                  id="restaurant-address"
                  name="address"
                  autoComplete="street-address"
                  placeholder="الحي والشارع"
                  value={formData.address}
                  onChange={(e) =>
                    updateField('address', e.target.value)
                  }
                  className={fieldClass}
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="restaurant-description"
                className={labelClass}
              >
                نبذة عن المطعم (اختياري)
              </label>
              <textarea
                id="restaurant-description"
                name="description"
                rows={3}
                placeholder="عرّف العملاء بمطعمك..."
                value={formData.description}
                onChange={(e) =>
                  updateField('description', e.target.value)
                }
                className="w-full resize-y rounded-2xl border-0 px-4 py-3 text-sm text-[#343a46] outline-none placeholder:text-[#a0a6b1] focus:ring-2 focus:ring-[#6ba8e5]/50"
                style={neumorphicInput}
              />
            </div>

            <div className="flex gap-3 pt-3">
              <button
                type="button"
                onClick={() => setStep(1)}
                className={`${secondaryButtonClass} flex-1`}
                style={neumorphicCard}
              >
                <ArrowRight size={17} />
                السابق
              </button>

              <button
                type="submit"
                className={`${primaryButtonClass} flex-1`}
                style={neumorphicCard}
              >
                مراجعة البيانات
                <ArrowLeft size={17} />
              </button>
            </div>
          </form>
        )}

        {/* Step 3: Confirmation */}
        {step === 3 && (
          <div className="space-y-5">
            <div
              className="flex items-center gap-3 rounded-2xl p-4"
              style={neumorphicInput}
            >
              <div
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-[#3476b9]"
                style={neumorphicCard}
              >
                <ClipboardCheck size={22} />
              </div>
              <div>
                <h2 className="text-sm font-extrabold text-[#343a46]">
                  ملخص التسجيل
                </h2>
                <p className="mt-1 text-xs leading-5 text-[#858b98]">
                  راجع المعلومات التالية قبل إنشاء حساب مطعمك.
                </p>
              </div>
            </div>

            <div
              className="space-y-4 rounded-2xl p-4 sm:p-5"
              style={neumorphicCard}
            >
              <div className="flex items-start gap-3">
                <User
                  size={17}
                  className="mt-0.5 shrink-0 text-[#3476b9]"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] text-[#858b98]">
                    الاسم الكامل
                  </p>
                  <p className="mt-1 break-words text-sm font-bold text-[#343a46]">
                    {formData.fullName}
                  </p>
                </div>
              </div>

              <div className="h-px bg-[#d7dbe3]" />

              <div className="flex items-start gap-3">
                <Mail
                  size={17}
                  className="mt-0.5 shrink-0 text-[#3476b9]"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] text-[#858b98]">
                    البريد الإلكتروني
                  </p>
                  <p
                    dir="ltr"
                    className="mt-1 break-all text-left text-sm font-semibold text-[#343a46]"
                  >
                    {formData.email}
                  </p>
                </div>
              </div>

              {formData.phone && (
                <>
                  <div className="h-px bg-[#d7dbe3]" />
                  <div className="flex items-start gap-3">
                    <Phone
                      size={17}
                      className="mt-0.5 shrink-0 text-[#3476b9]"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-[11px] text-[#858b98]">
                        رقم الهاتف
                      </p>
                      <p
                        dir="ltr"
                        className="mt-1 text-left text-sm font-semibold text-[#343a46]"
                      >
                        {formData.phone}
                      </p>
                    </div>
                  </div>
                </>
              )}

              <div className="h-px bg-[#d7dbe3]" />

              <div className="flex items-start gap-3">
                <Store
                  size={17}
                  className="mt-0.5 shrink-0 text-[#3476b9]"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] text-[#858b98]">
                    اسم المطعم
                  </p>
                  <p className="mt-1 break-words text-sm font-extrabold text-[#3476b9]">
                    {formData.restaurantName}
                  </p>
                </div>
              </div>

              {formData.city && (
                <>
                  <div className="h-px bg-[#d7dbe3]" />
                  <div className="flex items-start gap-3">
                    <MapPin
                      size={17}
                      className="mt-0.5 shrink-0 text-[#3476b9]"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-[11px] text-[#858b98]">
                        المدينة
                      </p>
                      <p className="mt-1 text-sm font-semibold text-[#343a46]">
                        {formData.city}
                      </p>
                    </div>
                  </div>
                </>
              )}

              {formData.address && (
                <>
                  <div className="h-px bg-[#d7dbe3]" />
                  <div className="flex items-start gap-3">
                    <MapPin
                      size={17}
                      className="mt-0.5 shrink-0 text-[#3476b9]"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-[11px] text-[#858b98]">
                        العنوان
                      </p>
                      <p className="mt-1 break-words text-sm text-[#343a46]">
                        {formData.address}
                      </p>
                    </div>
                  </div>
                </>
              )}

              {formData.description && (
                <>
                  <div className="h-px bg-[#d7dbe3]" />
                  <div>
                    <p className="text-[11px] text-[#858b98]">
                      نبذة عن المطعم
                    </p>
                    <p className="mt-1 whitespace-pre-wrap break-words text-sm leading-6 text-[#343a46]">
                      {formData.description}
                    </p>
                  </div>
                </>
              )}
            </div>

            <p className="flex items-start gap-2 text-[11px] leading-6 text-[#858b98]">
              <ShieldCheck
                size={16}
                className="mt-1 shrink-0 text-[#3476b9]"
              />
              سيتم إنشاء حسابك باستخدام خدمة المصادقة الحالية، وقد تحتاج
              إلى تأكيد بريدك الإلكتروني قبل تسجيل الدخول.
            </p>

            <div className="flex gap-3 pt-1">
              <button
                type="button"
                onClick={() => setStep(2)}
                disabled={loading}
                className={`${secondaryButtonClass} flex-1`}
                style={neumorphicCard}
              >
                <ArrowRight size={17} />
                تعديل
              </button>

              <button
                type="button"
                onClick={handleFinalSubmit}
                disabled={loading}
                className={`${primaryButtonClass} flex-1`}
                style={{
                  ...neumorphicCard,
                  color: '#3476b9',
                }}
              >
                {loading ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-[#3476b9] border-t-transparent" />
                    جارٍ الإنشاء...
                  </>
                ) : (
                  <>
                    <Plus size={18} />
                    إنشاء الحساب
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Login navigation */}
        <footer className="mt-7 border-t border-[#d7dbe3] pt-6 text-center">
          <p className="text-xs text-[#858b98]">
            هل لديك حساب مطعم بالفعل؟
          </p>

          <button
            type="button"
            onClick={onNavigateLogin}
            className="mt-3 inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold text-[#3476b9] transition duration-200 hover:-translate-y-0.5"
            style={neumorphicCard}
          >
            تسجيل الدخول
            <ArrowLeft size={17} />
          </button>

          <div className="mt-5 flex items-center justify-center gap-2 text-[10px] text-[#969daa]">
            <ShieldCheck size={14} className="text-[#5795ce]" />
            <span>تسجيل آمن عبر Menuora</span>
          </div>
        </footer>
      </section>

      <p className="mt-6 text-center text-[10px] text-[#a0a6b1]">
        © {new Date().getFullYear()} Menuora — جميع الحقوق محفوظة
      </p>
    </main>
  );
};
