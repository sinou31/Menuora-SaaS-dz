
import React, { useState } from 'react';
import {
  Lock,
  CheckCircle2,
  ShieldCheck,
  Eye,
  EyeOff,
  ArrowLeft,
  KeyRound,
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { evaluatePasswordStrength } from '../../utils/validators';
import { useToast } from '../../hooks/useToast';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';

interface ResetPasswordPageProps {
  onSuccess: () => void;
}

export const ResetPasswordPage: React.FC<ResetPasswordPageProps> = ({
  onSuccess,
}) => {
  const { updatePassword } = useAuth();
  const { success, error: toastError } = useToast();

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [completed, setCompleted] = useState(false);

  const pwdStrength = evaluatePasswordStrength(password);

  const strengthLabel =
    pwdStrength.label === 'strong'
      ? 'قوية'
      : pwdStrength.label === 'medium'
        ? 'متوسطة'
        : 'ضعيفة';

  const strengthColor =
    pwdStrength.label === 'strong'
      ? 'text-emerald-600'
      : pwdStrength.label === 'medium'
        ? 'text-amber-600'
        : 'text-rose-500';

  const strengthWidth =
    pwdStrength.score >= 3
      ? '100%'
      : pwdStrength.score === 2
        ? '66%'
        : pwdStrength.score === 1
          ? '33%'
          : '8%';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (pwdStrength.score < 2) {
      toastError(
        'يرجى اختيار كلمة مرور أقوى (8 أحرف على الأقل تحتوي على أرقام وأحرف)',
      );
      return;
    }

    if (password !== confirmPassword) {
      toastError('كلمتا المرور غير متطابقتين');
      return;
    }

    setLoading(true);

    try {
      const { error } = await updatePassword(password);

      if (error) throw error;

      success('تم تعيين كلمة المرور الجديدة بنجاح');
      setCompleted(true);
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : 'فشل تحديث كلمة المرور';

      toastError(message || 'فشل تحديث كلمة المرور');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      dir="rtl"
      className="flex min-h-screen items-center justify-center bg-[#E8EDF5] px-4 py-10 text-[#26334A]"
    >
      <div className="w-full max-w-md">
        {/* Brand */}
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[22px] bg-[#E8EDF5] text-[#4776D0] shadow-[8px_8px_18px_#c6cbd2,-8px_-8px_18px_#ffffff]">
            <ShieldCheck className="h-8 w-8" />
          </div>

          <h1 className="text-2xl font-black tracking-tight">Menuora</h1>
          <p className="mt-2 text-sm text-[#7C899E]">
            أمان حسابك يبدأ بكلمة مرور قوية
          </p>
        </div>

        {/* Main card */}
        <div className="rounded-[30px] border border-white/70 bg-[#E8EDF5] p-6 shadow-[12px_12px_30px_#c6cbd2,-12px_-12px_30px_#ffffff] sm:p-9">
          {completed ? (
            <div className="py-3 text-center">
              <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-[#E8EDF5] text-emerald-600 shadow-[inset_5px_5px_10px_#c6cbd2,inset_-5px_-5px_10px_#ffffff]">
                <CheckCircle2 className="h-8 w-8" />
              </div>

              <h2 className="text-xl font-extrabold sm:text-2xl">
                تم تحديث كلمة المرور
              </h2>

              <p className="mt-4 text-sm leading-7 text-[#7C899E]">
                تم حفظ كلمة المرور الجديدة بنجاح. يمكنك الآن المتابعة إلى
                حسابك واستخدام كلمة المرور الجديدة لتسجيل الدخول.
              </p>

              <Button
                variant="primary"
                className="mt-6 w-full"
                onClick={onSuccess}
              >
                <span>المتابعة إلى لوحة التحكم</span>
                <ArrowLeft className="mr-2 h-4 w-4" />
              </Button>
            </div>
          ) : (
            <>
              <div className="mb-7 text-center">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#E8EDF5] text-[#4776D0] shadow-[inset_5px_5px_10px_#c6cbd2,inset_-5px_-5px_10px_#ffffff]">
                  <KeyRound className="h-6 w-6" />
                </div>

                <h2 className="text-xl font-extrabold sm:text-2xl">
                  إعادة تعيين كلمة المرور
                </h2>

                <p className="mt-3 text-sm leading-7 text-[#7C899E]">
                  اختر كلمة مرور جديدة وآمنة لحساب مطعمك.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <Input
                    label="كلمة المرور الجديدة"
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="أدخل كلمة مرور جديدة"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    icon={<Lock className="h-4 w-4" />}
                  />

                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    aria-label={
                      showPassword
                        ? 'إخفاء كلمة المرور'
                        : 'إظهار كلمة المرور'
                    }
                    className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-[#718099] transition-colors hover:text-[#4776D0]"
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                    {showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                  </button>
                </div>

                {password.length > 0 && (
                  <div className="rounded-2xl bg-[#E8EDF5] p-4 shadow-[inset_4px_4px_8px_#c6cbd2,inset_-4px_-4px_8px_#ffffff]">
                    <div className="mb-3 flex items-center justify-between text-xs">
                      <span className="text-[#7C899E]">
                        قوة كلمة المرور
                      </span>
                      <span className={`font-bold ${strengthColor}`}>
                        {strengthLabel}
                      </span>
                    </div>

                    <div
                      className="h-2 overflow-hidden rounded-full bg-[#D8DFE9]"
                      role="progressbar"
                      aria-label="قوة كلمة المرور"
                      aria-valuemin={0}
                      aria-valuemax={100}
                      aria-valuenow={pwdStrength.score >= 3 ? 100 : pwdStrength.score === 2 ? 66 : pwdStrength.score === 1 ? 33 : 8}
                    >
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          pwdStrength.label === 'strong'
                            ? 'bg-emerald-500'
                            : pwdStrength.label === 'medium'
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                        }`}
                        style={{ width: strengthWidth }}
                      />
                    </div>

                    <p className="mt-3 text-[11px] leading-5 text-[#7C899E]">
                      استخدم 8 أحرف على الأقل، مع مزيج من الحروف والأرقام
                      لزيادة الأمان.
                    </p>
                  </div>
                )}

                <div>
                  <Input
                    label="تأكيد كلمة المرور الجديدة"
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    placeholder="أعد كتابة كلمة المرور"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    icon={<Lock className="h-4 w-4" />}
                  />

                  <button
                    type="button"
                    onClick={() =>
                      setShowConfirmPassword((value) => !value)
                    }
                    aria-label={
                      showConfirmPassword
                        ? 'إخفاء تأكيد كلمة المرور'
                        : 'إظهار تأكيد كلمة المرور'
                    }
                    className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-[#718099] transition-colors hover:text-[#4776D0]"
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                    {showConfirmPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                  </button>

                  {confirmPassword.length > 0 && (
                    <p
                      className={`mt-2 text-xs ${
                        password === confirmPassword
                          ? 'text-emerald-600'
                          : 'text-rose-500'
                      }`}
                    >
                      {password === confirmPassword
                        ? 'كلمتا المرور متطابقتان'
                        : 'كلمتا المرور غير متطابقتين'}
                    </p>
                  )}
                </div>

                <Button
                  type="submit"
                  variant="primary"
                  loading={loading}
                  className="mt-2 w-full"
                >
                  حفظ كلمة المرور الجديدة
                  <ArrowLeft className="mr-2 h-4 w-4" />
                </Button>
              </form>

              <div className="mt-6 flex items-center justify-center gap-2 text-xs text-[#8B96A8]">
                <ShieldCheck className="h-4 w-4" />
                <span>لا تشارك كلمة المرور مع أي شخص</span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
