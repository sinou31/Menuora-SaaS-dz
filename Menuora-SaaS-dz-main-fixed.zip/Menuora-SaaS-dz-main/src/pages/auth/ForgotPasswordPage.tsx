
import React, { useState } from 'react';
import {
  Mail,
  ArrowRight,
  CheckCircle2,
  ShieldCheck,
  ArrowLeft,
  Loader2,
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { isValidEmail } from '../../utils/validators';
import { useToast } from '../../hooks/useToast';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';

interface ForgotPasswordPageProps {
  onNavigateLogin: () => void;
}

export const ForgotPasswordPage: React.FC<ForgotPasswordPageProps> = ({
  onNavigateLogin,
}) => {
  const { resetPassword } = useAuth();
  const { error: toastError } = useToast();

  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const normalizedEmail = email.trim();

    if (!isValidEmail(normalizedEmail)) {
      toastError('يرجى كتابة بريد إلكتروني صالح');
      return;
    }

    setLoading(true);

    try {
      await resetPassword(normalizedEmail);
    } catch {
      // Keep the response generic to prevent account enumeration.
    } finally {
      setSubmitted(true);
      setLoading(false);
    }
  };

  return (
    <div
      dir="rtl"
      className="min-h-screen flex items-center justify-center bg-[#E8EDF5] px-4 py-10 text-[#26334A]"
    >
      <div className="w-full max-w-md">
        {/* Brand */}
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[22px] bg-[#E8EDF5] text-[#4776D0] shadow-[8px_8px_18px_#c6cbd2,-8px_-8px_18px_#ffffff]">
            <ShieldCheck className="h-8 w-8" />
          </div>

          <h1 className="text-2xl font-black tracking-tight text-[#26334A]">
            Menuora
          </h1>
          <p className="mt-2 text-sm text-[#7C899E]">
            إدارة مطعمك تبدأ من هنا
          </p>
        </div>

        {/* Main card */}
        <div className="rounded-[30px] border border-white/70 bg-[#E8EDF5] p-6 shadow-[12px_12px_30px_#c6cbd2,-12px_-12px_30px_#ffffff] sm:p-9">
          {!submitted ? (
            <>
              <div className="mb-7 text-center">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#E8EDF5] text-[#4776D0] shadow-[inset_5px_5px_10px_#c6cbd2,inset_-5px_-5px_10px_#ffffff]">
                  <Mail className="h-6 w-6" />
                </div>

                <h2 className="text-xl font-extrabold sm:text-2xl">
                  استعادة كلمة المرور
                </h2>
                <p className="mt-3 text-sm leading-7 text-[#7C899E]">
                  لا تقلق، يحدث هذا أحيانًا. أدخل بريدك الإلكتروني المسجل
                  وسنرسل لك تعليمات إعادة تعيين كلمة المرور.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <Input
                    label="البريد الإلكتروني المسجل"
                    type="email"
                    required
                    placeholder="name@restaurant.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    icon={<Mail className="h-4 w-4" />}
                  />
                </div>

                <Button
                  type="submit"
                  variant="primary"
                  loading={loading}
                  className="mt-2 w-full"
                >
                  {loading ? (
                    <>
                      <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      جارٍ إرسال التعليمات...
                    </>
                  ) : (
                    <>
                      <span>إرسال رابط الاستعادة</span>
                      <ArrowLeft className="mr-2 h-4 w-4" />
                    </>
                  )}
                </Button>

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={onNavigateLogin}
                    className="inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold text-[#718099] transition-colors hover:text-[#4776D0]"
                  >
                    <ArrowRight className="h-4 w-4" />
                    العودة إلى تسجيل الدخول
                  </button>
                </div>
              </form>
            </>
          ) : (
            <div className="py-3 text-center">
              <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-[#E8EDF5] text-emerald-600 shadow-[inset_5px_5px_10px_#c6cbd2,inset_-5px_-5px_10px_#ffffff]">
                <CheckCircle2 className="h-8 w-8" />
              </div>

              <h2 className="text-xl font-extrabold sm:text-2xl">
                تحقق من بريدك الإلكتروني
              </h2>

              <p className="mt-4 text-sm leading-7 text-[#7C899E]">
                إذا كان البريد الإلكتروني الذي أدخلته مسجلًا لدينا، فستصلك
                رسالة تحتوي على رابط إعادة تعيين كلمة المرور. تحقق أيضًا من
                مجلد الرسائل غير المرغوب فيها.
              </p>

              <div className="mt-5 rounded-2xl bg-[#E8EDF5] px-4 py-3 text-sm text-[#52627B] shadow-[inset_4px_4px_8px_#c6cbd2,inset_-4px_-4px_8px_#ffffff]">
                <span className="break-all font-semibold" dir="ltr">
                  {email.trim()}
                </span>
              </div>

              <Button
                variant="secondary"
                className="mt-6 w-full"
                onClick={onNavigateLogin}
              >
                العودة إلى تسجيل الدخول
              </Button>

              <button
                type="button"
                onClick={() => setSubmitted(false)}
                className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-[#4776D0] transition-colors hover:text-[#315BA8]"
              >
                <ArrowRight className="h-4 w-4" />
                تجربة بريد إلكتروني آخر
              </button>
            </div>
          )}
        </div>

        <p className="mt-6 text-center text-xs leading-6 text-[#8B96A8]">
          نحافظ على خصوصية حسابك ولا نكشف ما إذا كان البريد مسجلًا لدينا.
        </p>
      </div>
    </div>
  );
};
