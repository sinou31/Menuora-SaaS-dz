import React, { useState } from 'react';
import { Save, Store, Globe, Phone, MapPin, DollarSign, Image as ImageIcon } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { restaurantService } from '../../services/restaurantService';
import { storageService } from '../../services/storageService';
import { useToast } from '../../hooks/useToast';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';
import { ImageUploader } from '../../components/ImageUploader';

export const RestaurantSettingsPage: React.FC = () => {
  const { restaurant, refreshRestaurant } = useAuth();
  const { success, error: toastError } = useToast();

  const [name, setName] = useState(restaurant?.name || '');
  const [description, setDescription] = useState(restaurant?.description || '');
  const [phone, setPhone] = useState(restaurant?.phone || '');
  const [whatsapp, setWhatsapp] = useState(restaurant?.whatsapp || '');
  const [address, setAddress] = useState(restaurant?.address || '');
  const [city, setCity] = useState(restaurant?.city || '');
  const [currency, setCurrency] = useState(restaurant?.currency || 'DZD');

  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!restaurant?.id) return;

    if (!name.trim()) {
      toastError('اسم المطعم مطلوب');
      return;
    }

    setIsSubmitting(true);
    try {
      let logoUrl = restaurant.logo_url;
      let coverUrl = restaurant.cover_url;

      if (logoFile) {
        const logoRes = await storageService.uploadRestaurantAsset(restaurant.id, logoFile, 'logo');
        logoUrl = logoRes.url;
      }

      if (coverFile) {
        const coverRes = await storageService.uploadRestaurantAsset(restaurant.id, coverFile, 'cover');
        coverUrl = coverRes.url;
      }

      await restaurantService.updateRestaurant(restaurant.id, {
        name: name.trim(),
        description: description.trim() || null,
        phone: phone.trim() || null,
        whatsapp: whatsapp.trim() || null,
        address: address.trim() || null,
        city: city.trim() || null,
        currency: currency.trim() || 'DZD',
        logo_url: logoUrl,
        cover_url: coverUrl
      });

      await refreshRestaurant();
      success('تم حفظ إعدادات المطعم بنجاح');
    } catch (err: any) {
      toastError(err.message || 'فشل تحديث البيانات');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="text-lg md:text-xl font-bold text-white">إعدادات المطعم والهوية البصرية</h2>
        <p className="text-xs text-[#8E95A8] mt-1">
          تخصيص بيانات المطعم المعروضة للزبائن على القائمة الرقمية
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Visual Brand Assets */}
        <div className="p-5 rounded-2xl bg-[#11131B] border border-[#212635] space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-[#D4AF37]" />
            <span>الهوية البصرية (الشعار والغلاف)</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ImageUploader
              label="شعار المطعم (Logo)"
              initialImageUrl={restaurant?.logo_url}
              onFileSelect={file => setLogoFile(file)}
            />
            <ImageUploader
              label="صورة غلاف المطعم (Banner)"
              initialImageUrl={restaurant?.cover_url}
              onFileSelect={file => setCoverFile(file)}
            />
          </div>
        </div>

        {/* General Info */}
        <div className="p-5 rounded-2xl bg-[#11131B] border border-[#212635] space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Store className="w-4 h-4 text-[#D4AF37]" />
            <span>المعلومات الأساسية</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Input
              label="اسم المطعم"
              required
              value={name}
              onChange={e => setName(e.target.value)}
            />

            <div className="flex flex-col gap-1.5 text-right">
              <label className="text-xs font-semibold text-[#C4C7D5]">معرف الرابط (Slug)</label>
              <input
                disabled
                value={restaurant?.slug || ''}
                className="w-full bg-[#0D0F15] border border-[#232736] text-[#7E8699] font-mono text-sm rounded-lg px-3.5 py-2.5 cursor-not-allowed"
              />
              <span className="text-[10px] text-[#6E7587]">المعرف الفريد لرابط قائمتك الرقمية</span>
            </div>
          </div>

          <div className="flex flex-col gap-1.5 text-right">
            <label className="text-xs font-semibold text-[#C4C7D5]">نبذة عن المطعم</label>
            <textarea
              rows={3}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="وصف ترحيبي يظهر أعلى القائمة الرقمية للزبائن..."
              className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-sm rounded-lg p-3 focus:outline-none focus:border-[#D4AF37]"
            />
          </div>
        </div>

        {/* Contact and Location */}
        <div className="p-5 rounded-2xl bg-[#11131B] border border-[#212635] space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#D4AF37]" />
            <span>التواصل والموقع الجغرافي والعملة</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Input
              label="رقم الهاتف"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="+966500000000"
              icon={<Phone className="w-4 h-4" />}
            />
            <Input
              label="رقم الواتساب للطلبات"
              value={whatsapp}
              onChange={e => setWhatsapp(e.target.value)}
              placeholder="+966500000000"
            />
            <div className="flex flex-col gap-1.5 text-right">
              <label className="text-xs font-semibold text-[#C4C7D5]">عملة الأسعار</label>
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value)}
                className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="DZD">دينار جزائري (DZD)</option>
                <option value="SAR">ريال سعودي (SAR)</option>
                <option value="AED">درهم إماراتي (AED)</option>
                <option value="KWD">دينار كويتي (KWD)</option>
                <option value="QAR">ريال قطري (QAR)</option>
                <option value="OMR">ريال عماني (OMR)</option>
                <option value="BHD">دينار بحريني (BHD)</option>
                <option value="EGP">جنيه مصري (EGP)</option>
                <option value="USD">دولار أمريكي (USD)</option>
                <option value="EUR">يورو (EUR)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="المدينة"
              value={city}
              onChange={e => setCity(e.target.value)}
              placeholder="مثال: الرياض"
            />
            <Input
              label="العنوان بالتفصيل"
              value={address}
              onChange={e => setAddress(e.target.value)}
              placeholder="مثال: حي العليا، طريق الملك فهد"
            />
          </div>
        </div>

        {/* Submit */}
        <div className="flex items-center justify-end">
          <Button
            type="submit"
            variant="primary"
            loading={isSubmitting}
            icon={<Save className="w-4 h-4" />}
          >
            حفظ التغييرات
          </Button>
        </div>
      </form>
    </div>
  );
};
