import React, { useState, useEffect, useCallback } from 'react';
import {
  Sparkles,
  Wand2,
  Languages,
  Activity,
  Check,
  RotateCcw,
  X,
  Save,
  Plus,
  Copy,
  Info,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Eye,
  SlidersHorizontal,
  ArrowRight
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { aiService } from '../../services/aiService';
import { menuItemService } from '../../services/menuItemService';
import { categoryService } from '../../services/categoryService';
import { MenuItem, Category, AIProductGeneratedResult, AITranslatedItem, AIUsageSummary } from '../../types/database.types';
import { useToast } from '../../hooks/useToast';
import { Button } from '../../components/Button';
import { Input } from '../../components/Input';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import { Modal } from '../../components/Modal';

type ActiveAITab = 'generator' | 'translator' | 'usage' | 'image_enhancer';

export const AIMenuManagerPage: React.FC = () => {
  const { restaurant } = useAuth();
  const { success, error: toastError, info } = useToast();

  const [activeTab, setActiveTab] = useState<ActiveAITab>('generator');
  const [existingItems, setExistingItems] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  // Tab 1: Product Description Generator State
  const [genProductName, setGenProductName] = useState('');
  const [genIngredients, setGenIngredients] = useState('');
  const [genLanguage, setGenLanguage] = useState<'ar' | 'en' | 'fr'>('ar');
  const [genTone, setGenTone] = useState('appetizing');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedResult, setGeneratedResult] = useState<AIProductGeneratedResult | null>(null);

  // Editing state before saving generated item
  const [editGenerated, setEditGenerated] = useState<{
    name: string;
    short_description: string;
    description: string;
    ingredientsText: string;
    price: string;
    category_id: string;
  }>({
    name: '',
    short_description: '',
    description: '',
    ingredientsText: '',
    price: '25',
    category_id: ''
  });
  const [isSavingProduct, setIsSavingProduct] = useState(false);

  // Tab 2: Translation State
  const [sourceLang, setSourceLang] = useState<'ar' | 'en' | 'fr'>('ar');
  const [targetLang, setTargetLang] = useState<'ar' | 'en' | 'fr'>('en');
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [isTranslating, setIsTranslating] = useState(false);
  const [translatedResults, setTranslatedResults] = useState<AITranslatedItem[] | null>(null);
  const [isSavingTranslations, setIsSavingTranslations] = useState(false);

  // Tab 3: Usage Stats
  const [usageStats, setUsageStats] = useState<AIUsageSummary | null>(null);
  const [loadingUsage, setLoadingUsage] = useState(false);

  const loadInitialData = useCallback(async () => {
    if (!restaurant?.id) return;
    try {
      const [items, cats] = await Promise.all([
        menuItemService.getMenuItems(restaurant.id),
        categoryService.getCategories(restaurant.id)
      ]);
      setExistingItems(items);
      setCategories(cats);
    } catch (err: any) {
      console.warn('Error loading items for AI manager:', err);
    } finally {
      setLoadingData(false);
    }
  }, [restaurant?.id]);

  const loadUsage = useCallback(async () => {
    if (!restaurant?.id) return;
    setLoadingUsage(true);
    try {
      const stats = await aiService.getAIUsageStats(restaurant.id);
      setUsageStats(stats);
    } catch (err) {
      console.warn('Failed to load AI usage:', err);
    } finally {
      setLoadingUsage(false);
    }
  }, [restaurant?.id]);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  useEffect(() => {
    if (activeTab === 'usage') {
      loadUsage();
    }
  }, [activeTab, loadUsage]);

  // Handle Generate Description
  const handleGenerateDescription = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!restaurant?.id) return;
    if (!genProductName.trim()) {
      toastError('يرجى كتابة اسم الطبق الأساسي أولاً');
      return;
    }

    setIsGenerating(true);
    try {
      const res = await aiService.generateProductDescription({
        restaurantId: restaurant.id,
        productName: genProductName,
        rawIngredients: genIngredients,
        language: genLanguage,
        tone: genTone
      });

      setGeneratedResult(res);
      setEditGenerated({
        name: res.name,
        short_description: res.short_description,
        description: res.description,
        ingredientsText: res.ingredients.join(', '),
        price: '30.00',
        category_id: categories[0]?.id || ''
      });
      success('تم توليد الاقتراح بالذكاء الاصطناعي بنجاح ✨');
    } catch (err: any) {
      toastError(err.message || 'فشل توليد الوصف');
    } finally {
      setIsGenerating(false);
    }
  };

  // Save Generated Product to Supabase
  const handleSaveGeneratedProduct = async () => {
    if (!restaurant?.id || !generatedResult) return;
    if (!editGenerated.name.trim()) {
      toastError('اسم المنتج مطلوب');
      return;
    }
    const priceNum = parseFloat(editGenerated.price);
    if (isNaN(priceNum) || priceNum < 0) {
      toastError('يرجى إدخال سعر صحيح');
      return;
    }

    setIsSavingProduct(true);
    try {
      await menuItemService.createMenuItem(restaurant.id, {
        name: editGenerated.name.trim(),
        description: editGenerated.description.trim() || editGenerated.short_description,
        price: priceNum,
        category_id: editGenerated.category_id || null,
        is_available: true,
        is_featured: false
      });

      success('تم حفظ المنتج في قائمة طعام مطعمك بنجاح ✓');
      setGeneratedResult(null);
      setGenProductName('');
      setGenIngredients('');
      await loadInitialData();
    } catch (err: any) {
      toastError(err.message || 'فشل حفظ المنتج');
    } finally {
      setIsSavingProduct(false);
    }
  };

  // Handle Translate Items
  const handleTranslate = async () => {
    if (!restaurant?.id) return;
    if (selectedItemIds.length === 0) {
      toastError('يرجى تحديد طبق واحد على الأقل للترجمة');
      return;
    }
    if (sourceLang === targetLang) {
      toastError('يرجى اختيار لغة هدف مختلفة عن لغة المصدر');
      return;
    }

    const itemsToTranslate = existingItems
      .filter(it => selectedItemIds.includes(it.id))
      .map(it => ({
        id: it.id,
        name: it.name,
        description: it.description,
        ingredients: []
      }));

    setIsTranslating(true);
    try {
      const results = await aiService.translateMenuItems({
        restaurantId: restaurant.id,
        sourceLang,
        targetLang,
        items: itemsToTranslate
      });

      setTranslatedResults(results);
      success(`تمت ترجمة ${results.length} صنفاً بنجاح ✨ يمكنك مراجعتها وحفظها.`);
    } catch (err: any) {
      toastError(err.message || 'فشلت الترجمة');
    } finally {
      setIsTranslating(false);
    }
  };

  // Apply and Save Translated Items
  const handleApplyTranslations = async () => {
    if (!translatedResults || translatedResults.length === 0) return;
    setIsSavingTranslations(true);
    try {
      // Never trust ids echoed back by the AI: only update items the user selected.
      const allowedIds = new Set(selectedItemIds);
      const safeResults = translatedResults.filter(
        t => allowedIds.has(t.id) && t.name?.trim()
      );

      if (safeResults.length === 0) {
        throw new Error('لم يتم العثور على ترجمات صالحة للتطبيق');
      }

      for (const t of safeResults) {
        await menuItemService.updateMenuItem(t.id, {
          name: t.name.trim(),
          description: t.description?.trim() || null
        });
      }
      success('تم تطبيق وحفظ الترجمات في قاعدة البيانات بنجاح ✓');
      setTranslatedResults(null);
      setSelectedItemIds([]);
      await loadInitialData();
    } catch (err: any) {
      toastError(err.message || 'فشل حفظ بعض الترجمات');
    } finally {
      setIsSavingTranslations(false);
    }
  };

  const selectAllItems = () => {
    // At most 15 items can be translated per batch, so compare against that cap.
    if (selectedItemIds.length === Math.min(existingItems.length, 15)) {
      setSelectedItemIds([]);
    } else {
      setSelectedItemIds(existingItems.slice(0, 15).map(i => i.id));
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    info('تم النسخ إلى الحافظة');
  };

  if (loadingData) {
    return <LoadingSpinner message="جاري تحميل مدير الذكاء الاصطناعي..." />;
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-[#141724] via-[#10121B] to-[#141724] border border-[#23293D]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4AF37] to-[#8C6D1F] flex items-center justify-center text-black font-black shadow-md shrink-0">
            <Sparkles className="w-5 h-5 fill-black" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg md:text-xl font-bold text-white">مدير القائمة الذكي (AI Menu Manager)</h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/30">
                PRO AI
              </span>
            </div>
            <p className="text-xs text-[#8E95A8] mt-0.5">
              توليد أوصاف أطباق احترافية، ترجمة القائمة متعددة اللغات، ومتابعة استهلاك السحابة
            </p>
          </div>
        </div>
      </div>

      {/* Segmented Control Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-[#12141D] rounded-xl border border-[#202534] overflow-x-auto text-xs">
        <button
          onClick={() => setActiveTab('generator')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'generator'
              ? 'bg-[#D4AF37] text-black font-bold shadow-sm'
              : 'text-[#8E95A8] hover:text-white hover:bg-white/5'
          }`}
        >
          <Wand2 className="w-4 h-4" />
          <span>توليد وصف الأطباق (AI Description)</span>
        </button>

        <button
          onClick={() => setActiveTab('translator')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'translator'
              ? 'bg-[#D4AF37] text-black font-bold shadow-sm'
              : 'text-[#8E95A8] hover:text-white hover:bg-white/5'
          }`}
        >
          <Languages className="w-4 h-4" />
          <span>ترجمة القائمة (AI Translation)</span>
        </button>

        <button
          onClick={() => setActiveTab('usage')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'usage'
              ? 'bg-[#D4AF37] text-black font-bold shadow-sm'
              : 'text-[#8E95A8] hover:text-white hover:bg-white/5'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>سجل الاستهلاك الحقيقي (AI Usage)</span>
        </button>

        <button
          onClick={() => setActiveTab('image_enhancer')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'image_enhancer'
              ? 'bg-[#D4AF37] text-black font-bold shadow-sm'
              : 'text-[#8E95A8] hover:text-white hover:bg-white/5'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span>تحسين صور الأطباق (Image AI)</span>
        </button>
      </div>

      {/* =========================================================================
          TAB 1: PRODUCT DESCRIPTION GENERATOR
         ========================================================================= */}
      {activeTab === 'generator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Form: Inputs */}
          <div className="lg:col-span-5 p-5 rounded-2xl bg-[#11131B] border border-[#212635] space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-[#D4AF37]" />
                <span>بيانات الصنف الأولية</span>
              </h3>
              <p className="text-xs text-[#8E95A8] mt-1">
                اكتب اسماً بسيطاً والمكونات وسيقوم الذكاء الاصطناعي بصياغة اسم ووصف جذاب لقائمتك
              </p>
            </div>

            <form onSubmit={handleGenerateDescription} className="space-y-4">
              <Input
                label="اسم الطبق أو المشروب"
                required
                placeholder="مثال: Pizza Margherita أو برجر لحم مدخن"
                value={genProductName}
                onChange={e => setGenProductName(e.target.value)}
              />

              <div className="flex flex-col gap-1.5 text-right">
                <label className="text-xs font-semibold text-[#C4C7D5]">المكونات الأساسية أو النكهات</label>
                <textarea
                  rows={3}
                  placeholder="مثال: صلصة طماطم سان مارزانو، موزاريلا طازجة، ريحان إيطالي، زيت زيتون بكر"
                  value={genIngredients}
                  onChange={e => setGenIngredients(e.target.value)}
                  className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-xs rounded-lg p-3 focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5 text-right">
                  <label className="text-xs font-semibold text-[#C4C7D5]">لغة الصياغة</label>
                  <select
                    value={genLanguage}
                    onChange={e => setGenLanguage(e.target.value as any)}
                    className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-xs rounded-lg px-3 py-2.5 focus:outline-none focus:border-[#D4AF37]"
                  >
                    <option value="ar">العربية (Arabic)</option>
                    <option value="en">الإنجليزية (English)</option>
                    <option value="fr">الفرنسية (French)</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1.5 text-right">
                  <label className="text-xs font-semibold text-[#C4C7D5]">نبرة الوصف (Tone)</label>
                  <select
                    value={genTone}
                    onChange={e => setGenTone(e.target.value)}
                    className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-xs rounded-lg px-3 py-2.5 focus:outline-none focus:border-[#D4AF37]"
                  >
                    <option value="appetizing">شهي وفاخر (Gourmet)</option>
                    <option value="classic">كلاسيكي ومعياري</option>
                    <option value="healthy">صحي ومختصر (Fresh)</option>
                  </select>
                </div>
              </div>

              <div className="pt-2">
                <Button
                  type="submit"
                  variant="primary"
                  loading={isGenerating}
                  className="w-full py-2.5"
                  icon={<Sparkles className="w-4 h-4" />}
                >
                  {isGenerating ? 'جاري التفكير والصياغة...' : '✨ توليد الاقتراح بالذكاء الاصطناعي'}
                </Button>
              </div>
            </form>
          </div>

          {/* Right Area: Output & Review Before Save */}
          <div className="lg:col-span-7 p-5 rounded-2xl bg-[#11131B] border border-[#212635] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-[#1E2332] mb-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Eye className="w-4 h-4 text-[#D4AF37]" />
                  <span>معاينة وتعديل الاقتراح (Preview & Edit)</span>
                </h3>
                {generatedResult && (
                  <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>تم التحقق من هيكل البيانات</span>
                  </span>
                )}
              </div>

              {isGenerating ? (
                <div className="py-16 flex flex-col items-center justify-center gap-3 text-center">
                  <Loader2 className="w-8 h-8 text-[#D4AF37] animate-spin" />
                  <p className="text-xs font-semibold text-white">جاري التفكير وصياغة الوصف الشهي...</p>
                  <p className="text-[11px] text-[#7E8597]">الطلب يمر عبر Supabase Edge Function بطريقة آمنة تماماً</p>
                </div>
              ) : generatedResult ? (
                <div className="space-y-4">
                  {/* Editable Name */}
                  <Input
                    label="الاسم المقترح (قابل للتعديل)"
                    value={editGenerated.name}
                    onChange={e => setEditGenerated({ ...editGenerated, name: e.target.value })}
                  />

                  {/* Short Description */}
                  <Input
                    label="وصف ترويجي قصير (Teaser)"
                    value={editGenerated.short_description}
                    onChange={e => setEditGenerated({ ...editGenerated, short_description: e.target.value })}
                  />

                  {/* Full Description */}
                  <div className="flex flex-col gap-1 text-right">
                    <label className="text-xs font-semibold text-[#C4C7D5]">الوصف التفصيلي الجذاب</label>
                    <textarea
                      rows={3}
                      value={editGenerated.description}
                      onChange={e => setEditGenerated({ ...editGenerated, description: e.target.value })}
                      className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-xs rounded-lg p-3 focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  {/* Ingredients & Tags */}
                  <div className="p-3 bg-[#151824] rounded-xl border border-[#232838] space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-[#8E95A8]">المكونات المحددة:</span>
                      <button
                        onClick={() => copyToClipboard(generatedResult.ingredients.join(', '))}
                        className="text-[11px] text-[#D4AF37] hover:underline flex items-center gap-1"
                      >
                        <Copy className="w-3 h-3" />
                        <span>نسخ</span>
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {generatedResult.ingredients.map((ing, i) => (
                        <span key={i} className="px-2 py-0.5 rounded-md bg-[#1F2434] text-white text-[11px]">
                          {ing}
                        </span>
                      ))}
                    </div>

                    {generatedResult.tags.length > 0 && (
                      <div className="pt-2 border-t border-[#1F2432] flex items-center gap-2">
                        <span className="text-[#8E95A8] text-[11px]">الوسوم:</span>
                        <div className="flex flex-wrap gap-1">
                          {generatedResult.tags.map((t, i) => (
                            <span key={i} className="text-[10px] text-[#D4AF37] font-mono">
                              #{t}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Save Settings */}
                  <div className="p-3 bg-[#131620] rounded-xl border border-[#222736] grid grid-cols-2 gap-3">
                    <Input
                      label={`السعر (${restaurant?.currency || 'DZD'})`}
                      type="number"
                      step="0.01"
                      min="0"
                      value={editGenerated.price}
                      onChange={e => setEditGenerated({ ...editGenerated, price: e.target.value })}
                    />

                    <div className="flex flex-col gap-1 text-right">
                      <label className="text-xs font-semibold text-[#C4C7D5]">حفظ في تصنيف</label>
                      <select
                        value={editGenerated.category_id}
                        onChange={e => setEditGenerated({ ...editGenerated, category_id: e.target.value })}
                        className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-xs rounded-lg px-3 py-2.5 focus:outline-none focus:border-[#D4AF37]"
                      >
                        <option value="">بدون تصنيف</option>
                        {categories.map(c => (
                          <option key={c.id} value={c.id}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="py-20 text-center text-xs text-[#7E8597] border border-dashed border-[#202534] rounded-xl">
                  اكتب اسم ومكونات الطبق على اليمين ثم اضغط على زر التوليد لرؤية مقترح الذكاء الاصطناعي وتعديله قبل الحفظ في قائمتك.
                </div>
              )}
            </div>

            {/* Action Buttons: Accept / Reject / Regenerate */}
            {generatedResult && (
              <div className="pt-4 border-t border-[#1E2332] mt-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setGeneratedResult(null)}
                    icon={<X className="w-3.5 h-3.5 text-rose-400" />}
                  >
                    تجاهل النتيجة
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={handleGenerateDescription}
                    loading={isGenerating}
                    icon={<RotateCcw className="w-3.5 h-3.5" />}
                  >
                    إعادة الصياغة
                  </Button>
                </div>

                <Button
                  size="sm"
                  variant="primary"
                  loading={isSavingProduct}
                  onClick={handleSaveGeneratedProduct}
                  icon={<Save className="w-3.5 h-3.5" />}
                >
                  قبول وحفظ في القائمة ✓
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2: AI MENU TRANSLATION
         ========================================================================= */}
      {activeTab === 'translator' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl bg-[#11131B] border border-[#212635] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Languages className="w-4 h-4 text-[#D4AF37]" />
                  <span>ترجمة أطباق القائمة بين اللغات</span>
                </h3>
                <p className="text-xs text-[#8E95A8] mt-1">
                  ترجمة أسماء وأوصاف الأطباق والمكونات باحترافية مع الحفاظ الصارم على الأسعار والمعرفات دون مساس
                </p>
              </div>

              {/* Languages selectors */}
              <div className="flex items-center gap-2 text-xs">
                <select
                  value={sourceLang}
                  onChange={e => setSourceLang(e.target.value as any)}
                  className="bg-[#141724] border border-[#262B3D] text-[#F3F4F6] text-xs rounded-lg px-3 py-2"
                >
                  <option value="ar">من: العربية</option>
                  <option value="en">من: الإنجليزية</option>
                  <option value="fr">من: الفرنسية</option>
                </select>

                <ArrowRight className="w-4 h-4 text-[#D4AF37] rotate-180" />

                <select
                  value={targetLang}
                  onChange={e => setTargetLang(e.target.value as any)}
                  className="bg-[#141724] border border-[#262B3D] text-[#F3F4F6] text-xs rounded-lg px-3 py-2"
                >
                  <option value="en">إلى: الإنجليزية</option>
                  <option value="fr">إلى: الفرنسية</option>
                  <option value="ar">إلى: العربية</option>
                </select>

                <Button
                  size="sm"
                  variant="primary"
                  loading={isTranslating}
                  disabled={selectedItemIds.length === 0}
                  onClick={handleTranslate}
                  icon={<Sparkles className="w-3.5 h-3.5" />}
                >
                  {isTranslating ? 'جاري الترجمة...' : '✨ ترجمة بالذكاء الاصطناعي'}
                </Button>
              </div>
            </div>

            {/* Selection bar */}
            <div className="flex items-center justify-between pt-3 border-t border-[#1C202C] text-xs">
              <div className="flex items-center gap-3">
                <button
                  onClick={selectAllItems}
                  className="text-[#D4AF37] hover:underline font-semibold cursor-pointer"
                >
                  {selectedItemIds.length === existingItems.length ? 'إلغاء تحديد الكل' : 'تحديد جميع الأطباق (حد أقصى 15)'}
                </button>
                <span className="text-[#8E95A8]">
                  تم تحديد {selectedItemIds.length} من {existingItems.length}
                </span>
              </div>
              <span className="text-[11px] text-[#6E7587]">
                الترجمة تحافظ على الأسعار كما هي دون تغيير
              </span>
            </div>

            {/* Existing products selector table */}
            <div className="overflow-x-auto max-h-72 divide-y divide-[#1B202D] border border-[#202534] rounded-xl bg-[#0D0F16]">
              {existingItems.map(item => {
                const isSelected = selectedItemIds.includes(item.id);
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      if (isSelected) {
                        setSelectedItemIds(prev => prev.filter(id => id !== item.id));
                      } else {
                        if (selectedItemIds.length >= 15) {
                          toastError('الحد الأقصى للدفعة الواحدة هو 15 صنفاً لضبط التكلفة وسرعة الاستجابة.');
                          return;
                        }
                        setSelectedItemIds(prev => [...prev, item.id]);
                      }
                    }}
                    className={`p-3 flex items-center justify-between cursor-pointer transition-colors text-xs ${
                      isSelected ? 'bg-[#D4AF37]/10' : 'hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => {}}
                        className="rounded border-[#252A38] text-[#D4AF37] focus:ring-[#D4AF37]"
                      />
                      <div>
                        <h5 className="font-bold text-white">{item.name}</h5>
                        {item.description && (
                          <p className="text-[11px] text-[#7E8597] line-clamp-1">{item.description}</p>
                        )}
                      </div>
                    </div>
                    <span className="font-mono text-[#D4AF37] font-semibold whitespace-nowrap">
                      {item.price} {restaurant?.currency || 'DZD'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Translation Preview Modal / Section */}
          {translatedResults && translatedResults.length > 0 && (
            <div className="p-5 rounded-2xl bg-[#11131B] border-2 border-[#D4AF37]/40 space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>معاينة الترجمة قبل الاعتماد والحفظ في قاعدة البيانات</span>
                  </h4>
                  <p className="text-xs text-[#8E95A8] mt-0.5">
                    راجع الترجمات الناتجة، ولن يتم التعديل على القائمة الفعلية حتى تضغط على زر التأكيد.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => setTranslatedResults(null)}
                  >
                    إلغاء المعاينة
                  </Button>
                  <Button
                    size="sm"
                    variant="primary"
                    loading={isSavingTranslations}
                    onClick={handleApplyTranslations}
                    icon={<Save className="w-3.5 h-3.5" />}
                  >
                    اعتماد وحفظ الترجمة في Supabase ✓
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-96 overflow-y-auto">
                {translatedResults.map(tr => {
                  const orig = existingItems.find(it => it.id === tr.id);
                  return (
                    <div key={tr.id} className="p-3 bg-[#151824] rounded-xl border border-[#242A3D] space-y-2 text-xs">
                      <div className="border-b border-[#212738] pb-1.5 flex justify-between items-start">
                        <div>
                          <span className="text-[10px] text-[#7E8597]">الأصل ({sourceLang}):</span>
                          <p className="font-semibold text-white">{orig?.name}</p>
                        </div>
                        <span className="font-mono text-[#D4AF37] font-bold">
                          {orig?.price} {restaurant?.currency}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-[#D4AF37] font-semibold">المترجم ({targetLang}):</span>
                        <p className="font-bold text-white" dir="ltr">{tr.name}</p>
                        {tr.description && (
                          <p className="text-[11px] text-[#A6AFC2] mt-1 leading-relaxed" dir="ltr">
                            {tr.description}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          TAB 3: AI USAGE DASHBOARD (REAL DB DATA)
         ========================================================================= */}
      {activeTab === 'usage' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl bg-[#11131B] border border-[#212635] space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#D4AF37]" />
                <span>سجل استهلاك الذكاء الاصطناعي الفعلي (Real Supabase Metrics)</span>
              </h3>
              <p className="text-xs text-[#8E95A8] mt-1">
                جميع الأرقام محسوبة ومسجلة بدقة من جدول <code className="text-[#D4AF37]">ai_usage</code> في قاعدة بياناتك بدون أرقام وهمية
              </p>
            </div>

            {loadingUsage ? (
              <LoadingSpinner message="جاري احتساب سجل الاستهلاك من Supabase..." />
            ) : usageStats && usageStats.totalRequests > 0 ? (
              <div className="space-y-6">
                {/* Metric Cards */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-4 rounded-xl bg-[#141724] border border-[#23293D]">
                    <span className="text-xs text-[#8E95A8]">إجمالي طلبات AI</span>
                    <p className="text-2xl font-bold text-white font-mono mt-1">
                      {usageStats.totalRequests}
                    </p>
                    <span className="text-[10px] text-[#6E7587]">عملية مسجلة</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#141724] border border-[#23293D]">
                    <span className="text-xs text-[#8E95A8]">توليد الأوصاف</span>
                    <p className="text-2xl font-bold text-[#D4AF37] font-mono mt-1">
                      {usageStats.productDescriptionsCount}
                    </p>
                    <span className="text-[10px] text-[#6E7587]">أطباق تم وصفها</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#141724] border border-[#23293D]">
                    <span className="text-xs text-[#8E95A8]">عمليات الترجمة</span>
                    <p className="text-2xl font-bold text-purple-400 font-mono mt-1">
                      {usageStats.translationsCount}
                    </p>
                    <span className="text-[10px] text-[#6E7587]">دفعات مترجمة</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#141724] border border-[#23293D]">
                    <span className="text-xs text-[#8E95A8]">أسئلة المساعد الذكي</span>
                    <p className="text-2xl font-bold text-blue-400 font-mono mt-1">
                      {usageStats.assistantQueriesCount}
                    </p>
                    <span className="text-[10px] text-[#6E7587]">استفسارات زبائن</span>
                  </div>
                </div>

                {/* Quota Progress */}
                <div className="p-4 rounded-xl bg-[#131622] border border-[#212635] space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">الحصة الشهرية للطلبات (Monthly Quota)</span>
                    <span className="font-mono text-[#D4AF37]">
                      {usageStats.totalRequests} / {usageStats.monthlyQuota} طلب
                    </span>
                  </div>
                  <div className="h-2 w-full bg-[#1A1E2B] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#D4AF37] to-amber-500 rounded-full"
                      style={{
                        width: `${Math.min(100, (usageStats.totalRequests / usageStats.monthlyQuota) * 100)}%`
                      }}
                    />
                  </div>
                  <p className="text-[11px] text-[#7E8597]">
                    يتم تجديد الحصة تلقائياً مع بداية كل دورة اشتراك لحماية التكلفة وتجنب الاستهلاك الزائد.
                  </p>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-[#7E8597] border border-dashed border-[#202534] rounded-xl">
                لا توجد بيانات استخدام حتى الآن.
                <br />
                <span className="text-[11px] text-[#6E7587] mt-1 block">
                  عند توليد أول وصف طبق أو ترجمة أصناف أو استخدام المساعد ستظهر الإحصائيات هنا تلقائياً.
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 4: IMAGE AI ARCHITECTURE (OPTIONAL MODULE)
         ========================================================================= */}
      {activeTab === 'image_enhancer' && (
        <div className="p-6 rounded-2xl bg-[#11131B] border border-[#212635] space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">معالجة وتحسين صور الأطباق (AI Image Architecture)</h3>
              <p className="text-xs text-[#8E95A8]">
                وحدة هيكلية مستقبلية مجهزة لربط خدمات إزالة الخلفية وتحسين جودة صور أطباق المطبخ
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
            <div className="p-4 rounded-xl bg-[#141724] border border-[#23293D] space-y-2">
              <span className="text-xs font-bold text-[#D4AF37]">1. ضغط الصور الفوري (نشط حالياً)</span>
              <p className="text-xs text-[#8E95A8] leading-relaxed">
                يعمل محرك Canvas المحلي في المتصفح حالياً على تحويل الصور وصيانتها إلى WebP بحجم خفيف قبل الرفع للسحابة.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#141724] border border-[#23293D] space-y-2">
              <span className="text-xs font-bold text-purple-400">2. إزالة الخلفيات المعقدة (جاهز للربط)</span>
              <p className="text-xs text-[#8E95A8] leading-relaxed">
                هيكلية Provider معزولة عبر Edge Functions تتيح تمرير صورة الطبق لإزالة خلفية طاولة المطبخ تلقائياً.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#141724] border border-[#23293D] space-y-2">
              <span className="text-xs font-bold text-blue-400">3. تحسين الإضاءة الفندقية</span>
              <p className="text-xs text-[#8E95A8] leading-relaxed">
                إبراز ألوان الأطعمة لتكون شهية ومطابقة لأعلى معايير قوائم الفنادق والمطاعم الراقية.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
