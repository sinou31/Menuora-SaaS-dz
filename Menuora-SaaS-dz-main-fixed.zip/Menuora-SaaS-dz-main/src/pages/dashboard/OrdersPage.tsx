import React, { useEffect, useState, useCallback } from 'react';
import { ShoppingBag, CheckCircle, Clock, ChefHat, Check, X, Phone, User, MessageSquare } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { orderService } from '../../services/orderService';
import { Order, OrderStatus } from '../../types/database.types';
import { useToast } from '../../hooks/useToast';
import { useRealtimeOrders } from '../../hooks/useRealtimeOrders';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import { EmptyState } from '../../components/EmptyState';
import { Modal } from '../../components/Modal';
import { Button } from '../../components/Button';

export const OrdersPage: React.FC = () => {
  const { restaurant } = useAuth();
  const { success, error: toastError } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const fetchOrders = useCallback(async () => {
    if (!restaurant?.id) return;
    try {
      const data = await orderService.getOrders(restaurant.id);
      setOrders(data);
    } catch (err: any) {
      console.error('Failed to load orders:', err);
      toastError('تعذر تحميل الطلبات: ' + (err?.message || 'خطأ غير معروف'));
    } finally {
      setLoading(false);
    }
  }, [restaurant?.id, toastError]);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  // Live updates: re-fetch on new orders (the realtime payload has no joined items)
  // and merge status changes made elsewhere. The dashboard layout already shows the toast.
  useRealtimeOrders({
    restaurantId: restaurant?.id,
    notify: false,
    onNewOrder: () => {
      void fetchOrders();
    },
    onOrderUpdated: (updated) => {
      setOrders(prev =>
        prev.map(o => (o.id === updated.id ? { ...o, ...updated, table: o.table, order_items: o.order_items } : o))
      );
    }
  });

  const handleUpdateStatus = async (orderId: string, newStatus: OrderStatus) => {
    setUpdatingId(orderId);
    try {
      await orderService.updateOrderStatus(orderId, newStatus);
      success('تم تحديث حالة الطلب بنجاح');
      setOrders(prev =>
        prev.map(o => (o.id === orderId ? { ...o, status: newStatus } : o))
      );
      if (selectedOrder?.id === orderId) {
        setSelectedOrder(prev => (prev ? { ...prev, status: newStatus } : null));
      }
    } catch (err: any) {
      toastError(err.message || 'فشل تحديث الحالة');
    } finally {
      setUpdatingId(null);
    }
  };

  const filteredOrders = orders.filter(o => {
    if (statusFilter === 'all') return true;
    return o.status === statusFilter;
  });

  const currency = restaurant?.currency || 'DZD';

  if (loading) {
    return <LoadingSpinner message="جاري استرجاع طلبات المطعم..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header and status tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-white">إدارة الطلبات الحية</h2>
          <p className="text-xs text-[#8E95A8] mt-1">
            متابعة فورية للطلبات الواردة من طاولات المطعم
          </p>
        </div>
        <Button
          size="sm"
          variant="secondary"
          onClick={fetchOrders}
          icon={<Clock className="w-3.5 h-3.5" />}
        >
          تحديث القائمة
        </Button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-[#12141D] rounded-xl border border-[#202534] overflow-x-auto text-xs">
        {[
          { id: 'all', label: 'جميع الطلبات' },
          { id: 'pending', label: 'قيد الانتظار' },
          { id: 'preparing', label: 'جاري التحضير' },
          { id: 'ready', label: 'جاهز للتقديم' },
          { id: 'completed', label: 'مكتمل' },
          { id: 'cancelled', label: 'ملغي' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setStatusFilter(tab.id)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              statusFilter === tab.id
                ? 'bg-[#D4AF37] text-black font-semibold shadow-sm'
                : 'text-[#8E95A8] hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {filteredOrders.length === 0 ? (
        <EmptyState
          icon={<ShoppingBag className="w-6 h-6" />}
          title="لا توجد طلبات في هذا القسم"
          description="ستظهر الطلبات هنا فور إرسال الزبائن طلباتهم عبر رمز الاستجابة السريعة QR الخاص بالطاولات."
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredOrders.map(order => {
            const isUpdating = updatingId === order.id;
            return (
              <div
                key={order.id}
                className="p-5 rounded-2xl bg-[#11131B] border border-[#212635] flex flex-col justify-between hover:border-[#383F54] transition-all"
              >
                <div>
                  {/* Top Bar of card: ID, Table, Status */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <span className="font-mono text-xs text-[#D4AF37] font-semibold">
                        #{order.id.slice(0, 6)}
                      </span>
                      <h4 className="text-sm font-bold text-white mt-0.5">
                        {order.table?.name || (order.table_id ? `طاولة #${order.table_id.slice(0, 4)}` : 'طلب مباشر')}
                      </h4>
                    </div>

                    <div className="text-xs">
                      {order.status === 'pending' && (
                        <span className="text-amber-400 font-medium">قيد الانتظار</span>
                      )}
                      {order.status === 'preparing' && (
                        <span className="text-blue-400 font-medium">جاري التحضير</span>
                      )}
                      {order.status === 'ready' && (
                        <span className="text-purple-400 font-medium">جاهز للتقديم</span>
                      )}
                      {order.status === 'completed' && (
                        <span className="text-emerald-400 font-medium">مكتمل</span>
                      )}
                      {order.status === 'cancelled' && (
                        <span className="text-rose-400 font-medium">ملغي</span>
                      )}
                    </div>
                  </div>

                  {/* Customer details */}
                  <div className="space-y-1 text-xs text-[#8E95A8] py-2 border-y border-[#1A1E2B] my-2">
                    <div className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-[#6E7587]" />
                      <span className="text-white">{order.customer_name || 'عميل'}</span>
                    </div>
                    {order.customer_phone && (
                      <div className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-[#6E7587]" />
                        <span dir="ltr">{order.customer_phone}</span>
                      </div>
                    )}
                    {order.notes && (
                      <div className="flex items-start gap-1.5 text-amber-200/90 bg-amber-950/20 p-2 rounded-lg mt-1">
                        <MessageSquare className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                        <span className="text-[11px] leading-relaxed">{order.notes}</span>
                      </div>
                    )}
                  </div>

                  {/* Summary of Items */}
                  <div className="my-3 space-y-1">
                    {order.order_items?.map((it) => (
                      <div key={it.id} className="flex items-center justify-between text-xs">
                        <span className="text-[#C4C7D5]">
                          {it.quantity}x {it.item_name || 'طبق'}
                        </span>
                        <span className="font-mono text-[#8E95A8]">
                          {(it.price * it.quantity).toFixed(2)} {currency}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer: Total & Status Transition Buttons */}
                <div className="pt-3 border-t border-[#1A1E2B] mt-2">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs text-[#8E95A8]">المجموع الكلي:</span>
                    <span className="text-base font-bold text-white font-mono">
                      {order.total} {currency}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {order.status === 'pending' && (
                      <>
                        <Button
                          size="sm"
                          variant="primary"
                          className="flex-1"
                          loading={isUpdating}
                          onClick={() => handleUpdateStatus(order.id, 'preparing')}
                          icon={<ChefHat className="w-3.5 h-3.5" />}
                        >
                          بدء التحضير
                        </Button>
                        <Button
                          size="sm"
                          variant="danger"
                          loading={isUpdating}
                          onClick={() => handleUpdateStatus(order.id, 'cancelled')}
                          icon={<X className="w-3.5 h-3.5" />}
                        >
                          إلغاء
                        </Button>
                      </>
                    )}

                    {order.status === 'preparing' && (
                      <Button
                        size="sm"
                        variant="primary"
                        className="w-full"
                        loading={isUpdating}
                        onClick={() => handleUpdateStatus(order.id, 'ready')}
                        icon={<Check className="w-3.5 h-3.5" />}
                      >
                        جاهز للتقديم
                      </Button>
                    )}

                    {order.status === 'ready' && (
                      <Button
                        size="sm"
                        variant="primary"
                        className="w-full"
                        loading={isUpdating}
                        onClick={() => handleUpdateStatus(order.id, 'completed')}
                        icon={<CheckCircle className="w-3.5 h-3.5" />}
                      >
                        تسليم الطلب (مكتمل)
                      </Button>
                    )}

                    {(order.status === 'completed' || order.status === 'cancelled') && (
                      <Button
                        size="sm"
                        variant="secondary"
                        className="w-full"
                        onClick={() => setSelectedOrder(order)}
                      >
                        عرض التفاصيل
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Details Modal */}
      {selectedOrder && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedOrder(null)}
          title={`تفاصيل الطلب #${selectedOrder.id.slice(0, 6)}`}
          description={selectedOrder.table?.name || 'طلب طاولة'}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-[#151822] rounded-xl space-y-1.5 border border-[#242938]">
              <div className="flex justify-between">
                <span className="text-[#8E95A8]">العميل:</span>
                <span className="font-semibold text-white">{selectedOrder.customer_name || 'عميل'}</span>
              </div>
              {selectedOrder.customer_phone && (
                <div className="flex justify-between">
                  <span className="text-[#8E95A8]">رقم الهاتف:</span>
                  <span className="font-mono text-white" dir="ltr">{selectedOrder.customer_phone}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-[#8E95A8]">تاريخ الطلب:</span>
                <span className="text-white">
                  {new Date(selectedOrder.created_at).toLocaleString('ar-SA')}
                </span>
              </div>
            </div>

            <div>
              <h5 className="font-bold text-white mb-2">الأطباق المطلوبة:</h5>
              <div className="divide-y divide-[#1F2432] bg-[#12141D] rounded-xl p-3 border border-[#212635]">
                {selectedOrder.order_items?.map(it => (
                  <div key={it.id} className="py-2 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-white">{it.item_name || 'طبق'}</p>
                      <p className="text-[11px] text-[#8E95A8]">الكمية: {it.quantity}</p>
                    </div>
                    <span className="font-mono text-sm text-[#D4AF37]">
                      {(it.price * it.quantity).toFixed(2)} {currency}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-[#1F2432] text-sm">
              <span className="font-bold text-white">إجمالي الحساب:</span>
              <span className="font-bold text-[#D4AF37] font-mono text-base">
                {selectedOrder.total} {currency}
              </span>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
