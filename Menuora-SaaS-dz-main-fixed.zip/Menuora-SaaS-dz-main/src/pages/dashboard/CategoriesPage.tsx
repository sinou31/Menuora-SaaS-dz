import React, { useEffect, useState, useCallback } from 'react';
import { FolderTree, Plus, Edit2, Trash2, ArrowUpDown } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { categoryService } from '../../services/categoryService';
import { Category } from '../../types/database.types';
import { useToast } from '../../hooks/useToast';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import { EmptyState } from '../../components/EmptyState';
import { Modal } from '../../components/Modal';
import { ConfirmDialog } from '../../components/ConfirmDialog';
import { Button } from '../../components/Button';
import { Input } from '../../components/Input';

export const CategoriesPage: React.FC = () => {
  const { restaurant } = useAuth();
  const { success, error: toastError } = useToast();

  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Category | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [sortOrder, setSortOrder] = useState('0');

  const loadCategories = useCallback(async () => {
    if (!restaurant?.id) return;
    try {
      const data = await categoryService.getCategories(restaurant.id);
      setCategories(data);
    } catch (err: any) {
      console.error('Failed to load categories:', err);
    } finally {
      setLoading(false);
    }
  }, [restaurant?.id]);

  useEffect(() => {
    loadCategories();
  }, [loadCategories]);

  const handleOpenAdd = () => {
    setEditingCategory(null);
    setName('');
    setDescription('');
    setSortOrder(String(categories.length + 1));
    setIsModalOpen(true);
  };

  const handleOpenEdit = (cat: Category) => {
    setEditingCategory(cat);
    setName(cat.name);
    setDescription(cat.description || '');
    setSortOrder(String(cat.sort_order));
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!restaurant?.id) return;
    if (!name.trim()) {
      toastError('اسم التصنيف مطلوب');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingCategory) {
        await categoryService.updateCategory(editingCategory.id, {
          name: name.trim(),
          description: description.trim() || null,
          sort_order: parseInt(sortOrder) || 0
        });
        success('تم تحديث التصنيف بنجاح');
      } else {
        await categoryService.createCategory(restaurant.id, {
          name: name.trim(),
          description: description.trim() || null,
          sort_order: parseInt(sortOrder) || 0
        });
        success('تمت إضافة التصنيف بنجاح');
      }
      setIsModalOpen(false);
      await loadCategories();
    } catch (err: any) {
      toastError(err.message || 'فشل حفظ التصنيف');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setIsSubmitting(true);
    try {
      await categoryService.deleteCategory(deleteTarget.id);
      success('تم حذف التصنيف');
      setDeleteTarget(null);
      await loadCategories();
    } catch (err: any) {
      toastError(err.message || 'فشل حذف التصنيف');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleActive = async (cat: Category) => {
    try {
      await categoryService.updateCategory(cat.id, { is_active: !cat.is_active });
      setCategories(prev =>
        prev.map(c => (c.id === cat.id ? { ...c, is_active: !cat.is_active } : c))
      );
      success(cat.is_active ? 'تم تعطيل ظهور التصنيف' : 'تم تفعيل ظهور التصنيف');
    } catch (err: any) {
      toastError(err.message);
    }
  };

  if (loading) {
    return <LoadingSpinner message="جاري استرجاع التصنيفات..." />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-white">إدارة تصنيفات القائمة</h2>
          <p className="text-xs text-[#8E95A8] mt-1">
            تنظيم أطباق المطعم في أقسام ميسرة للزبائن (المقبلات، الأطباق الرئيسية، المشروبات)
          </p>
        </div>
        <Button
          size="sm"
          variant="primary"
          onClick={handleOpenAdd}
          icon={<Plus className="w-4 h-4" />}
        >
          إضافة تصنيف جديد
        </Button>
      </div>

      {categories.length === 0 ? (
        <EmptyState
          icon={<FolderTree className="w-6 h-6" />}
          title="لم تضف أي تصنيفات بعد"
          description="التصنيفات تساعد زبائنك على تصفح قائمة طعامك بسرعة وسهولة."
          actionLabel="+ إضافة أول تصنيف"
          onAction={handleOpenAdd}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {categories.map(cat => (
            <div
              key={cat.id}
              className="p-5 rounded-2xl bg-[#11131B] border border-[#212635] flex flex-col justify-between hover:border-[#383F54] transition-all"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-bold text-white">{cat.name}</h4>
                    <span className="text-[11px] text-[#7E8699] font-mono mt-0.5 inline-block">
                      ترتيب العرض: {cat.sort_order}
                    </span>
                  </div>
                  <button
                    onClick={() => handleToggleActive(cat)}
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded cursor-pointer ${
                      cat.is_active
                        ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/40'
                        : 'bg-neutral-800 text-[#8E95A8]'
                    }`}
                  >
                    {cat.is_active ? 'مفعل بالقائمة' : 'مخفي مؤقتاً'}
                  </button>
                </div>

                {cat.description && (
                  <p className="text-xs text-[#8E95A8] mt-2.5 leading-relaxed line-clamp-2">
                    {cat.description}
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-[#1C202C] mt-4 flex items-center justify-end gap-1.5">
                <button
                  onClick={() => handleOpenEdit(cat)}
                  className="p-1.5 rounded-lg text-[#8E95A8] hover:text-white hover:bg-white/5 border border-[#252A38] cursor-pointer"
                  title="تعديل"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setDeleteTarget(cat)}
                  className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-950/30 border border-rose-900/30 cursor-pointer"
                  title="حذف"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsModalOpen(false)}
          title={editingCategory ? 'تعديل التصنيف' : 'إضافة تصنيف جديد'}
          description="أدخل اسم القسم وترتيب ظهوره للزبائن"
          maxWidth="sm"
        >
          <form onSubmit={handleSave} className="space-y-4">
            <Input
              label="اسم التصنيف"
              required
              placeholder="مثال: المقبلات والمشروبات الساخنة"
              value={name}
              onChange={e => setName(e.target.value)}
            />

            <Input
              label="ترتيب العرض (رقمي)"
              type="number"
              placeholder="1"
              value={sortOrder}
              onChange={e => setSortOrder(e.target.value)}
            />

            <div className="flex flex-col gap-1.5 text-right">
              <label className="text-xs font-semibold text-[#C4C7D5]">نبذة عن التصنيف (اختياري)</label>
              <textarea
                rows={2}
                placeholder="تفاصيل سريعة عن أصناف هذا القسم..."
                value={description}
                onChange={e => setDescription(e.target.value)}
                className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-sm rounded-lg p-3 focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="flex items-center gap-2 pt-3 border-t border-[#1F2432]">
              <Button type="submit" variant="primary" loading={isSubmitting} className="flex-1">
                حفظ التصنيف
              </Button>
              <Button
                type="button"
                variant="secondary"
                onClick={() => setIsModalOpen(false)}
                disabled={isSubmitting}
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete confirmation */}
      {deleteTarget && (
        <ConfirmDialog
          isOpen={true}
          onClose={() => setDeleteTarget(null)}
          onConfirm={handleConfirmDelete}
          title="تأكيد حذف التصنيف"
          message={`هل أنت متأكد من حذف التصنيف "${deleteTarget.name}"؟ لن يتم حذف الأطباق المرتبطة به ولكن ستصبح بدون تصنيف.`}
          confirmLabel="نعم، احذف التصنيف"
          loading={isSubmitting}
        />
      )}
    </div>
  );
};
