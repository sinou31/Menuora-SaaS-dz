import React, { useState } from 'react';
import { User, Lock, Mail, Phone, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { evaluatePasswordStrength } from '../../utils/validators';
import { useToast } from '../../hooks/useToast';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';

export const ProfilePage: React.FC = () => {
  const { user, profile, refreshProfile, updatePassword } = useAuth();
  const { success, error: toastError } = useToast();

  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [phoneNumber, setPhoneNumber] = useState(profile?.phone || '');
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);

  // Password change state
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  const pwdStrength = evaluatePasswordStrength(newPassword);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id || !isSupabaseConfigured) return;

    setIsUpdatingProfile(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: fullName.trim(),
          phone: phoneNumber.trim(),
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (error) throw error;

      await refreshProfile();
      success('تم تحديث بيانات الملف الشخصي بنجاح');
    } catch (err: any) {
      toastError(err.message || 'فشل تحديث الملف الشخصي');
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pwdStrength.score < 2) {
      toastError('يرجى اختيار كلمة مرور أقوى (8 أحرف على الأقل تحتوي أرقام وأحرف)');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      toastError('كلمتا المرور غير متطابقتين');
      return;
    }

    setIsChangingPassword(true);
    try {
      const { error } = await updatePassword(newPassword);
      if (error) throw error;

      success('تم تغيير كلمة المرور بنجاح');
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (err: any) {
      toastError(err.message || 'فشل تغيير كلمة المرور');
    } finally {
      setIsChangingPassword(false);
    }
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-lg md:text-xl font-bold text-white">إعدادات الملف الشخصي والأمان</h2>
        <p className="text-xs text-[#8E95A8] mt-1">
          إدارة اسمك ورقم هاتفك وكلمة مرور حسابك في Supabase
        </p>
      </div>

      {/* Account Info Form */}
      <div className="p-5 rounded-2xl bg-[#11131B] border border-[#212635]">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
          <User className="w-4 h-4 text-[#D4AF37]" />
          <span>المعلومات الشخصية</span>
        </h3>

        <form onSubmit={handleUpdateProfile} className="space-y-4">
          <Input
            label="الاسم الكامل"
            required
            value={fullName}
            onChange={e => setFullName(e.target.value)}
          />

          <div className="flex flex-col gap-1.5 text-right">
            <label className="text-xs font-semibold text-[#C4C7D5]">البريد الإلكتروني الأساسي</label>
            <div className="flex items-center gap-2">
              <input
                disabled
                value={user?.email || ''}
                className="w-full bg-[#0E1016] border border-[#232736] text-[#7E8699] text-sm rounded-lg px-3.5 py-2.5 cursor-not-allowed font-mono"
                dir="ltr"
              />
              <span className="text-[11px] text-[#6E7587] whitespace-nowrap">
                محمي بـ Supabase Auth
              </span>
            </div>
          </div>

          <Input
            label="رقم الهاتف"
            value={phoneNumber}
            onChange={e => setPhoneNumber(e.target.value)}
            placeholder="+966500000000"
            icon={<Phone className="w-4 h-4" />}
          />

          <div className="flex items-center justify-between pt-3 border-t border-[#1F2432]">
            <span className="text-xs text-[#8E95A8]">
              الدور: <strong className="text-white">{profile?.role || 'restaurant_owner'}</strong>
            </span>
            <Button type="submit" variant="primary" size="sm" loading={isUpdatingProfile}>
              تحديث المعلومات
            </Button>
          </div>
        </form>
      </div>

      {/* Password Change Form */}
      <div className="p-5 rounded-2xl bg-[#11131B] border border-[#212635]">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
          <Lock className="w-4 h-4 text-[#D4AF37]" />
          <span>تغيير كلمة المرور</span>
        </h3>

        <form onSubmit={handleChangePassword} className="space-y-4">
          <Input
            label="كلمة المرور الجديدة"
            type="password"
            required
            value={newPassword}
            onChange={e => setNewPassword(e.target.value)}
            placeholder="••••••••"
          />

          {newPassword && (
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-[#8E95A8]">قوة كلمة المرور:</span>
                <span className={`font-semibold ${pwdStrength.color}`}>
                  {pwdStrength.label === 'strong' ? 'قوية' : pwdStrength.label === 'medium' ? 'متوسطة' : 'ضعيفة'}
                </span>
              </div>
              <div className="h-1.5 w-full bg-[#1A1E2B] rounded-full overflow-hidden flex gap-1">
                <div
                  className={`h-full transition-all duration-300 ${
                    pwdStrength.score === 1
                      ? 'w-1/3 bg-rose-500'
                      : pwdStrength.score === 2
                      ? 'w-2/3 bg-amber-500'
                      : 'w-full bg-emerald-500'
                  }`}
                />
              </div>
            </div>
          )}

          <Input
            label="تأكيد كلمة المرور الجديدة"
            type="password"
            required
            value={confirmNewPassword}
            onChange={e => setConfirmNewPassword(e.target.value)}
            placeholder="••••••••"
          />

          <div className="flex justify-end pt-3 border-t border-[#1F2432]">
            <Button
              type="submit"
              variant="secondary"
              size="sm"
              loading={isChangingPassword}
              disabled={!newPassword || !confirmNewPassword}
            >
              تحديث كلمة المرور
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
