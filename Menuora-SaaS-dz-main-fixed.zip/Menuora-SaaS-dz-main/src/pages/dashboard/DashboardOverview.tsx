import React, { useEffect, useState } from 'react';
import {
  ShoppingBag,
  DollarSign,
  UtensilsCrossed,
  FolderTree,
  QrCode,
  Eye,
  Plus,
  ExternalLink,
  Clock,
  ArrowUpRight
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { statsService } from '../../services/statsService';
import { orderService } from '../../services/orderService';
import { DashboardStats, Order } from '../../types/database.types';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import { Button } from '../../components/Button';
import { DashboardTab } from '../../layouts/DashboardLayout';

interface DashboardOverviewProps {
  onNavigateTab: (tab: DashboardTab) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({ onNavigateTab }) => {
  const { restaurant } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    async function loadData() {
      if (!restaurant?.id) {
        setLoading(false);
        return;
      }
      try {
        const [dashStats, orders] = await Promise.all([
          statsService.getDashboardStats(restaurant.id),
          orderService.getOrders(restaurant.id)
        ]);
        if (isMounted) {
          setStats(dashStats);
          setRecentOrders(orders.slice(0, 5));
        }
      } catch (err) {
        console.error('Error loading dashboard overview:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadData();
    return () => {
      isMounted = false;
    };
  }, [restaurant?.id]);

  if (loading) {
    return <LoadingSpinner message="جاري استرجاع بيانات المطعم..." />;
  }

  const currency = restaurant?.currency || 'DZD';

  return (
    <div className="space-y-6">
      {/* Welcome & Quick Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-[#131620] to-[#0F1117] border border-[#222736]">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-white">
            مرحباً بك في {restaurant?.name || 'لوحة تحكم مطعمك'}
          </h2>
          <p className="text-xs text-[#8E95A8] mt-1">
            متابعة حية للطلبات، المنتجات، وزيارات القائمة الرقمية
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            size="sm"
            variant="primary"
            onClick={() => onNavigateTab('menu')}
            icon={<Plus className="w-4 h-4" />}
          >
            إضافة منتج
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => onNavigateTab('tables')}
            icon={<QrCode className="w-4 h-4" />}
          >
            رموز QR للطاولات
          </Button>
        </div>
      </div>

      {/* Real Statistics Metric Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Metric 1 */}
        <div className="p-4 rounded-xl bg-[#11131B] border border-[#1F2432] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#8E95A8] text-xs mb-2">
            <span>طلبات اليوم</span>
            <ShoppingBag className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <span className="text-xl md:text-2xl font-bold text-white font-mono tabular-nums">
            {stats ? stats.todayOrdersCount : 0}
          </span>
          <span className="text-[11px] text-[#6E7587] mt-1">من قاعدة البيانات</span>
        </div>

        {/* Metric 2 */}
        <div className="p-4 rounded-xl bg-[#11131B] border border-[#1F2432] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#8E95A8] text-xs mb-2">
            <span>مبيعات اليوم</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <span className="text-xl md:text-2xl font-bold text-emerald-400 font-mono tabular-nums">
            {stats ? stats.todayRevenue : 0}
            <span className="text-xs font-sans ms-1 text-[#8E95A8]">{currency}</span>
          </span>
          <span className="text-[11px] text-[#6E7587] mt-1">طلبات مؤكدة</span>
        </div>

        {/* Metric 3 */}
        <div className="p-4 rounded-xl bg-[#11131B] border border-[#1F2432] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#8E95A8] text-xs mb-2">
            <span>المنتجات</span>
            <UtensilsCrossed className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <span className="text-xl md:text-2xl font-bold text-white font-mono tabular-nums">
            {stats ? stats.productsCount : 0}
          </span>
          <span className="text-[11px] text-[#6E7587] mt-1">في القائمة</span>
        </div>

        {/* Metric 4 */}
        <div className="p-4 rounded-xl bg-[#11131B] border border-[#1F2432] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#8E95A8] text-xs mb-2">
            <span>التصنيفات</span>
            <FolderTree className="w-4 h-4 text-[#8E95A8]" />
          </div>
          <span className="text-xl md:text-2xl font-bold text-white font-mono tabular-nums">
            {stats ? stats.categoriesCount : 0}
          </span>
          <span className="text-[11px] text-[#6E7587] mt-1">أقسام مفعلة</span>
        </div>

        {/* Metric 5 */}
        <div className="p-4 rounded-xl bg-[#11131B] border border-[#1F2432] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#8E95A8] text-xs mb-2">
            <span>الطاولات</span>
            <QrCode className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <span className="text-xl md:text-2xl font-bold text-white font-mono tabular-nums">
            {stats ? stats.tablesCount : 0}
          </span>
          <span className="text-[11px] text-[#6E7587] mt-1">مع رمز QR</span>
        </div>

        {/* Metric 6 */}
        <div className="p-4 rounded-xl bg-[#11131B] border border-[#1F2432] flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#8E95A8] text-xs mb-2">
            <span>زيارات القائمة</span>
            <Eye className="w-4 h-4 text-blue-400" />
          </div>
          <span className="text-xl md:text-2xl font-bold text-white font-mono tabular-nums">
            {stats ? stats.menuViewsCount : 0}
          </span>
          <span className="text-[11px] text-[#6E7587] mt-1">مسح QR فعلي</span>
        </div>
      </div>

      {/* Recent Orders Section */}
      <div className="p-5 rounded-2xl bg-[#10121A] border border-[#1F2432]">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm md:text-base font-bold text-white">آخر الطلبات المستلمة</h3>
            <p className="text-xs text-[#8E95A8]">طلبات العملاء الحية عبر رموز QR</p>
          </div>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => onNavigateTab('orders')}
            icon={<ArrowUpRight className="w-4 h-4" />}
          >
            عرض جميع الطلبات
          </Button>
        </div>

        {recentOrders.length === 0 ? (
          <div className="text-center py-10 text-xs text-[#7E8699]">
            لا توجد طلبات مسجلة حتى الآن. ستظهر الطلبات هنا فور مسح الزبائن لرمز QR وإرسال طلباتهم.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-[#1F2432] text-[#8E95A8]">
                  <th className="py-2.5 px-3 font-semibold">رقم الطلب</th>
                  <th className="py-2.5 px-3 font-semibold">الطاولة</th>
                  <th className="py-2.5 px-3 font-semibold">العميل</th>
                  <th className="py-2.5 px-3 font-semibold">المبلغ</th>
                  <th className="py-2.5 px-3 font-semibold">الحالة</th>
                  <th className="py-2.5 px-3 font-semibold">الوقت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1E2A]">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-3 px-3 font-mono text-[#D4AF37]">
                      #{order.id.slice(0, 6)}
                    </td>
                    <td className="py-3 px-3">
                      {order.table?.name || (order.table_id ? `طاولة #${order.table_id.slice(0, 4)}` : 'طلب مباشر')}
                    </td>
                    <td className="py-3 px-3 text-[#E0E2EC]">
                      {order.customer_name || 'عميل'}
                    </td>
                    <td className="py-3 px-3 font-mono font-semibold text-white">
                      {order.total} {currency}
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-[11px] font-medium text-[#C4C7D5]">
                        {order.status === 'pending' && 'قيد الانتظار'}
                        {order.status === 'preparing' && 'جاري التحضير'}
                        {order.status === 'ready' && 'جاهز للتقديم'}
                        {order.status === 'completed' && 'مكتمل'}
                        {order.status === 'cancelled' && 'ملغي'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-[#7E8699]">
                      {new Date(order.created_at).toLocaleTimeString('ar-SA', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
