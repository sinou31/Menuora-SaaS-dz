
import React, { useEffect, useState, useCallback } from 'react';
import {
  Plus,
  Search,
  Edit2,
  Copy,
  Trash2,
  Star,
  Eye,
  EyeOff,
  Sparkles,
  Zap
} from 'lucide-react';

import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';
import { menuItemService } from '../../services/menuItemService';
import { categoryService } from '../../services/categoryService';
import { storageService } from '../../services/storageService';
import { aiService } from '../../services/aiService';
import { MenuItem, Category } from '../../types/database.types';
import { useToast } from '../../hooks/useToast';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import { EmptyState } from '../../components/EmptyState';
import { Modal } from '../../components/Modal';
import { ConfirmDialog } from '../../components/ConfirmDialog';
import { Button } from '../../components/Button';
import { Input } from '../../components/Input';
import { ImageUploader } from '../../components/ImageUploader';

export const MenuPage: React.FC = () => {
  const { restaurant, user, loading: authLoading } = useAuth();
  const { success, error: toastError } = useToast();

  const [items, setItems] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [deleteItemTarget, setDeleteItemTarget] = useState<MenuItem | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isAIAssisting, setIsAIAssisting] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category_id: '',
    is_available: true,
    is_featured: false
  });

  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  // Load menu items and categories.
  const loadData = useCallback(async () => {
    if (authLoading) return;

    if (!user) {
      setItems([]);
      setCategories([]);
      setLoadError('لم يتم تسجيل الدخول. سجّل الدخول مجددًا.');
      setLoading(false);
      return;
    }

    if (!restaurant?.id) {
      setItems([]);
      setCategories([]);
      setLoadError(
        'لم يتم العثور على مطعم مرتبط بحسابك. تحقق من تحميل بيانات المطعم ثم أعد المحاولة.'
      );
      setLoading(false);
      console.error('MenuPage: restaurant ID is missing for user', user.id);
      return;
    }

    setLoading(true);
    setLoadError('');

    try {
      const [dbItems, dbCats] = await Promise.all([
        menuItemService.getMenuItems(restaurant.id),
        categoryService.getCategories(restaurant.id)
      ]);

      setItems(dbItems);
      setCategories(dbCats);
    } catch (err: unknown) {
      console.error('Failed to load menu:', err);

      const message =
        err instanceof Error ? err.message : 'خطأ غير معروف';

      setLoadError(message);
      toastError(`تعذر تحميل قائمة الطعام: ${message}`);
    } finally {
      setLoading(false);
    }
  }, [authLoading, user, restaurant?.id, toastError]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  // Reset the product form.
  const resetForm = () => {
    setEditingItem(null);
    setFormData({
      name: '',
      description: '',
      price: '',
      category_id: categories[0]?.id || '',
      is_available: true,
      is_featured: false
    });
    setSelectedFile(null);
  };

  // Generate an AI product description.
  const handleAutoDraftDescription = async () => {
    if (!restaurant?.id) {
      toastError('بيانات المطعم غير محمّلة.');
      return;
    }

    if (!formData.name.trim()) {
      toastError('يرجى كتابة اسم المنتج أولاً لصياغة الوصف المناسب له');
      return;
    }

    setIsAIAssisting(true);

    try {
      const res = await aiService.generateProductDescription({
        restaurantId: restaurant.id,
        productName: formData.name.trim(),
        rawIngredients: formData.description
      });

      setFormData(prev => ({
        ...prev,
        description: res.description
      }));

      success('تمت صياغة الوصف بالذكاء الاصطناعي ✨');
    } catch (err: unknown) {
      toastError(
        err instanceof Error ? err.message : 'فشلت الصياغة التلقائية'
      );
    } finally {
      setIsAIAssisting(false);
    }
  };

  // Open the full product form.
  const handleOpenAdd = () => {
    resetForm();
    setIsEditModalOpen(true);
  };

  // Open the edit form.
  const handleOpenEdit = (item: MenuItem) => {
    setEditingItem(item);

    setFormData({
      name: item.name,
      description: item.description || '',
      price: String(item.price),
      category_id: item.category_id || '',
      is_available: item.is_available,
      is_featured: item.is_featured
    });

    setSelectedFile(null);
    setIsEditModalOpen(true);
  };

  // Validate the product name and price.
  const validateProduct = (): number | null => {
    if (!restaurant?.id) {
      toastError('بيانات المطعم غير محمّلة. أعد تسجيل الدخول.');
      return null;
    }

    if (!formData.name.trim()) {
      toastError('اسم المنتج مطلوب');
      return null;
    }

    if (!formData.price.trim()) {
      toastError('يرجى إدخال سعر المنتج');
      return null;
    }

    const price = Number(formData.price);

    if (!Number.isFinite(price) || price < 0) {
      toastError('يرجى إدخال سعر صحيح');
      return null;
    }

    return price;
  };

  // Quick add product.
  const handleQuickAdd = async (e: React.FormEvent) => {
    e.preventDefault();

    const priceNum = validateProduct();
    if (priceNum === null || !restaurant?.id) return;

    setIsSubmitting(true);

    try {
      let image_url: string | null = null;
      let image_path: string | null = null;

      if (selectedFile) {
        const uploadRes = await storageService.uploadProductImage(
          restaurant.id,
          selectedFile
        );

        image_url = uploadRes.url;
        image_path = uploadRes.path;
      }

      await menuItemService.createMenuItem(restaurant.id, {
        name: formData.name.trim(),
        price: priceNum,
        category_id: formData.category_id || null,
        image_url,
        image_path,
        is_available: true,
        is_featured: false
      });

      success('تمت إضافة المنتج بنجاح ✓');

      setIsQuickAddOpen(false);
      resetForm();

      await loadData();
    } catch (err: unknown) {
      console.error('Quick add product error:', err);
      toastError(
        err instanceof Error ? err.message : 'فشل إضافة المنتج'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Create or update product.
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();

    const priceNum = validateProduct();
    if (priceNum === null || !restaurant?.id) return;

    setIsSubmitting(true);

    try {
      let imageUrl = editingItem?.image_url || null;
      let imagePath = editingItem?.image_path || null;
      let oldImagePathToDelete: string | null = null;

      if (selectedFile) {
        const uploadRes = await storageService.uploadProductImage(
          restaurant.id,
          selectedFile
        );

        oldImagePathToDelete = imagePath;

        imageUrl = uploadRes.url;
        imagePath = uploadRes.path;
      }

      const productData = {
        name: formData.name.trim(),
        description: formData.description.trim() || null,
        price: priceNum,
        category_id: formData.category_id || null,
        image_url: imageUrl,
        image_path: imagePath,
        is_available: formData.is_available,
        is_featured: formData.is_featured
      };

      if (editingItem) {
        await menuItemService.updateMenuItem(
          editingItem.id,
          productData
        );

        // Only now that the database row points to the new image is it safe to
        // remove the previous file (and only if no duplicate still uses it).
        if (oldImagePathToDelete) {
          try {
            const { count } = await supabase
              .from('menu_items')
              .select('id', { count: 'exact', head: true })
              .eq('image_path', oldImagePathToDelete);

            if (!count) {
              await storageService.deleteImage('menu-images', oldImagePathToDelete);
            }
          } catch (imageError) {
            console.warn('Could not delete previous image:', imageError);
          }
        }

        success('تم تحديث بيانات المنتج بنجاح');
      } else {
        await menuItemService.createMenuItem(
          restaurant.id,
          productData
        );

        success('تم حفظ المنتج الجديد بنجاح');
      }

      setIsEditModalOpen(false);
      resetForm();

      await loadData();
    } catch (err: unknown) {
      console.error('Save product error:', err);

      toastError(
        err instanceof Error ? err.message : 'فشل حفظ المنتج'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Toggle availability.
  const handleToggleAvailability = async (item: MenuItem) => {
    try {
      const next = await menuItemService.toggleAvailability(
        item.id,
        item.is_available
      );

      setItems(prev =>
        prev.map(i =>
          i.id === item.id ? { ...i, is_available: next } : i
        )
      );

      success(
        next
          ? 'المنتج الآن متوفر للطلب'
          : 'تم تعطيل توفر المنتج مؤقتاً'
      );
    } catch (err: unknown) {
      console.error('Toggle availability error:', err);
      toastError(
        err instanceof Error ? err.message : 'تعذر تغيير توفر المنتج'
      );
    }
  };

  // Toggle featured status.
  const handleToggleFeatured = async (item: MenuItem) => {
    try {
      const next = await menuItemService.toggleFeatured(
        item.id,
        item.is_featured
      );

      setItems(prev =>
        prev.map(i =>
          i.id === item.id ? { ...i, is_featured: next } : i
        )
      );

      success(
        next
          ? 'تم تمييز المنتج في أعلى القائمة'
          : 'تمت إزالة التمييز عن المنتج'
      );
    } catch (err: unknown) {
      console.error('Toggle featured error:', err);
      toastError(
        err instanceof Error ? err.message : 'تعذر تغيير تمييز المنتج'
      );
    }
  };

  // Duplicate product.
  const handleDuplicate = async (item: MenuItem) => {
    try {
      await menuItemService.duplicateMenuItem(item);

      success('تم تكرار المنتج بنجاح');
      await loadData();
    } catch (err: unknown) {
      console.error('Duplicate product error:', err);
      toastError(
        err instanceof Error ? err.message : 'تعذر تكرار المنتج'
      );
    }
  };

  // Delete product.
  const handleConfirmDelete = async () => {
    if (!deleteItemTarget) return;

    setIsSubmitting(true);

    try {
      await menuItemService.deleteMenuItem(
        deleteItemTarget.id,
        deleteItemTarget.image_path
      );

      success('تم حذف المنتج بنجاح');
      setDeleteItemTarget(null);

      await loadData();
    } catch (err: unknown) {
      console.error('Delete product error:', err);
      toastError(
        err instanceof Error ? err.message : 'تعذر حذف المنتج'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredItems = items.filter(item => {
    const query = searchQuery.toLowerCase();

    const matchesSearch =
      item.name.toLowerCase().includes(query) ||
      (item.description || '').toLowerCase().includes(query);

    const matchesCategory =
      selectedCategory === 'all' ||
      item.category_id === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const currency = restaurant?.currency || 'DZD';

  // Wait for authentication initialization.
  if (authLoading || loading) {
    return (
      <LoadingSpinner message="جاري استرجاع قائمة الأطباق..." />
    );
  }

  // Show a recoverable error instead of an endless spinner.
  if (loadError) {
    return (
      <div className="space-y-4">
        <div className="rounded-xl border border-rose-900/40 bg-[#11131B] p-5">
          <h2 className="text-base font-bold text-white">
            تعذر تحميل قائمة الطعام
          </h2>

          <p className="mt-2 text-sm text-rose-300 break-words">
            {loadError}
          </p>

          <div className="mt-4">
            <Button
              variant="primary"
              onClick={() => void loadData()}
            >
              إعادة المحاولة
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-white">
            إدارة قائمة الطعام والمنتجات
          </h2>

          <p className="text-xs text-[#8E95A8] mt-1">
            إضافة وتعديل الأطباق، الأسعار، الصور وتحديد المنتجات المميزة
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="secondary"
            onClick={() => {
              resetForm();
              setIsQuickAddOpen(true);
            }}
            icon={<Zap className="w-4 h-4 text-[#D4AF37]" />}
          >
            إضافة سريعة
          </Button>

          <Button
            size="sm"
            variant="primary"
            onClick={handleOpenAdd}
            icon={<Plus className="w-4 h-4" />}
          >
            إضافة منتج كامل
          </Button>
        </div>
      </div>

      {/* Search and category filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          <Input
            placeholder="ابحث عن منتج بالاسم أو المكونات..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            icon={<Search className="w-4 h-4" />}
          />
        </div>

        <div className="w-full sm:w-56">
          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-xs md:text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-[#D4AF37]"
          >
            <option value="all">جميع التصنيفات</option>

            {categories.map(category => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Product list */}
      {filteredItems.length === 0 ? (
        <EmptyState
          icon={<Plus className="w-6 h-6" />}
          title={
            items.length === 0
              ? 'لم تضف أي منتجات بعد'
              : 'لا توجد نتائج مطابقة لبحثك'
          }
          description={
            items.length === 0
              ? 'ابدأ ببناء قائمة طعام مطعمك الرقمية الآن عبر إضافة أول طبق أو مشروب.'
              : 'جرّب البحث باسم آخر أو اختر تصنيفاً مختلفاً.'
          }
          actionLabel={
            items.length === 0 ? '+ إضافة أول منتج' : undefined
          }
          onAction={
            items.length === 0 ? handleOpenAdd : undefined
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map(item => {
            const cat = categories.find(
              category => category.id === item.category_id
            );

            return (
              <div
                key={item.id}
                className={`p-4 rounded-2xl bg-[#11131B] border transition-all flex flex-col justify-between ${
                  item.is_available
                    ? 'border-[#212635] hover:border-[#383F54]'
                    : 'border-rose-950/40 opacity-75'
                }`}
              >
                <div>
                  <div className="relative rounded-xl overflow-hidden aspect-video bg-[#171A24] mb-3 flex items-center justify-center">
                    {item.image_url ? (
                      <img
                        src={item.image_url}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        loading="lazy"
                        className="w-full h-full object-cover"
                        onError={e => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    ) : (
                      <div className="text-center p-4">
                        <span className="text-xs text-[#6E7587]">
                          بدون صورة
                        </span>
                      </div>
                    )}

                    {item.is_featured && (
                      <div className="absolute top-2 start-2 bg-[#D4AF37] text-black text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 shadow-md">
                        <Sparkles className="w-3 h-3" />
                        <span>مميز</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-sm font-bold text-white leading-snug">
                        {item.name}
                      </h4>

                      <p className="text-[11px] text-[#8E95A8] mt-0.5">
                        {cat?.name || 'بدون تصنيف'}
                      </p>
                    </div>

                    <span className="font-mono text-sm font-bold text-[#D4AF37] whitespace-nowrap">
                      {item.price} {currency}
                    </span>
                  </div>

                  {item.description && (
                    <p className="text-xs text-[#7E8597] line-clamp-2 mt-2 leading-relaxed">
                      {item.description}
                    </p>
                  )}
                </div>

                <div className="pt-3 border-t border-[#1C202C] mt-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => void handleToggleAvailability(item)}
                      title={
                        item.is_available
                          ? 'تعطيل التوفر'
                          : 'تفعيل التوفر'
                      }
                      className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                        item.is_available
                          ? 'bg-emerald-950/30 text-emerald-300 border-emerald-800/40 hover:bg-emerald-900/50'
                          : 'bg-rose-950/30 text-rose-300 border-rose-800/40 hover:bg-rose-900/50'
                      }`}
                    >
                      {item.is_available ? (
                        <Eye className="w-3.5 h-3.5" />
                      ) : (
                        <EyeOff className="w-3.5 h-3.5" />
                      )}
                    </button>

                    <button
                      onClick={() => void handleToggleFeatured(item)}
                      title={
                        item.is_featured
                          ? 'إلغاء التمييز'
                          : 'جعله مميز'
                      }
                      className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                        item.is_featured
                          ? 'bg-[#D4AF37]/20 text-[#D4AF37] border-[#D4AF37]/40'
                          : 'bg-transparent text-[#6E7587] border-[#252A38] hover:text-white'
                      }`}
                    >
                      <Star className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(item)}
                      className="p-1.5 rounded-lg text-[#8E95A8] hover:text-white hover:bg-white/5 border border-[#252A38] cursor-pointer"
                      title="تعديل المنتج"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => void handleDuplicate(item)}
                      className="p-1.5 rounded-lg text-[#8E95A8] hover:text-white hover:bg-white/5 border border-[#252A38] cursor-pointer"
                      title="نسخ مكرر"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => setDeleteItemTarget(item)}
                      className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-950/30 border border-rose-900/30 cursor-pointer"
                      title="حذف المنتج"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / edit product modal */}
      {isEditModalOpen && (
        <Modal
          isOpen={true}
          onClose={() => {
            if (!isSubmitting) setIsEditModalOpen(false);
          }}
          title={
            editingItem
              ? 'تعديل بيانات المنتج'
              : 'إضافة منتج جديد للقائمة'
          }
          description="أدخل تفاصيل الطبق أو المشروب وصورته لعرضها للزبائن"
          maxWidth="lg"
        >
          <form onSubmit={handleSaveProduct} className="space-y-4">
            <Input
              label="اسم المنتج"
              required
              placeholder="مثال: برجر لحم واغيو كلاسيك"
              value={formData.name}
              onChange={e =>
                setFormData({ ...formData, name: e.target.value })
              }
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Input
                label={`السعر (${currency})`}
                type="number"
                step="0.01"
                min="0"
                required
                placeholder="0.00"
                value={formData.price}
                onChange={e =>
                  setFormData({ ...formData, price: e.target.value })
                }
              />

              <div className="flex flex-col gap-1.5 text-right">
                <label className="text-xs font-semibold text-[#C4C7D5]">
                  التصنيف
                </label>

                <select
                  value={formData.category_id}
                  onChange={e =>
                    setFormData({
                      ...formData,
                      category_id: e.target.value
                    })
                  }
                  className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-sm rounded-lg px-3.5 py-2.5 focus:outline-none focus:border-[#D4AF37]"
                >
                  <option value="">بدون تصنيف</option>

                  {categories.map(category => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex flex-col gap-1.5 text-right">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-[#C4C7D5]">
                  الوصف والمكونات
                </label>

                <button
                  type="button"
                  onClick={() => void handleAutoDraftDescription()}
                  disabled={isAIAssisting}
                  className="text-[11px] font-bold text-[#D4AF37] hover:underline flex items-center gap-1 cursor-pointer disabled:opacity-50"
                >
                  <Sparkles className="w-3 h-3 text-[#D4AF37]" />
                  <span>
                    {isAIAssisting
                      ? 'جاري الصياغة...'
                      : '✨ صياغة بالذكاء الاصطناعي'}
                  </span>
                </button>
              </div>

              <textarea
                rows={3}
                placeholder="وصف شهي للمنتج والمكونات التي يحتوي عليها..."
                value={formData.description}
                onChange={e =>
                  setFormData({
                    ...formData,
                    description: e.target.value
                  })
                }
                className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-sm rounded-lg p-3 focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <ImageUploader
              label="صورة المنتج"
              initialImageUrl={editingItem?.image_url}
              onFileSelect={file => setSelectedFile(file)}
            />

            <div className="flex items-center gap-6 pt-2">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
                <input
                  type="checkbox"
                  checked={formData.is_available}
                  onChange={e =>
                    setFormData({
                      ...formData,
                      is_available: e.target.checked
                    })
                  }
                  className="rounded border-[#252A38] text-[#D4AF37] focus:ring-[#D4AF37]"
                />
                <span>متوفر للطلب في القائمة</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
                <input
                  type="checkbox"
                  checked={formData.is_featured}
                  onChange={e =>
                    setFormData({
                      ...formData,
                      is_featured: e.target.checked
                    })
                  }
                  className="rounded border-[#252A38] text-[#D4AF37] focus:ring-[#D4AF37]"
                />
                <span>منتج مميز (يظهر في المقدمة)</span>
              </label>
            </div>

            <div className="flex items-center gap-2 pt-3 border-t border-[#1F2432]">
              <Button
                type="submit"
                variant="primary"
                loading={isSubmitting}
                className="flex-1"
              >
                {editingItem
                  ? 'حفظ التعديلات'
                  : 'حفظ المنتج الجديد'}
              </Button>

              <Button
                type="button"
                variant="secondary"
                onClick={() => setIsEditModalOpen(false)}
                disabled={isSubmitting}
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Quick add modal */}
      {isQuickAddOpen && (
        <Modal
          isOpen={true}
          onClose={() => {
            if (!isSubmitting) setIsQuickAddOpen(false);
          }}
          title="إضافة منتج سريعة"
          description="أضف المنتجات المتتالية بسرعة بأقل خطوات ممكنة"
          maxWidth="sm"
        >
          <form onSubmit={handleQuickAdd} className="space-y-3.5">
            <Input
              label="اسم المنتج"
              required
              placeholder="مثال: عصير برتقال طازج"
              value={formData.name}
              onChange={e =>
                setFormData({ ...formData, name: e.target.value })
              }
            />

            <Input
              label={`السعر (${currency})`}
              type="number"
              step="0.01"
              min="0"
              required
              placeholder="15.00"
              value={formData.price}
              onChange={e =>
                setFormData({ ...formData, price: e.target.value })
              }
            />

            <div className="flex flex-col gap-1 text-right">
              <label className="text-xs font-semibold text-[#C4C7D5]">
                التصنيف
              </label>

              <select
                value={formData.category_id}
                onChange={e =>
                  setFormData({
                    ...formData,
                    category_id: e.target.value
                  })
                }
                className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="">بدون تصنيف</option>

                {categories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            <ImageUploader
              label="صورة سريعة (اختياري)"
              onFileSelect={file => setSelectedFile(file)}
            />

            <div className="flex items-center gap-2 pt-2 border-t border-[#1F2432]">
              <Button
                type="submit"
                variant="primary"
                loading={isSubmitting}
                className="w-full"
              >
                حفظ المنتج سريعاً ✓
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete confirmation */}
      {deleteItemTarget && (
        <ConfirmDialog
          isOpen={true}
          onClose={() => setDeleteItemTarget(null)}
          onConfirm={handleConfirmDelete}
          title="حذف المنتج من القائمة"
          message={`هل أنت متأكد من حذف المنتج "${deleteItemTarget.name}"؟ سيتم حذف بياناته وصورته من السحابة نهائياً ولا يمكن التراجع.`}
          confirmLabel="نعم، احذف المنتج"
          loading={isSubmitting}
        />
      )}
    </div>
  );
};
