import React from 'react';
import { Check, Star, Zap, Shield } from 'lucide-react';
import { Button } from '../../components/Button';
import { useAuth } from '../../hooks/useAuth';

export const SubscriptionPage: React.FC = () => {
  const { restaurant } = useAuth();

  const plans = [
    {
      id: 'free',
      name: 'الباقة المجانية (Free)',
      target: 'للمطاعم والمقاهي الناشئة',
      price: '0',
      period: 'مجاناً للأبد',
      featured: false,
      features: [
        'قائمة طعام رقمية لـ 20 صنفاً',
        'حتى 5 طاولات برمز QR',
        'استقبال طلبات العملاء المباشرة',
        'تحديثات فورية للأسعار',
        'دعم فني عبر البريد الإلكتروني'
      ],
      current: true
    },
    {
      id: 'pro',
      name: 'باقة المحترفين (Pro)',
      target: 'للمطاعم والمقاهي المتنامية',
      price: '149',
      period: 'ريال / شهرياً',
      featured: true,
      features: [
        'قائمة طعام لعدد غير محدود من الأصناف',
        'حتى 30 طاولة برمز QR مع تخصيص الشعار',
        'لوحة متابعة الطلبات Realtime مع تنبيهات صوتية',
        'تحليلات الزيارات وإحصائيات المبيعات اليومية',
        'رفع وتعديل غير محدود للصور عبر السحابة',
        'دعم ذو أولوية عبر الواتساب'
      ],
      current: false
    },
    {
      id: 'business',
      name: 'باقة الأعمال والسلاسل (Business)',
      target: 'للفروع المتعددة وسلاسل الضيافة',
      price: '349',
      period: 'ريال / شهرياً',
      featured: false,
      features: [
        'كل مزايا باقة Pro بالكامل',
        'طاولات غير محدودة وفروع متعددة',
        'ربط اسم نطاق خاص مخصص (Custom Domain)',
        'تخصيص كامل للألوان وهوية العلامة التجارية',
        'تقارير تفصيلية قابلة للتصدير (Excel & PDF)',
        'مدير حساب مخصص وتدريب لطاقم العمل'
      ],
      current: false
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg md:text-xl font-bold text-white">خطط الاشتراك والترقية</h2>
        <p className="text-xs text-[#8E95A8] mt-1">
          اختر الباقة التي تناسب حجم مطعمك وعدد طاولاتك. جاهزة للتفعيل المباشر مع بوابات الدفع.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {plans.map(p => (
          <div
            key={p.id}
            className={`p-6 rounded-2xl flex flex-col justify-between transition-all ${
              p.featured
                ? 'bg-[#141724] border-2 border-[#D4AF37] shadow-[0_0_25px_rgba(212,175,55,0.1)]'
                : 'bg-[#11131B] border border-[#212635]'
            }`}
          >
            <div>
              {p.featured && (
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#D4AF37] text-black text-[11px] font-bold mb-3">
                  <Star className="w-3.5 h-3.5 fill-black" />
                  <span>الأكثر اختياراً للمطاعم</span>
                </div>
              )}

              <h3 className="text-base font-bold text-white">{p.name}</h3>
              <p className="text-xs text-[#8E95A8] mt-1">{p.target}</p>

              <div className="my-5 pb-5 border-b border-[#202534] flex items-baseline gap-1.5">
                <span className="text-3xl font-black text-white font-mono">{p.price}</span>
                <span className="text-xs text-[#8E95A8]">{p.period}</span>
              </div>

              <ul className="space-y-3 text-xs">
                {p.features.map((feat, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-[#C4C7D5]">
                    <Check className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-6 mt-6 border-t border-[#1C202C]">
              {p.current ? (
                <div className="w-full py-2.5 rounded-xl text-center text-xs font-semibold bg-[#1D212E] text-[#8E95A8] border border-[#2B3144]">
                  باقتك الحالية
                </div>
              ) : (
                <Button
                  variant={p.featured ? 'primary' : 'outline'}
                  size="sm"
                  className="w-full"
                  onClick={() => alert('بوابة الدفع الإلكتروني ستكون متاحة قريباً في التحديث القادم.')}
                >
                  الترقية إلى {p.name.split(' ')[0]}
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
