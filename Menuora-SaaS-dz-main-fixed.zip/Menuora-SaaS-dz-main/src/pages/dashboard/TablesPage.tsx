import React, { useEffect, useState, useCallback } from 'react';
import {
  QrCode,
  Plus,
  Download,
  Printer,
  Copy,
  Check,
  Trash2,
  Edit2,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { tableService } from '../../services/tableService';
import { Table } from '../../types/database.types';
import { generateQRDataUrl, downloadQRImage } from '../../lib/qr';
import { useToast } from '../../hooks/useToast';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import { EmptyState } from '../../components/EmptyState';
import { Modal } from '../../components/Modal';
import { ConfirmDialog } from '../../components/ConfirmDialog';
import { Button } from '../../components/Button';
import { Input } from '../../components/Input';

export const TablesPage: React.FC = () => {
  const { restaurant } = useAuth();
  const { success, error: toastError } = useToast();

  const [tables, setTables] = useState<Table[]>([]);
  const [loading, setLoading] = useState(true);

  // Modals state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [qrModalTable, setQrModalTable] = useState<Table | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [editingTable, setEditingTable] = useState<Table | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Table | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Print state
  const [printTable, setPrintTable] = useState<{ table: Table; qrUrl: string } | null>(null);

  // Form
  const [name, setName] = useState('');
  const [number, setNumber] = useState('');

  const loadTables = useCallback(async () => {
    if (!restaurant?.id) return;
    try {
      const data = await tableService.getTables(restaurant.id);
      setTables(data);
    } catch (err: any) {
      console.error('Failed to load tables:', err);
    } finally {
      setLoading(false);
    }
  }, [restaurant?.id]);

  useEffect(() => {
    loadTables();
  }, [loadTables]);

  const getTableMenuUrl = (table: Table) => {
    const origin = window.location.origin;
    const slug = restaurant?.slug || 'menu';
    return `${origin}/#/menu/${slug}?table=${table.slug}`;
  };

  const handleOpenAdd = () => {
    setEditingTable(null);
    setName(`طاولة ${tables.length + 1}`);
    setNumber(String(tables.length + 1));
    setIsModalOpen(true);
  };

  const handleOpenEdit = (t: Table) => {
    setEditingTable(t);
    setName(t.name);
    setNumber(t.number);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!restaurant?.id) return;
    if (!name.trim() || !number.trim()) {
      toastError('يرجى كتابة اسم ورقم الطاولة');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingTable) {
        await tableService.updateTable(editingTable.id, {
          name: name.trim(),
          number: number.trim()
        });
        success('تم تحديث بيانات الطاولة');
      } else {
        await tableService.createTable(restaurant.id, {
          name: name.trim(),
          number: number.trim()
        });
        success('تم إنشاء الطاولة بنجاح');
      }
      setIsModalOpen(false);
      await loadTables();
    } catch (err: any) {
      toastError(err.message || 'فشل حفظ الطاولة');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setIsSubmitting(true);
    try {
      await tableService.deleteTable(deleteTarget.id);
      success('تم حذف الطاولة');
      setDeleteTarget(null);
      await loadTables();
    } catch (err: any) {
      toastError(err.message || 'فشل حذف الطاولة');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleViewQR = async (t: Table) => {
    setQrDataUrl(null); // never show the previous table's QR while generating
    setQrModalTable(t);
    const url = getTableMenuUrl(t);
    try {
      const qr = await generateQRDataUrl(url, {
        width: 700,
        margin: 2
      });
      setQrDataUrl(qr);
    } catch (err) {
      toastError('فشل إنشاء رمز QR');
    }
  };

  const handleDownloadQR = async (t: Table) => {
    const url = getTableMenuUrl(t);
    try {
      const qr = await generateQRDataUrl(url, { width: 800, margin: 2 });
      downloadQRImage(qr, `${restaurant?.name || 'restaurant'}-table-${t.number}-qr`);
      success('تم بدء تحميل صورة رمز QR');
    } catch (err) {
      toastError('فشل تحميل الرمز');
    }
  };

  const handlePrintQR = async (t: Table) => {
    const url = getTableMenuUrl(t);
    try {
      const qr = await generateQRDataUrl(url, { width: 600, margin: 1 });
      setPrintTable({ table: t, qrUrl: qr });
      setTimeout(() => {
        window.print();
      }, 300);
    } catch (err) {
      toastError('تعذر تجهيز بطاقة الطباعة');
    }
  };

  const handleCopyUrl = (t: Table) => {
    const url = getTableMenuUrl(t);
    navigator.clipboard
      .writeText(url)
      .then(() => {
        setCopiedId(t.id);
        success('تم نسخ رابط قائمة الطاولة إلى الحافظة');
        setTimeout(() => setCopiedId(null), 2500);
      })
      .catch(() => toastError('تعذر النسخ تلقائياً، انسخ الرابط يدوياً'));
  };

  if (loading) {
    return <LoadingSpinner message="جاري استرجاع طاولات المطعم..." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-white">إدارة الطاولات ورموز QR</h2>
          <p className="text-xs text-[#8E95A8] mt-1">
            إنشاء رموز QR مخصصة لكل طاولة، تحميلها وطباعتها لوضعها على الطاولات
          </p>
        </div>
        <Button
          size="sm"
          variant="primary"
          onClick={handleOpenAdd}
          icon={<Plus className="w-4 h-4" />}
        >
          إضافة طاولة جديدة
        </Button>
      </div>

      {tables.length === 0 ? (
        <EmptyState
          icon={<QrCode className="w-6 h-6" />}
          title="لم تقم بإضافة أي طاولات حتى الآن"
          description="أضف أرقام طاولات مطعمك لإنشاء رموز QR ذكية تتيح للزبائن تصفح القائمة والطلب مباشرة."
          actionLabel="+ إضافة أول طاولة"
          onAction={handleOpenAdd}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tables.map(table => {
            const isCopied = copiedId === table.id;
            return (
              <div
                key={table.id}
                className="p-5 rounded-2xl bg-[#11131B] border border-[#212635] flex flex-col justify-between hover:border-[#383F54] transition-all"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center font-bold font-mono text-[#D4AF37] text-base">
                        #{table.number}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{table.name}</h4>
                        <span className="text-[11px] text-[#7E8699] font-mono">
                          {table.slug}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(table)}
                        className="p-1.5 rounded-lg text-[#8E95A8] hover:text-white hover:bg-white/5 border border-[#252A38] cursor-pointer"
                        title="تعديل"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(table)}
                        className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-950/30 border border-rose-900/30 cursor-pointer"
                        title="حذف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-[#8E95A8] mb-4">
                    رابط مباشر يربط طلبات الزبون بهذه الطاولة فوراً
                  </p>
                </div>

                <div className="pt-3 border-t border-[#1C202C] space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      size="sm"
                      variant="primary"
                      onClick={() => handleViewQR(table)}
                      icon={<QrCode className="w-3.5 h-3.5" />}
                    >
                      معاينة الرمز
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => handleDownloadQR(table)}
                      icon={<Download className="w-3.5 h-3.5" />}
                    >
                      تحميل PNG
                    </Button>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handlePrintQR(table)}
                      icon={<Printer className="w-3.5 h-3.5" />}
                    >
                      طباعة كارت
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleCopyUrl(table)}
                      icon={isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    >
                      {isCopied ? 'تم النسخ' : 'نسخ الرابط'}
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Table Modal */}
      {isModalOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsModalOpen(false)}
          title={editingTable ? 'تعديل بيانات الطاولة' : 'إضافة طاولة جديدة'}
          description="حدد اسم ورقم الطاولة لتوليد رمز الـ QR الخاص بها"
          maxWidth="sm"
        >
          <form onSubmit={handleSave} className="space-y-4">
            <Input
              label="اسم الطاولة"
              required
              placeholder="مثال: طاولة الصالة الرئيسية 1"
              value={name}
              onChange={e => setName(e.target.value)}
            />

            <Input
              label="رقم الطاولة (فريد)"
              required
              placeholder="1"
              value={number}
              onChange={e => setNumber(e.target.value)}
            />

            <div className="flex items-center gap-2 pt-3 border-t border-[#1F2432]">
              <Button type="submit" variant="primary" loading={isSubmitting} className="flex-1">
                حفظ الطاولة
              </Button>
              <Button
                type="button"
                variant="secondary"
                onClick={() => setIsModalOpen(false)}
                disabled={isSubmitting}
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* QR Preview Modal */}
      {qrModalTable && qrDataUrl && (
        <Modal
          isOpen={true}
          onClose={() => setQrModalTable(null)}
          title={`رمز QR لـ ${qrModalTable.name}`}
          description={`رقم الطاولة: #${qrModalTable.number}`}
          maxWidth="sm"
        >
          <div className="flex flex-col items-center gap-4 text-center">
            <div className="p-4 bg-white rounded-2xl shadow-xl">
              <img
                src={qrDataUrl}
                alt={`QR ${qrModalTable.name}`}
                className="w-56 h-56 object-contain"
              />
            </div>
            <p className="text-xs text-[#8E95A8] max-w-xs">
              امسح الكود بكاميرا هاتفك أو حمّله لطباعته ووضعه على الطاولة
            </p>

            <div className="flex items-center gap-2 w-full pt-2">
              <Button
                size="sm"
                variant="primary"
                onClick={() => handleDownloadQR(qrModalTable)}
                icon={<Download className="w-3.5 h-3.5" />}
                className="flex-1"
              >
                تحميل الصورة
              </Button>
              <Button
                size="sm"
                variant="secondary"
                onClick={() => handlePrintQR(qrModalTable)}
                icon={<Printer className="w-3.5 h-3.5" />}
                className="flex-1"
              >
                طباعة الكارت
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Delete Confirmation */}
      {deleteTarget && (
        <ConfirmDialog
          isOpen={true}
          onClose={() => setDeleteTarget(null)}
          onConfirm={handleConfirmDelete}
          title="تأكيد حذف الطاولة"
          message={`هل أنت متأكد من حذف ${deleteTarget.name}؟ لن يتمكن الزبائن من مسح رمز QR الخاص بها مستقبلاً.`}
          confirmLabel="نعم، احذف الطاولة"
          loading={isSubmitting}
        />
      )}

      {/* Print area rendered outside viewport, revealed only during @media print */}
      {printTable && (
        <div id="qr-print-area" className="hidden print:block text-black text-center p-8">
          <div style={{ border: '2px dashed #000', borderRadius: '16px', padding: '24px', maxWidth: '380px', margin: '0 auto' }}>
            <h2 style={{ fontSize: '20px', fontWeight: 'bold', margin: '0 0 6px 0' }}>
              {restaurant?.name || 'مطعمنا'}
            </h2>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: '0 0 16px 0', color: '#333' }}>
              {printTable.table.name} (#{printTable.table.number})
            </h3>

            <div style={{ display: 'inline-block', padding: '8px', background: '#fff', border: '1px solid #ddd' }}>
              <img
                src={printTable.qrUrl}
                alt="Table QR"
                style={{ width: '220px', height: '220px', display: 'block' }}
              />
            </div>

            <p style={{ fontSize: '13px', marginTop: '14px', marginBottom: '4px', fontWeight: 'bold' }}>
              امسح الرمز بكاميرا هاتفك للطلب مباشرة
            </p>
            <p style={{ fontSize: '10px', color: '#666', margin: 0 }}>
              مدعوم بنظام Restaurant QR SaaS
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
