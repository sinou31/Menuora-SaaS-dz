import React, { useEffect, useState, useCallback } from 'react';
import { ShieldCheck, CheckCircle2, XCircle, AlertTriangle, RefreshCw, Store } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { restaurantService } from '../../services/restaurantService';
import { Restaurant, RestaurantStatus } from '../../types/database.types';
import { useToast } from '../../hooks/useToast';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import { Button } from '../../components/Button';

export const AdminDashboardPage: React.FC = () => {
  const { profile } = useAuth();
  const { success, error: toastError } = useToast();

  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const isSuperAdmin = profile?.role === 'super_admin';

  const loadAllRestaurants = useCallback(async () => {
    try {
      const data = await restaurantService.getAllRestaurantsAdmin();
      setRestaurants(data);
    } catch (err: any) {
      console.error('Failed to load restaurants:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isSuperAdmin) {
      loadAllRestaurants();
    } else {
      setLoading(false);
    }
  }, [isSuperAdmin, loadAllRestaurants]);

  const handleUpdateStatus = async (restaurantId: string, status: RestaurantStatus) => {
    setUpdatingId(restaurantId);
    try {
      await restaurantService.updateRestaurantStatusAdmin(restaurantId, status);
      success(`تم تحديث حالة المطعم إلى ${status}`);
      setRestaurants(prev =>
        prev.map(r => (r.id === restaurantId ? { ...r, status } : r))
      );
    } catch (err: any) {
      toastError(err.message || 'فشل تحديث الحالة');
    } finally {
      setUpdatingId(null);
    }
  };

  if (!isSuperAdmin) {
    return (
      <div className="p-8 text-center bg-[#141013] border border-rose-900/40 rounded-2xl max-w-lg mx-auto my-12">
        <ShieldCheck className="w-12 h-12 text-rose-400 mx-auto mb-3" />
        <h3 className="text-base font-bold text-white">غير مصرح بالدخول</h3>
        <p className="text-xs text-[#8E95A8] mt-2 leading-relaxed">
          هذه الصفحة مخصصة للمشرف العام فقط (Super Admin). حسابك مسجل بدور{' '}
          <strong className="text-white">{profile?.role || 'مستخدم عادي'}</strong>.
        </p>
      </div>
    );
  }

  if (loading) {
    return <LoadingSpinner message="جاري استرجاع قائمة مطاعم المنصة..." />;
  }

  const approvedCount = restaurants.filter(r => r.status === 'approved').length;
  const pendingCount = restaurants.filter(r => r.status === 'pending').length;
  const suspendedCount = restaurants.filter(r => r.status === 'suspended').length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#D4AF37]" />
            <span>لوحة الإدارة العامة للمنصة (Super Admin)</span>
          </h2>
          <p className="text-xs text-[#8E95A8] mt-1">
            إدارة طلبات تسجيل المطاعم الجديدة، الاعتماد، والتعليق من قاعدة البيانات الحقيقية
          </p>
        </div>
        <Button
          size="sm"
          variant="secondary"
          onClick={loadAllRestaurants}
          icon={<RefreshCw className="w-3.5 h-3.5" />}
        >
          تحديث السجل
        </Button>
      </div>

      {/* Stats summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-xl bg-[#11131B] border border-[#212635]">
          <span className="text-xs text-[#8E95A8]">المطاعم المعتمدة والنشطة</span>
          <p className="text-2xl font-bold text-emerald-400 font-mono mt-1">{approvedCount}</p>
        </div>
        <div className="p-4 rounded-xl bg-[#11131B] border border-[#212635]">
          <span className="text-xs text-[#8E95A8]">طلبات قيد المراجعة</span>
          <p className="text-2xl font-bold text-amber-400 font-mono mt-1">{pendingCount}</p>
        </div>
        <div className="p-4 rounded-xl bg-[#11131B] border border-[#212635]">
          <span className="text-xs text-[#8E95A8]">مطاعم معلقة</span>
          <p className="text-2xl font-bold text-rose-400 font-mono mt-1">{suspendedCount}</p>
        </div>
      </div>

      {/* Restaurants Table */}
      <div className="p-5 rounded-2xl bg-[#11131B] border border-[#212635] overflow-x-auto">
        <table className="w-full text-right text-xs">
          <thead>
            <tr className="border-b border-[#202534] text-[#8E95A8]">
              <th className="py-3 px-3 font-semibold">المطعم</th>
              <th className="py-3 px-3 font-semibold">المدينة</th>
              <th className="py-3 px-3 font-semibold">المعرف الفريد (Slug)</th>
              <th className="py-3 px-3 font-semibold">الحالة</th>
              <th className="py-3 px-3 font-semibold">تاريخ التسجيل</th>
              <th className="py-3 px-3 font-semibold text-center">إجراءات المشرف</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1B202D]">
            {restaurants.map(rest => {
              const isUpdating = updatingId === rest.id;
              return (
                <tr key={rest.id} className="hover:bg-white/5 transition-colors">
                  <td className="py-3 px-3 font-semibold text-white">
                    <div className="flex items-center gap-2">
                      <Store className="w-4 h-4 text-[#D4AF37]" />
                      <span>{rest.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-[#C4C7D5]">{rest.city || '—'}</td>
                  <td className="py-3 px-3 font-mono text-[#D4AF37]">{rest.slug}</td>
                  <td className="py-3 px-3">
                    <span className="text-[11px] font-medium text-[#C4C7D5]">
                      {rest.status === 'approved' && 'معتمد'}
                      {rest.status === 'pending' && 'قيد المراجعة'}
                      {rest.status === 'suspended' && 'معلق'}
                      {rest.status === 'rejected' && 'مرفوض'}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-[#7E8699]">
                    {new Date(rest.created_at).toLocaleDateString('ar-SA')}
                  </td>
                  <td className="py-3 px-3">
                    <div className="flex items-center justify-center gap-1.5">
                      {rest.status !== 'approved' && (
                        <Button
                          size="sm"
                          variant="primary"
                          loading={isUpdating}
                          onClick={() => handleUpdateStatus(rest.id, 'approved')}
                          className="text-[11px] py-1 px-2.5 h-auto"
                        >
                          اعتماد
                        </Button>
                      )}
                      {rest.status !== 'suspended' && (
                        <Button
                          size="sm"
                          variant="danger"
                          loading={isUpdating}
                          onClick={() => handleUpdateStatus(rest.id, 'suspended')}
                          className="text-[11px] py-1 px-2.5 h-auto"
                        >
                          تعليق
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
