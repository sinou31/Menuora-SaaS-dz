import React, { useEffect, useState, useMemo } from 'react';
import {
  Search,
  ShoppingBag,
  Plus,
  Minus,
  Trash2,
  Clock,
  MapPin,
  Phone,
  Sparkles,
  CheckCircle2,
  Utensils,
  X,
  MessageSquare
} from 'lucide-react';
import { restaurantService } from '../../services/restaurantService';
import { categoryService } from '../../services/categoryService';
import { menuItemService } from '../../services/menuItemService';
import { tableService } from '../../services/tableService';
import { orderService } from '../../services/orderService';
import { statsService } from '../../services/statsService';
import { Restaurant, Category, MenuItem, Table } from '../../types/database.types';
import { LoadingSpinner } from '../../components/LoadingSpinner';
import { Button } from '../../components/Button';
import { Input } from '../../components/Input';
import { Modal } from '../../components/Modal';
import { AIMenuAssistantWidget } from '../../components/AIMenuAssistantWidget';
import { useToast } from '../../hooks/useToast';

interface CartItem {
  item: MenuItem;
  quantity: number;
}

interface PublicMenuPageProps {
  slug: string;
  tableSlug?: string;
  onNavigateLanding?: () => void;
}

export const PublicMenuPage: React.FC<PublicMenuPageProps> = ({
  slug,
  tableSlug,
  onNavigateLanding
}) => {
  const { error: toastError } = useToast();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [table, setTable] = useState<Table | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Filter
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Cart
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Customer order submission
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);
  const [completedOrderId, setCompletedOrderId] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    async function loadMenuData() {
      try {
        const rest = await restaurantService.getRestaurantBySlug(slug);
        if (!rest) {
          if (mounted) setErrorMsg('المطعم المطلوب غير موجود أو في انتظار المراجعة والاعتماد.');
          return;
        }

        if (mounted) setRestaurant(rest);

        // Fetch categories & available items in parallel
        const [cats, menu, tables] = await Promise.all([
          categoryService.getActiveCategories(rest.id),
          menuItemService.getPublicMenuItems(rest.id),
          tableService.getTables(rest.id)
        ]);

        if (mounted) {
          setCategories(cats);
          setItems(menu);

          // Find table if tableSlug given
          let matchedTable: Table | null = null;
          if (tableSlug) {
            matchedTable = tables.find(t => t.slug === tableSlug) || null;
            setTable(matchedTable);
          }

          // Non-blocking telemetry view record
          statsService.recordMenuView(rest.id, matchedTable?.id || null);
        }
      } catch (err: any) {
        if (mounted) setErrorMsg(err.message || 'فشل تحميل القائمة');
      } finally {
        if (mounted) setLoading(false);
      }
    }

    loadMenuData();
    return () => {
      mounted = false;
    };
  }, [slug, tableSlug]);

  // Cart operations
  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.item.id === item.id);
      if (existing) {
        return prev.map(c =>
          c.item.id === item.id ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      return [...prev, { item, quantity: 1 }];
    });
  };

  const updateQuantity = (itemId: string, delta: number) => {
    setCart(prev =>
      prev
        .map(c => {
          if (c.item.id === itemId) {
            const nextQty = c.quantity + delta;
            return nextQty > 0 ? { ...c, quantity: nextQty } : null;
          }
          return c;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const cartTotal = useMemo(() => {
    return cart.reduce((sum, c) => sum + c.item.price * c.quantity, 0);
  }, [cart]);

  const cartItemsCount = useMemo(() => {
    return cart.reduce((sum, c) => sum + c.quantity, 0);
  }, [cart]);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!restaurant?.id) return;
    if (cart.length === 0) return;

    setIsSubmittingOrder(true);
    try {
      const order = await orderService.createCustomerOrder({
        restaurantId: restaurant.id,
        tableId: table?.id || null,
        customerName: customerName || (table ? `عميل طاولة #${table.number}` : 'عميل القائمة'),
        customerPhone: customerPhone,
        notes: orderNotes,
        cart: cart.map(c => ({
          menuItemId: c.item.id,
          quantity: c.quantity
        }))
      });

      setCompletedOrderId(order.id);
      setCart([]);
      setIsCartOpen(false);
    } catch (err: any) {
      toastError(err.message || 'فشل إرسال الطلب');
    } finally {
      setIsSubmittingOrder(false);
    }
  };

  if (loading) {
    return <LoadingSpinner message="جاري تجهيز قائمة طعام المطعم..." fullScreen />;
  }

  if (errorMsg || !restaurant) {
    return (
      <div className="min-h-screen bg-[#0B0C10] text-[#E0E2EC] flex flex-col items-center justify-center p-6 text-center">
        <div className="p-8 max-w-md bg-[#11131B] border border-[#212635] rounded-3xl">
          <Utensils className="w-12 h-12 text-[#D4AF37] mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">القائمة غير متاحة</h2>
          <p className="text-xs text-[#8E95A8] leading-relaxed mb-6">
            {errorMsg || 'المطعم المطلوب غير متاح حالياً.'}
          </p>
          {onNavigateLanding && (
            <Button variant="secondary" onClick={onNavigateLanding}>
              العودة للرئيسية
            </Button>
          )}
        </div>
      </div>
    );
  }

  const currency = restaurant.currency || 'DZD';

  const filteredItems = items.filter(item => {
    const matchesCat = selectedCategory === 'all' || item.category_id === selectedCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const featuredItems = items.filter(i => i.is_featured);

  return (
    <div className="min-h-screen bg-[#0B0C10] text-[#E0E2EC] pb-24 selection:bg-[#D4AF37]/30">
      {/* Cover Banner */}
      <div className="relative h-44 sm:h-64 w-full bg-[#151824] overflow-hidden">
        {restaurant.cover_url ? (
          <img
            src={restaurant.cover_url}
            alt={restaurant.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-b from-[#181C28] to-[#0B0C10]" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10] via-black/40 to-transparent" />
      </div>

      {/* Restaurant Header Info Container */}
      <div className="max-w-4xl mx-auto px-4 -mt-16 sm:-mt-20 relative z-10">
        <div className="bg-[#11131C] border border-[#222738] rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-5 text-center sm:text-right">
          {/* Logo Frame */}
          <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-[#1A1E2B] border-2 border-[#D4AF37]/40 overflow-hidden shrink-0 shadow-lg flex items-center justify-center">
            {restaurant.logo_url ? (
              <img
                src={restaurant.logo_url}
                alt={restaurant.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            ) : (
              <span className="font-bold text-[#D4AF37] text-2xl font-mono">
                {restaurant.name.slice(0, 2)}
              </span>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white">{restaurant.name}</h1>
              {table && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#D4AF37] text-xs font-bold self-center sm:self-auto">
                  <span>طلب مباشر من:</span>
                  <span className="font-mono">{table.name} (#{table.number})</span>
                </div>
              )}
            </div>

            {restaurant.description && (
              <p className="text-xs text-[#8E95A8] mt-2 leading-relaxed">
                {restaurant.description}
              </p>
            )}

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mt-3 text-xs text-[#7E8699]">
              {restaurant.city && (
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>{restaurant.city} {restaurant.address ? `· ${restaurant.address}` : ''}</span>
                </span>
              )}
              {restaurant.phone && (
                <span className="flex items-center gap-1" dir="ltr">
                  <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>{restaurant.phone}</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mt-5">
          <Input
            placeholder="ابحث عن أطباقك ومشروباتك المفضلة..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            icon={<Search className="w-4 h-4" />}
          />
        </div>

        {/* Categories Horizontal Scrolling Filter */}
        <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 rounded-xl font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#D4AF37] text-black font-bold shadow-md'
                : 'bg-[#131622] text-[#8E95A8] hover:text-white border border-[#232838]'
            }`}
          >
            جميع الأطباق ({items.length})
          </button>
          {categories.map(cat => {
            const count = items.filter(i => i.category_id === cat.id).length;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-[#D4AF37] text-black font-bold shadow-md'
                    : 'bg-[#131622] text-[#8E95A8] hover:text-white border border-[#232838]'
                }`}
              >
                {cat.name} ({count})
              </button>
            );
          })}
        </div>

        {/* Featured Items Carousel / Row if available */}
        {selectedCategory === 'all' && !searchQuery && featuredItems.length > 0 && (
          <div className="mt-8">
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5 mb-3">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>أطباق مختارة ومميزة</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {featuredItems.map(item => (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl bg-[#131622] border border-[#D4AF37]/30 flex gap-3 items-center hover:border-[#D4AF37] transition-all"
                >
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-[#1A1E2B] shrink-0">
                    {item.image_url ? (
                      <img
                        src={item.image_url}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        loading="lazy"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[10px] text-[#6E7587]">
                        بدون صورة
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-white truncate">{item.name}</h4>
                    <span className="font-mono text-xs font-bold text-[#D4AF37]">
                      {item.price} {currency}
                    </span>
                    <button
                      onClick={() => addToCart(item)}
                      className="mt-2 flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#D4AF37] text-black text-[11px] font-bold hover:bg-[#e0be4d] cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>إضافة</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Main Dishes Grid */}
        <div className="mt-8">
          <h3 className="text-sm font-bold text-white mb-3">
            {selectedCategory === 'all' ? 'قائمة الطعام' : categories.find(c => c.id === selectedCategory)?.name}
          </h3>

          {filteredItems.length === 0 ? (
            <div className="text-center py-12 bg-[#10121A] rounded-2xl border border-[#212635] text-xs text-[#7E8699]">
              لا توجد أطباق متاحة حالياً في هذا القسم.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredItems.map(item => {
                const inCart = cart.find(c => c.item.id === item.id);
                return (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl bg-[#11131B] border border-[#212635] hover:border-[#383F54] transition-all flex flex-col justify-between"
                  >
                    <div>
                      {/* Image Frame */}
                      <div className="relative rounded-xl overflow-hidden aspect-video bg-[#171A24] mb-3">
                        {item.image_url ? (
                          <img
                            src={item.image_url}
                            alt={item.name}
                            referrerPolicy="no-referrer"
                            loading="lazy"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-xs text-[#6E7587]">
                            بدون صورة
                          </div>
                        )}
                        {item.is_featured && (
                          <div className="absolute top-2 start-2 bg-[#D4AF37] text-black text-[10px] font-bold px-2 py-0.5 rounded-md">
                            مميز
                          </div>
                        )}
                      </div>

                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-sm font-bold text-white">{item.name}</h4>
                        <span className="font-mono text-sm font-bold text-[#D4AF37] whitespace-nowrap">
                          {item.price} {currency}
                        </span>
                      </div>

                      {item.description && (
                        <p className="text-xs text-[#7E8597] line-clamp-2 mt-1.5 leading-relaxed">
                          {item.description}
                        </p>
                      )}
                    </div>

                    <div className="pt-3 border-t border-[#1C202C] mt-3">
                      {inCart ? (
                        <div className="flex items-center justify-between bg-[#191D2A] rounded-xl p-1 border border-[#2B3145]">
                          <button
                            onClick={() => updateQuantity(item.id, -1)}
                            className="w-8 h-8 rounded-lg bg-[#242A3C] text-white flex items-center justify-center hover:bg-rose-900/50 cursor-pointer"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="font-mono font-bold text-sm text-white">
                            {inCart.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, 1)}
                            className="w-8 h-8 rounded-lg bg-[#D4AF37] text-black flex items-center justify-center font-bold hover:bg-[#e0be4d] cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <Button
                          variant="secondary"
                          size="sm"
                          className="w-full border-[#2F364C] hover:border-[#D4AF37]"
                          onClick={() => addToCart(item)}
                          icon={<Plus className="w-3.5 h-3.5 text-[#D4AF37]" />}
                        >
                          إضافة للطلب
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Footer Branding */}
          <footer className="py-10 text-center text-xs text-[#5D6374] border-t border-[#181B26] mt-12 mb-16">
            <p className="flex items-center justify-center gap-1.5 font-medium">
              <span>مشغّل بواسطة</span>
              <span className="font-bold tracking-wider text-[#D4AF37]">MENUORA</span>
              <span className="text-[10px] text-[#424859]">· تجربة طعام رقمية فاخرة</span>
            </p>
          </footer>
        </div>
      </div>

      {/* Floating Cart Bar at Bottom if items added */}
      {cartItemsCount > 0 && !isCartOpen && (
        <div className="fixed bottom-4 inset-x-4 max-w-lg mx-auto z-40 animate-in slide-in-from-bottom-5">
          <button
            onClick={() => setIsCartOpen(true)}
            className="w-full p-4 rounded-2xl bg-gradient-to-r from-[#D4AF37] to-[#B39023] text-black font-bold flex items-center justify-between shadow-[0_10px_30px_rgba(212,175,55,0.3)] cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-black/20 flex items-center justify-center font-mono font-black text-sm">
                {cartItemsCount}
              </div>
              <div className="text-right">
                <span className="text-xs opacity-90 block">سلة الطلب</span>
                <span className="text-sm font-black">متابعة إرسال الطلب للمطبخ</span>
              </div>
            </div>

            <span className="font-mono text-base font-black">
              {cartTotal.toFixed(2)} {currency}
            </span>
          </button>
        </div>
      )}

      {/* Cart & Checkout Modal Drawer */}
      {isCartOpen && (
        <Modal
          isOpen={true}
          onClose={() => setIsCartOpen(false)}
          title="سلة طلباتك"
          description={table ? `طلب من طاولة #${table.number}` : 'طلب مباشر'}
          maxWidth="md"
        >
          <form onSubmit={handleSubmitOrder} className="space-y-4">
            {/* List of items in cart */}
            <div className="divide-y divide-[#1F2432] max-h-60 overflow-y-auto p-1">
              {cart.map(c => (
                <div key={c.item.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <h5 className="font-bold text-white">{c.item.name}</h5>
                    <span className="font-mono text-[#D4AF37] text-[11px]">
                      {c.item.price} {currency}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1.5 bg-[#171B26] rounded-lg p-1 border border-[#272D3E]">
                      <button
                        type="button"
                        onClick={() => updateQuantity(c.item.id, -1)}
                        className="w-6 h-6 rounded bg-[#23293B] text-white flex items-center justify-center"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="font-mono font-bold px-1.5 text-white">{c.quantity}</span>
                      <button
                        type="button"
                        onClick={() => updateQuantity(c.item.id, 1)}
                        className="w-6 h-6 rounded bg-[#D4AF37] text-black flex items-center justify-center font-bold"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="font-mono font-bold text-white w-16 text-left">
                      {(c.item.price * c.quantity).toFixed(2)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Total */}
            <div className="p-3 bg-[#151822] rounded-xl flex items-center justify-between text-sm border border-[#232838]">
              <span className="font-bold text-white">إجمالي الحساب:</span>
              <span className="font-mono font-black text-[#D4AF37] text-base">
                {cartTotal.toFixed(2)} {currency}
              </span>
            </div>

            {/* Customer Inputs */}
            <div className="space-y-3 pt-2 border-t border-[#1F2432]">
              <Input
                label="اسمك (اختياري)"
                placeholder="أحمد"
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
              />

              <Input
                label="رقم الهاتف للتواصل (اختياري)"
                placeholder="+966500000000"
                value={customerPhone}
                onChange={e => setCustomerPhone(e.target.value)}
              />

              <div className="flex flex-col gap-1 text-right">
                <label className="text-xs font-semibold text-[#C4C7D5]">ملاحظات خاصة للمطبخ</label>
                <textarea
                  rows={2}
                  placeholder="بدون بصل، الصلصة جانباً..."
                  value={orderNotes}
                  onChange={e => setOrderNotes(e.target.value)}
                  className="w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-xs rounded-lg p-2.5 focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
            </div>

            <div className="pt-2">
              <Button
                type="submit"
                variant="primary"
                loading={isSubmittingOrder}
                className="w-full py-3"
              >
                تأكيد وإرسال الطلب للمطبخ ✓
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* Order Confirmed Modal */}
      {completedOrderId && (
        <Modal
          isOpen={true}
          onClose={() => setCompletedOrderId(null)}
          title="تم إرسال طلبك بنجاح!"
          maxWidth="sm"
        >
          <div className="text-center space-y-4 py-2">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h4 className="text-base font-bold text-white">شكراً لك!</h4>
              <p className="text-xs text-[#8E95A8] mt-1">
                رقم طلبك في نظام المطبخ هو:
              </p>
              <div className="font-mono text-xl font-bold text-[#D4AF37] mt-1 bg-[#151822] py-2 px-4 rounded-xl border border-[#232838] inline-block">
                #{completedOrderId.slice(0, 6)}
              </div>
            </div>

            <p className="text-xs text-[#C4C7D5] leading-relaxed">
              يقوم طاقم العمل الآن بمراجعة طلبك وتحضيره فوراً.
            </p>

            <Button
              variant="primary"
              className="w-full"
              onClick={() => setCompletedOrderId(null)}
            >
              العودة للقائمة
            </Button>
          </div>
        </Modal>
      )}

      {/* Floating AI Customer Assistant */}
      <AIMenuAssistantWidget
        restaurantSlug={restaurant.slug}
        restaurantName={restaurant.name}
        currency={currency}
        availableItems={items}
        onAddToCart={addToCart}
      />
    </div>
  );
};
