import React from 'react';
import {
  QrCode,
  UtensilsCrossed,
  ShoppingBag,
  Zap,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  ArrowLeft,
  ChevronDown,
  Sparkles,
  Smartphone,
  Eye,
  Sliders,
  DollarSign
} from 'lucide-react';
import { Button } from '../components/Button';

interface LandingPageProps {
  onNavigateLogin: () => void;
  onNavigateRegister: () => void;
  onNavigateSampleMenu: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigateLogin,
  onNavigateRegister,
  onNavigateSampleMenu
}) => {
  return (
    <div className="min-h-screen bg-[#0B0C10] text-[#E0E2EC] selection:bg-[#D4AF37]/30">
      {/* 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-40 bg-[#0B0C10]/90 backdrop-blur-md border-b border-[#1E222F]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand title */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#D4AF37] to-[#8C6D1F] flex items-center justify-center font-black text-black text-sm shadow-md">
              M
            </div>
            <span className="text-base font-bold text-white tracking-wide whitespace-nowrap">
              MENUORA
            </span>
          </div>

          {/* Zone 2: Nav links */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-[#8E95A8]">
            <a href="#features" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              المميزات
            </a>
            <a href="#how-it-works" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              كيف يعمل
            </a>
            <a href="#pricing" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              الباقات
            </a>
            <a href="#faq" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              الأسئلة الشائعة
            </a>
          </nav>

          {/* Zone 3: Primary Action */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onNavigateLogin}
              className="text-xs font-bold text-[#C4C7D5] hover:text-white px-3 py-2 rounded-lg transition-colors cursor-pointer"
            >
              دخول المطاعم
            </button>
            <Button
              size="sm"
              variant="primary"
              onClick={onNavigateRegister}
            >
              ابدأ مجاناً
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-12 pb-20 md:pt-20 md:pb-32 overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-1/4 start-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#D4AF37]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#181B26] border border-[#272D3E] text-xs font-semibold text-[#D4AF37] mb-6">
            <Sparkles className="w-3.5 h-3.5" />
            <span>نظام القائمة الذكية السحابي للمطاعم والمقاهي</span>
          </div>

          <h1 className="text-3xl sm:text-5xl md:text-6xl font-black text-white tracking-tight leading-[1.2] max-w-4xl mx-auto">
            حوّل قائمة مطعمك إلى{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] via-[#f7e089] to-[#D4AF37]">
              تجربة رقمية احترافية
            </span>
          </h1>

          <p className="text-sm sm:text-base text-[#8E95A8] mt-6 max-w-2xl mx-auto leading-relaxed">
            أنشئ قائمة طعام تفاعلية مرتبطة برموز QR لكل طاولة. اسمح لزبائنك بالطلب الفوري عبر هواتفهم واستقبل الطلبات في لوحة تحكم حية بدون وسطاء.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8">
            <Button
              size="lg"
              variant="primary"
              onClick={onNavigateRegister}
              icon={<ArrowLeft className="w-4 h-4" />}
            >
              أنشئ قائمة مطعمك مجاناً
            </Button>
            <Button
              size="lg"
              variant="secondary"
              onClick={onNavigateLogin}
            >
              تسجيل دخول أصحاب المطاعم
            </Button>
          </div>

          <div className="flex items-center justify-center gap-6 mt-10 text-xs text-[#7E8699]">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>بدون عمولة على المبيعات</span>
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>تحديث فوري للأسعار والأطباق</span>
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>يعمل على جميع الهواتف</span>
            </span>
          </div>
        </div>
      </section>

      {/* Visual Showcase (Live QR Mockup) */}
      <section className="py-12 border-y border-[#181C28] bg-[#0E1016]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            {/* Feature 1 */}
            <div className="p-6 rounded-2xl bg-[#12141E] border border-[#202534] space-y-3">
              <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37]">
                <QrCode className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-white">رمز QR مخصص لكل طاولة</h3>
              <p className="text-xs text-[#8E95A8] leading-relaxed">
                رمز استجابة سريع يربط كل طاولة برقمها المحدد، يتيح للزبون مسح الكود وطلب أطباقه في ثوانٍ.
              </p>
            </div>

            {/* Feature 2 (Center Hero) */}
            <div className="p-8 rounded-3xl bg-gradient-to-b from-[#181B28] to-[#10121A] border-2 border-[#D4AF37]/30 text-center shadow-2xl space-y-4">
              <div className="w-20 h-20 rounded-2xl bg-white p-2 mx-auto shadow-md">
                <div className="w-full h-full bg-[#0B0C10] rounded-xl flex items-center justify-center text-[#D4AF37]">
                  <QrCode className="w-10 h-10" />
                </div>
              </div>
              <div>
                <h4 className="text-base font-bold text-white">امسح لتجربة القائمة</h4>
                <p className="text-xs text-[#8E95A8] mt-1">تصفح سريع بدون تحميل أي تطبيق</p>
              </div>
              <div className="pt-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={onNavigateRegister}
                >
                  ابدأ التجربة الآن
                </Button>
              </div>
            </div>

            {/* Feature 3 */}
            <div className="p-6 rounded-2xl bg-[#12141E] border border-[#202534] space-y-3">
              <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37]">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-white">إدارة طلبات المطبخ الفورية</h3>
              <p className="text-xs text-[#8E95A8] leading-relaxed">
                لوحة تحكم حية تعتمد تقنية Supabase Realtime لتحديث تدفق الطلبات وحالتها من الانتظار إلى التقديم.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-20 max-w-5xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider">
            خطوات بسيطة
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">كيف يعمل النظام في مطعمك؟</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="p-5 rounded-2xl bg-[#11131B] border border-[#202534]">
            <span className="font-mono text-2xl font-black text-[#D4AF37]">01</span>
            <h4 className="text-sm font-bold text-white mt-3 mb-1.5">أنشئ قائمة طعامك</h4>
            <p className="text-xs text-[#8E95A8] leading-relaxed">
              سجل حسابك وأضف تصنيفات الأطعمة والأطباق بأسعارها وصورها بدقة عالية مع ضغط الصور السحابي.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#11131B] border border-[#202534]">
            <span className="font-mono text-2xl font-black text-[#D4AF37]">02</span>
            <h4 className="text-sm font-bold text-white mt-3 mb-1.5">اطبع رموز QR للطاولات</h4>
            <p className="text-xs text-[#8E95A8] leading-relaxed">
              قم بتوليد رموز QR جاهزة للطباعة لكل طاولة، وحمّلها بصيغة PNG أو اطبعها فوراً عبر ضغطة زر.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#11131B] border border-[#202534]">
            <span className="font-mono text-2xl font-black text-[#D4AF37]">03</span>
            <h4 className="text-sm font-bold text-white mt-3 mb-1.5">استقبل الطلبات وتتبّع الأداء</h4>
            <p className="text-xs text-[#8E95A8] leading-relaxed">
              يمسح الزبون الرمز بهاتفه، يختار الأصناف ويؤكد الطلب لتصل التفاصيل لمطبخك فوراً مع إحصائيات المبيعات.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-[#0E1016] border-y border-[#181C28]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider">
              الأسعار والباقات
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">باقات مرنة تناسب طموحك</h2>
            <p className="text-xs text-[#8E95A8] mt-2">ابدأ مجاناً اليوم، وقم بالترقية مع نمو مطعمك</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Free */}
            <div className="p-6 rounded-2xl bg-[#11131B] border border-[#212635] flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold text-white">الباقة المجانية</h3>
                <p className="text-xs text-[#8E95A8] mt-1">للمطاعم والمقاهي في بدايتها</p>
                <div className="my-5 pb-5 border-b border-[#1E2332] flex items-baseline gap-1">
                  <span className="text-3xl font-black text-white font-mono">0</span>
                  <span className="text-xs text-[#8E95A8]">ريال للأبد</span>
                </div>
                <ul className="space-y-2.5 text-xs text-[#C4C7D5]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>حتى 20 صنفاً في القائمة</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>5 طاولات برمز QR</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>استقبال الطلبات المباشرة</span>
                  </li>
                </ul>
              </div>
              <div className="pt-6 mt-6 border-t border-[#1E2332]">
                <Button variant="secondary" className="w-full" onClick={onNavigateRegister}>
                  ابدأ مجاناً
                </Button>
              </div>
            </div>

            {/* Pro */}
            <div className="p-6 rounded-2xl bg-[#141724] border-2 border-[#D4AF37] flex flex-col justify-between shadow-xl">
              <div>
                <div className="inline-block px-2 py-0.5 rounded bg-[#D4AF37] text-black text-[10px] font-bold mb-2">
                  الأكثر شعبية
                </div>
                <h3 className="text-base font-bold text-white">باقة المحترفين</h3>
                <p className="text-xs text-[#8E95A8] mt-1">للمطاعم النشطة</p>
                <div className="my-5 pb-5 border-b border-[#242A3C] flex items-baseline gap-1">
                  <span className="text-3xl font-black text-white font-mono">149</span>
                  <span className="text-xs text-[#8E95A8]">ريال / شهرياً</span>
                </div>
                <ul className="space-y-2.5 text-xs text-[#C4C7D5]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>أصناف غير محدودة</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>حتى 30 طاولة برمز QR</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>تحديثات حية Realtime للطلبات</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>تحليلات المبيعات والزيارات</span>
                  </li>
                </ul>
              </div>
              <div className="pt-6 mt-6 border-t border-[#242A3C]">
                <Button variant="primary" className="w-full" onClick={onNavigateRegister}>
                  اختر باقة المحترفين
                </Button>
              </div>
            </div>

            {/* Business */}
            <div className="p-6 rounded-2xl bg-[#11131B] border border-[#212635] flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold text-white">باقة الأعمال</h3>
                <p className="text-xs text-[#8E95A8] mt-1">للسلاسل والفروع الكبرى</p>
                <div className="my-5 pb-5 border-b border-[#1E2332] flex items-baseline gap-1">
                  <span className="text-3xl font-black text-white font-mono">349</span>
                  <span className="text-xs text-[#8E95A8]">ريال / شهرياً</span>
                </div>
                <ul className="space-y-2.5 text-xs text-[#C4C7D5]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>كل مميزات باقة المحترفين</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>طاولات وفروع غير محدودة</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>ربط نطاق خاص (Domain)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>دعم فني مخصص على مدار الساعة</span>
                  </li>
                </ul>
              </div>
              <div className="pt-6 mt-6 border-t border-[#1E2332]">
                <Button variant="secondary" className="w-full" onClick={onNavigateRegister}>
                  اختر باقة الأعمال
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 max-w-4xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider">
            الأسئلة المتكررة
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">كل ما تحتاج معرفته</h2>
        </div>

        <div className="space-y-4">
          <div className="p-5 rounded-2xl bg-[#11131B] border border-[#202534]">
            <h4 className="text-sm font-bold text-white mb-2">هل يحتاج العميل لتحميل تطبيق على هاتفه؟</h4>
            <p className="text-xs text-[#8E95A8] leading-relaxed">
              كلا على الإطلاق. تفتح القائمة فوراً في متصفح الهاتف بمجرد توجيه كاميرا الهاتف نحو رمز QR على الطاولة بسرعة فائقة وبدون أي تسجيل أو انتظار.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#11131B] border border-[#202534]">
            <h4 className="text-sm font-bold text-white mb-2">كيف أعرف رقم الطاولة التي أرسل منها العميل طلبه؟</h4>
            <p className="text-xs text-[#8E95A8] leading-relaxed">
              يقوم نظامنا بتوليد رمز QR فريد لكل طاولة يحتوي على معرف رقمي لها، وعندما يرسل الزبون طلبه يصل للمطبخ مع رقم الطاولة بشكل تلقائي لا يمكن التلاعب به.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#11131B] border border-[#202534]">
            <h4 className="text-sm font-bold text-white mb-2">هل يمكنني تعديل الأسعار أو نفاد صنف معين في أي وقت؟</h4>
            <p className="text-xs text-[#8E95A8] leading-relaxed">
              نعم، بضغطة زر واحدة من هاتفك أو جهازك في لوحة التحكم، يمكنك إيقاف توفر أي طبق فوراً ليختفي من قائمة الزبائن، أو تعديل السعر ليظهر محدثاً فوراً.
            </p>
          </div>
        </div>
      </section>

      {/* Final CTA Strip */}
      <section className="py-16 bg-gradient-to-r from-[#171924] via-[#1A1813] to-[#171924] border-t border-[#23293B] text-center px-4">
        <h2 className="text-2xl sm:text-3xl font-black text-white max-w-xl mx-auto">
          جاهز لتطوير تجربة زبائنك وزيادة كفاءة طلبات مطعمك؟
        </h2>
        <p className="text-xs text-[#8E95A8] mt-3 max-w-md mx-auto">
          انضم اليوم إلى مئات المطاعم التي تدير قوائمها الرقمية باحترافية
        </p>
        <div className="mt-6">
          <Button size="lg" variant="primary" onClick={onNavigateRegister}>
            ابدأ الآن مجاناً
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-[#090A0E] border-t border-[#161822] text-xs text-[#6E7587]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white tracking-wide">MENUORA</span>
            <span>· جميع الحقوق محفوظة {new Date().getFullYear()}</span>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={onNavigateLogin} className="hover:text-white cursor-pointer">
              دخول المطاعم
            </button>
            <button onClick={onNavigateRegister} className="hover:text-white cursor-pointer">
              تسجيل مطعم
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
