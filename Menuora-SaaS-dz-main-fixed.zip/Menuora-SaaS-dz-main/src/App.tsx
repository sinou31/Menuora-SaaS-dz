import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/auth/LoginPage';
import { RegisterPage } from './pages/auth/RegisterPage';
import { VerifyEmailPage } from './pages/auth/VerifyEmailPage';
import { ForgotPasswordPage } from './pages/auth/ForgotPasswordPage';
import { ResetPasswordPage } from './pages/auth/ResetPasswordPage';
import { DashboardLayout, DashboardTab } from './layouts/DashboardLayout';
import { DashboardOverview } from './pages/dashboard/DashboardOverview';
import { OrdersPage } from './pages/dashboard/OrdersPage';
import { MenuPage } from './pages/dashboard/MenuPage';
import { CategoriesPage } from './pages/dashboard/CategoriesPage';
import { TablesPage } from './pages/dashboard/TablesPage';
import { RestaurantSettingsPage } from './pages/dashboard/RestaurantSettingsPage';
import { ProfilePage } from './pages/dashboard/ProfilePage';
import { SubscriptionPage } from './pages/dashboard/SubscriptionPage';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AIMenuManagerPage } from './pages/dashboard/AIMenuManagerPage';
import { PublicMenuPage } from './pages/public/PublicMenuPage';
import { LoadingSpinner } from './components/LoadingSpinner';

function AppRouter() {
  const { user, loading, restaurant } = useAuth();

  const [currentHash, setCurrentHash] = useState(
    () => window.location.hash || ''
  );
  const [dashboardTab, setDashboardTab] =
    useState<DashboardTab>('overview');
  const [verifyEmailParam, setVerifyEmailParam] = useState('');

  useEffect(() => {
    const handleHashChange = () => {
      setCurrentHash(window.location.hash || '');
    };

    window.addEventListener('hashchange', handleHashChange);

    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []);

  const navigate = (route: string) => {
    const newHash = route ? `#${route.replace(/^#/, '')}` : '';

    if (window.location.hash !== newHash) {
      window.location.hash = newHash;
    }

    setCurrentHash(newHash);
  };

  if (loading) {
    return (
      <LoadingSpinner
        message="جاري استعادة الجلسة والتحقق من الحساب..."
        fullScreen
      />
    );
  }

  const hash = currentHash.replace(/^#\/?/, '');
  const pathname = window.location.pathname.replace(/^\/+|\/+$/g, '');

  // Public restaurant menu
  if (hash.startsWith('menu/') || pathname.startsWith('menu/')) {
    const routeString = hash.startsWith('menu/') ? hash : pathname;
    const [pathPart, queryPart] = routeString.split('?');
    const slug = pathPart.replace(/^menu\//, '');
    const searchParams = new URLSearchParams(
      queryPart || window.location.search
    );
    const tableSlug = searchParams.get('table') || undefined;

    return (
      <PublicMenuPage
        slug={slug}
        tableSlug={tableSlug}
        onNavigateLanding={() => navigate('')}
      />
    );
  }

  // Verify email
  if (hash === 'verify-email') {
    return (
      <VerifyEmailPage
        email={verifyEmailParam || user?.email || ''}
        onNavigateLogin={() => navigate('login')}
      />
    );
  }

  // Forgot password
  if (hash === 'forgot-password') {
    return (
      <ForgotPasswordPage
        onNavigateLogin={() => navigate('login')}
      />
    );
  }

  // Reset password.
  // Supabase e-mails a link to `${origin}/reset-password` (see AuthContext.resetPassword),
  // i.e. a real PATH, not a hash route, and the recovery tokens arrive in the URL hash
  // (`#access_token=...&type=recovery`). The old code only matched `#reset-password`,
  // so the link from the e-mail opened the landing page instead of the reset form.
  const isRecoveryLink =
    hash === 'reset-password' ||
    pathname === 'reset-password' ||
    currentHash.includes('type=recovery');

  if (isRecoveryLink) {
    return (
      <ResetPasswordPage
        onSuccess={() => {
          // Leave the /reset-password path so the router does not show this page again.
          if (window.location.pathname !== '/') {
            window.history.replaceState(null, '', '/');
          }
          navigate('dashboard');
        }}
      />
    );
  }

  // Login
  if (hash === 'login') {
    return (
      <LoginPage
        onNavigateRegister={() => navigate('register')}
        onNavigateForgotPassword={() => navigate('forgot-password')}
        onSuccessLogin={() => navigate('dashboard')}
      />
    );
  }

  // Registration
  if (hash === 'register') {
    return (
      <RegisterPage
        onNavigateLogin={() => navigate('login')}
        onNavigateVerifyEmail={(email) => {
          setVerifyEmailParam(email);
          navigate('verify-email');
        }}
        onSuccessRegistered={() => navigate('dashboard')}
      />
    );
  }

  // Dashboard and admin routes
  if (user || hash.startsWith('dashboard') || hash.startsWith('admin')) {
    let activeTab: DashboardTab = dashboardTab;

    if (hash === 'admin' || hash === 'dashboard/admin') {
      activeTab = 'admin';
    } else if (hash === 'dashboard/orders') {
      activeTab = 'orders';
    } else if (hash === 'dashboard/menu') {
      activeTab = 'menu';
    } else if (hash === 'dashboard/categories') {
      activeTab = 'categories';
    } else if (hash === 'dashboard/tables') {
      activeTab = 'tables';
    } else if (hash === 'dashboard/ai') {
      activeTab = 'ai';
    } else if (hash === 'dashboard/settings') {
      activeTab = 'settings';
    } else if (hash === 'dashboard/profile') {
      activeTab = 'profile';
    } else if (hash === 'dashboard/subscription') {
      activeTab = 'subscription';
    }

    if (!user) {
      return (
        <LoginPage
          onNavigateRegister={() => navigate('register')}
          onNavigateForgotPassword={() => navigate('forgot-password')}
          onSuccessLogin={() => navigate('dashboard')}
        />
      );
    }

    return (
      <DashboardLayout
        currentTab={activeTab}
        onSelectTab={(tab) => {
          setDashboardTab(tab);
          navigate(`dashboard/${tab}`);
        }}
      >
        {activeTab === 'overview' && (
          <DashboardOverview
            onNavigateTab={(tab) => {
              setDashboardTab(tab);
              navigate(`dashboard/${tab}`);
            }}
          />
        )}

        {activeTab === 'orders' && <OrdersPage />}
        {activeTab === 'menu' && <MenuPage />}
        {activeTab === 'categories' && <CategoriesPage />}
        {activeTab === 'tables' && <TablesPage />}
        {activeTab === 'ai' && <AIMenuManagerPage />}
        {activeTab === 'settings' && <RestaurantSettingsPage />}
        {activeTab === 'profile' && <ProfilePage />}
        {activeTab === 'subscription' && <SubscriptionPage />}
        {activeTab === 'admin' && <AdminDashboardPage />}
      </DashboardLayout>
    );
  }

  // Landing page
  return (
    <LandingPage
      onNavigateLogin={() => navigate('login')}
      onNavigateRegister={() => navigate('register')}
      onNavigateSampleMenu={() => {
        if (restaurant?.slug) {
          navigate(`menu/${restaurant.slug}`);
        } else {
          navigate('register');
        }
      }}
    />
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <AppRouter />
      </AuthProvider>
    </ToastProvider>
  );
}
