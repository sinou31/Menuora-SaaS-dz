/**
 * Production Input Validation and Sanitization
 */

export interface PasswordStrengthResult {
  score: 1 | 2 | 3;
  label: 'weak' | 'medium' | 'strong';
  color: string;
  hasMinLength: boolean;
  hasNumber: boolean;
  hasLetter: boolean;
  hasSymbolOrUpper: boolean;
}

export function evaluatePasswordStrength(password: string): PasswordStrengthResult {
  const hasMinLength = password.length >= 8;
  const hasNumber = /\d/.test(password);
  const hasLetter = /[a-zA-Z\u0600-\u06FF]/.test(password);
  const hasSymbolOrUpper = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password) || /[A-Z]/.test(password);

  let score: 1 | 2 | 3 = 1;
  if (hasMinLength && hasNumber && hasLetter && (password.length >= 10 || hasSymbolOrUpper)) {
    score = 3;
  } else if (hasMinLength && (hasNumber || hasLetter)) {
    score = 2;
  }

  const label = score === 3 ? 'strong' : score === 2 ? 'medium' : 'weak';
  const color = score === 3 ? 'text-emerald-500' : score === 2 ? 'text-amber-500' : 'text-rose-500';

  return {
    score,
    label,
    color,
    hasMinLength,
    hasNumber,
    hasLetter,
    hasSymbolOrUpper
  };
}

export function isValidEmail(email: string): boolean {
  if (!email || email.length > 254) return false;
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  return emailRegex.test(email.trim());
}

export function isValidPhone(phone: string): boolean {
  if (!phone) return true; // optional
  const clean = phone.replace(/[\s\-\(\)]/g, '');
  return clean.length >= 8 && clean.length <= 15 && /^\+?\d+$/.test(clean);
}

export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s\u0600-\u06FF-]/g, '') // keep letters, arabic, hyphens
    .replace(/\s+/g, '-')
    .replace(/--+/g, '-')
    .replace(/^-+|-+$/g, '') || 'restaurant-' + Math.floor(1000 + Math.random() * 9000);
}

export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
export const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

export function validateImageFile(file: File): { valid: boolean; error?: string } {
  if (!ALLOWED_IMAGE_TYPES.includes(file.type.toLowerCase())) {
    return {
      valid: false,
      error: 'نوع الملف غير مدعوم. الصيغ المقبولة فقط: JPG, PNG, WEBP'
    };
  }

  if (file.size > MAX_IMAGE_SIZE_BYTES) {
    return {
      valid: false,
      error: 'حجم الصورة كبير جداً. الحد الأقصى المسموح به هو 5 ميجابايت'
    };
  }

  return { valid: true };
}
