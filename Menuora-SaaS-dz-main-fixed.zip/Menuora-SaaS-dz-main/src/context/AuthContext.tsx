
import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useRef
} from 'react';

import type { User, Session } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import type { Profile, Restaurant } from '../types/database.types';
import { restaurantService } from '../services/restaurantService';
import { generateSlug } from '../utils/validators';

interface RegisterData {
  email: string;
  password: string;
  fullName: string;
  phone: string;
  restaurantName: string;
  city: string;
  address: string;
  description: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  restaurant: Restaurant | null;
  loading: boolean;
  isConfigured: boolean;
  signIn: (
    email: string,
    password: string
  ) => Promise<{ error: Error | null }>;
  signUp: (
    data: RegisterData
  ) => Promise<{
    error: Error | null;
    needsEmailVerification: boolean;
  }>;
  signOut: () => Promise<void>;
  resetPassword: (
    email: string
  ) => Promise<{ error: Error | null }>;
  updatePassword: (
    password: string
  ) => Promise<{ error: Error | null }>;
  refreshProfile: () => Promise<void>;
  refreshRestaurant: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [loading, setLoading] = useState(true);

  const mountedRef = useRef(false);
  const currentUserIdRef = useRef<string | null>(null);
  const restaurantRequestRef = useRef(0);

  // Load the user's profile.
  const loadProfile = useCallback(async (userId: string): Promise<void> => {
    if (!isSupabaseConfigured || !userId) {
      setProfile(null);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (currentUserIdRef.current !== userId) return;

      if (error) {
        console.error('[AuthContext] Profile fetch error:', error);
        setProfile(null);
        return;
      }

      setProfile(data ?? null);
    } catch (error) {
      if (currentUserIdRef.current !== userId) return;

      console.error('[AuthContext] Profile fetch exception:', error);
      setProfile(null);
    }
  }, []);

  // Load the restaurant belonging to the authenticated user.
  const loadRestaurant = useCallback(async (
    userId: string
  ): Promise<void> => {
    const requestId = ++restaurantRequestRef.current;

    if (!isSupabaseConfigured || !userId) {
      setRestaurant(null);
      return;
    }

    try {
      // Verify which user Supabase currently considers authenticated.
      const {
        data: { user: currentUser },
        error: authError
      } = await supabase.auth.getUser();

      if (authError) {
        throw authError;
      }

      if (!currentUser) {
        throw new Error(
          'لا توجد جلسة مستخدم صالحة. سجّل الخروج ثم ادخل مجددًا.'
        );
      }

      if (currentUser.id !== userId) {
        console.error(
          '[AuthContext] User ID mismatch:',
          { requestedOwner: userId, authenticatedUser: currentUser.id }
        );

        return;
      }

      const result = await restaurantService.getRestaurantByOwner(
        currentUser.id
      );

      // Ignore stale requests and requests for a different account.
      if (
        !mountedRef.current ||
        currentUserIdRef.current !== userId ||
        requestId !== restaurantRequestRef.current
      ) {
        return;
      }

      setRestaurant(result);
    } catch (error) {
      if (
        !mountedRef.current ||
        currentUserIdRef.current !== userId ||
        requestId !== restaurantRequestRef.current
      ) {
        return;
      }

      console.error(
        '[AuthContext] Restaurant fetch failed:',
        error
      );

      setRestaurant(null);
    }
  }, []);

  const loadUserData = useCallback(async (
    userId: string
  ): Promise<void> => {
    await Promise.all([
      loadProfile(userId),
      loadRestaurant(userId)
    ]);
  }, [loadProfile, loadRestaurant]);

  // Initialize authentication and subscribe to auth changes.
  useEffect(() => {
    mountedRef.current = true;
    let disposed = false;
    let initialSessionHandled = false;

    const initialize = async (): Promise<void> => {
      if (!isSupabaseConfigured) {
        setLoading(false);
        return;
      }

      try {
        const {
          data: { session: initialSession },
          error
        } = await supabase.auth.getSession();

        if (error) {
          console.error(
            '[AuthContext] Session initialization error:',
            error
          );
        }

        if (disposed || initialSessionHandled) return;

        initialSessionHandled = true;

        const initialUser = initialSession?.user ?? null;
        currentUserIdRef.current = initialUser?.id ?? null;

        setSession(initialSession);
        setUser(initialUser);

        if (initialUser) {
          await loadUserData(initialUser.id);
        } else {
          setProfile(null);
          setRestaurant(null);
        }
      } catch (error) {
        console.error(
          '[AuthContext] Authentication initialization failed:',
          error
        );
      } finally {
        if (!disposed) {
          setLoading(false);
        }
      }
    };

    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((event, newSession) => {
      if (disposed) return;

      // The initialization function handles the initial session.
      if (event === 'INITIAL_SESSION' && initialSessionHandled) {
        return;
      }

      const nextUser = newSession?.user ?? null;
      const nextUserId = nextUser?.id ?? null;
      const sameUser =
        nextUserId !== null && currentUserIdRef.current === nextUserId;

      // supabase-js fires SIGNED_IN / TOKEN_REFRESHED / USER_UPDATED again for the SAME
      // user (token refresh, tab regaining focus...). Previously each one set
      // `loading = true`, which replaced the entire app with a spinner, unmounted every
      // page and wiped forms the user was typing in. Just keep the session fresh.
      if (sameUser && event !== 'USER_UPDATED') {
        setSession(newSession);
        setUser(nextUser);
        return;
      }

      if (sameUser && event === 'USER_UPDATED') {
        setSession(newSession);
        setUser(nextUser);
        Promise.resolve().then(() => {
          if (!disposed && currentUserIdRef.current === nextUserId) {
            void loadProfile(nextUserId);
          }
        });
        return;
      }

      // Invalidate old requests when the authenticated account changes.
      if (currentUserIdRef.current !== nextUserId) {
        restaurantRequestRef.current += 1;
        setProfile(null);
        setRestaurant(null);
      }

      currentUserIdRef.current = nextUserId;

      setSession(newSession);
      setUser(nextUser);
      initialSessionHandled = true;

      if (!nextUser) {
        setProfile(null);
        setRestaurant(null);
        setLoading(false);
        return;
      }

      setLoading(true);

      // Avoid querying Supabase directly inside its auth callback.
      Promise.resolve().then(async () => {
        if (disposed || currentUserIdRef.current !== nextUserId) return;

        try {
          await loadUserData(nextUserId);
        } finally {
          if (
            !disposed &&
            currentUserIdRef.current === nextUserId
          ) {
            setLoading(false);
          }
        }
      });
    });

    void initialize();

    return () => {
      disposed = true;
      mountedRef.current = false;
      restaurantRequestRef.current += 1;
      subscription.unsubscribe();
    };
  }, [loadUserData, loadProfile]);

  // Sign in.
  const signIn = async (
    email: string,
    password: string
  ): Promise<{ error: Error | null }> => {
    if (!isSupabaseConfigured) {
      return {
        error: new Error(
          'يرجى ضبط بيانات الاتصال بـ Supabase أولاً'
        )
      };
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password
      });

      if (error) {
        return { error };
      }

      if (data.user) {
        currentUserIdRef.current = data.user.id;
        setUser(data.user);
        setSession(data.session);

        await loadUserData(data.user.id);
      }

      return { error: null };
    } catch (error) {
      return {
        error: error instanceof Error
          ? error
          : new Error('حدث خطأ أثناء تسجيل الدخول')
      };
    }
  };

  // Sign up. The `handle_new_user` database trigger (supabase/schema.sql) creates the
  // profile, the restaurant and the free subscription from the metadata below. It must
  // run in the database because with e-mail confirmation enabled there is no session yet.
  const signUp = async (
    data: RegisterData
  ): Promise<{
    error: Error | null;
    needsEmailVerification: boolean;
  }> => {
    if (!isSupabaseConfigured) {
      return {
        error: new Error(
          'يرجى ضبط بيانات الاتصال بـ Supabase أولاً'
        ),
        needsEmailVerification: false
      };
    }

    try {
      const restaurantName = data.restaurantName.trim();

      if (!restaurantName) {
        return {
          error: new Error('يرجى إدخال اسم المطعم'),
          needsEmailVerification: false
        };
      }

      const slug = generateSlug(restaurantName);

      if (!slug) {
        return {
          error: new Error(
            'تعذر إنشاء رابط المطعم. غيّر اسم المطعم وحاول مجددًا'
          ),
          needsEmailVerification: false
        };
      }

      const { data: authData, error } = await supabase.auth.signUp({
        email: data.email.trim(),
        password: data.password,
        options: {
          data: {
            full_name: data.fullName.trim(),
            phone: data.phone.trim(),
            role: 'restaurant_owner',
            restaurant_name: restaurantName,
            restaurant_slug: slug,
            city: data.city.trim(),
            address: data.address.trim(),
            description: data.description.trim()
          }
        }
      });

      if (error) {
        return {
          error,
          needsEmailVerification: false
        };
      }

      if (authData.user && authData.session) {
        currentUserIdRef.current = authData.user.id;
        setUser(authData.user);
        setSession(authData.session);

        await loadUserData(authData.user.id);
      }

      return {
        error: null,
        needsEmailVerification: !authData.session
      };
    } catch (error) {
      return {
        error: error instanceof Error
          ? error
          : new Error('حدث خطأ أثناء إنشاء الحساب'),
        needsEmailVerification: false
      };
    }
  };

  // Sign out.
  const signOut = async (): Promise<void> => {
    if (!isSupabaseConfigured) return;

    try {
      const { error } = await supabase.auth.signOut();

      if (error) {
        console.error('[AuthContext] Sign out error:', error);
        // Fall back to clearing only the local session so the user is never stuck.
        await supabase.auth.signOut({ scope: 'local' }).catch(() => undefined);
      }
    } catch (error) {
      console.error('[AuthContext] Sign out exception:', error);
    } finally {
      currentUserIdRef.current = null;
      restaurantRequestRef.current += 1;

      setUser(null);
      setSession(null);
      setProfile(null);
      setRestaurant(null);
      setLoading(false);
    }
  };

  // Send password reset email.
  const resetPassword = async (
    email: string
  ): Promise<{ error: Error | null }> => {
    if (!isSupabaseConfigured) {
      return { error: new Error('Supabase غير مهيأ') };
    }

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(
        email.trim(),
        {
          redirectTo: `${window.location.origin}/reset-password`
        }
      );

      return { error };
    } catch (error) {
      return {
        error: error instanceof Error
          ? error
          : new Error('تعذر إرسال رسالة إعادة تعيين كلمة المرور')
      };
    }
  };

  // Update password.
  const updatePassword = async (
    password: string
  ): Promise<{ error: Error | null }> => {
    if (!isSupabaseConfigured) {
      return { error: new Error('Supabase غير مهيأ') };
    }

    try {
      const { error } = await supabase.auth.updateUser({ password });
      return { error };
    } catch (error) {
      return {
        error: error instanceof Error
          ? error
          : new Error('تعذر تحديث كلمة المرور')
      };
    }
  };

  const refreshProfile = async (): Promise<void> => {
    const userId = currentUserIdRef.current;

    if (userId) {
      await loadProfile(userId);
    }
  };

  const refreshRestaurant = async (): Promise<void> => {
    const userId = currentUserIdRef.current;

    if (!userId) {
      setRestaurant(null);
      return;
    }

    setLoading(true);

    try {
      await loadRestaurant(userId);
    } finally {
      if (
        mountedRef.current &&
        currentUserIdRef.current === userId
      ) {
        setLoading(false);
      }
    }
  };

  const value: AuthContextType = {
    user,
    session,
    profile,
    restaurant,
    loading,
    isConfigured: isSupabaseConfigured,
    signIn,
    signUp,
    signOut,
    resetPassword,
    updatePassword,
    refreshProfile,
    refreshRestaurant
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error(
      'useAuth must be used within an AuthProvider'
    );
  }

  return context;
}
