import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  X,
  MessageSquare,
  Loader2,
  AlertCircle,
  Plus,
  Utensils
} from 'lucide-react';
import { aiService } from '../services/aiService';
import { MenuItem } from '../types/database.types';
import { Button } from './Button';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  suggestedItems?: string[];
  isError?: boolean;
}

interface AIMenuAssistantWidgetProps {
  restaurantSlug: string;
  restaurantName: string;
  currency: string;
  availableItems: MenuItem[];
  onAddToCart: (item: MenuItem) => void;
}

export const AIMenuAssistantWidget: React.FC<AIMenuAssistantWidgetProps> = ({
  restaurantSlug,
  restaurantName,
  currency,
  availableItems,
  onAddToCart
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [rateLimited, setRateLimited] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: `مرحباً بك في ${restaurantName}! أنا مساعد القائمة الذكي، كيف أساعدك في اختيار وجبتك أو تذوق أطباقنا اليوم؟`
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Generate persistent random session key per browser session
  const [sessionKey] = useState(() => {
    try {
      let key = sessionStorage.getItem('ai_menu_session_key');
      if (!key) {
        key = 'session_' + Math.random().toString(36).substring(2, 10);
        sessionStorage.setItem('ai_menu_session_key', key);
      }
      return key;
    } catch {
      return 'session_' + Math.random().toString(36).substring(2, 10);
    }
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || loading || rateLimited) return;

    // Append user message
    const userMsgId = 'user_' + Date.now();
    setMessages(prev => [...prev, { id: userMsgId, sender: 'user', text }]);
    setInputMessage('');
    setLoading(true);

    abortControllerRef.current = new AbortController();

    try {
      const response = await aiService.askMenuAssistant(
        restaurantSlug,
        text,
        sessionKey,
        abortControllerRef.current.signal
      );

      if (response.rateLimited) {
        setRateLimited(true);
      }

      setMessages(prev => [
        ...prev,
        {
          id: 'assistant_' + Date.now(),
          sender: 'assistant',
          text: response.answer,
          suggestedItems: response.suggestedItems
        }
      ]);
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: 'assistant_err_' + Date.now(),
          sender: 'assistant',
          text: 'عذراً، حدث خطأ أثناء معالجة السؤال. يمكنك تصفح القائمة مباشرة.',
          isError: true
        }
      ]);
    } finally {
      setLoading(false);
      abortControllerRef.current = null;
    }
  };

  const quickQuestions = [
    'ما هي الأطباق النباتية؟',
    'ما هو أكثر طبق مميز لديكم؟',
    'هل لديكم مشروبات منعشة؟',
    'أريد وجبة خفيفة وسريعة'
  ];

  return (
    <>
      {/* Floating Action Button (Clean, Non-intrusive) */}
      {!isOpen && (
        <div className="fixed bottom-20 end-4 z-40">
          <button
            onClick={() => setIsOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#B89428] text-black font-bold text-xs shadow-[0_4px_20px_rgba(212,175,55,0.4)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
            aria-label="مساعد القائمة الذكي"
          >
            <Sparkles className="w-4 h-4 fill-black" />
            <span className="hidden sm:inline">اسأل المساعد الذكي</span>
            <span className="sm:hidden">المساعد</span>
          </button>
        </div>
      )}

      {/* Slide-out Drawer / Chat Modal */}
      {isOpen && (
        <div className="fixed inset-0 sm:inset-auto sm:bottom-6 sm:end-6 z-50 flex flex-col sm:w-96 sm:h-[540px] bg-[#0F1118] border border-[#222738] sm:rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
          {/* Header */}
          <div className="p-3.5 bg-[#141722] border-b border-[#212638] flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37]">
                <Sparkles className="w-3.5 h-3.5 fill-[#D4AF37]" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>مساعد القائمة الذكي</span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#D4AF37]/20 text-[#D4AF37] font-mono">
                    AI
                  </span>
                </h4>
                <p className="text-[10px] text-[#7E8699]">إجابات حصرية من قائمة {restaurantName}</p>
              </div>
            </div>

            <button
              onClick={() => {
                abortControllerRef.current?.abort();
                setIsOpen(false);
              }}
              className="p-1 rounded-lg text-[#7E8699] hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
              aria-label="إغلاق المساعد"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-3.5 overflow-y-auto space-y-3 text-xs">
            {messages.map(msg => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.sender === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-[#D4AF37] text-black font-semibold rounded-br-xs'
                      : msg.isError
                      ? 'bg-rose-950/40 border border-rose-900/40 text-rose-200 rounded-bl-xs'
                      : 'bg-[#171A26] border border-[#23293C] text-[#E0E2EC] rounded-bl-xs'
                  }`}
                >
                  <p>{msg.text}</p>

                  {/* Grounded Item Cards if mentioned in response */}
                  {msg.suggestedItems && msg.suggestedItems.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-white/10 space-y-1.5">
                      {msg.suggestedItems.map(itemId => {
                        const item = availableItems.find(it => it.id === itemId);
                        if (!item) return null;
                        return (
                          <div
                            key={item.id}
                            className="p-2 rounded-lg bg-black/30 border border-white/5 flex items-center justify-between gap-2"
                          >
                            <div className="min-w-0">
                              <p className="font-bold text-white truncate text-[11px]">{item.name}</p>
                              <span className="font-mono text-[10px] text-[#D4AF37]">
                                {item.price} {currency}
                              </span>
                            </div>
                            <button
                              onClick={() => onAddToCart(item)}
                              className="px-2 py-1 rounded bg-[#D4AF37] text-black text-[10px] font-bold flex items-center gap-1 hover:bg-[#e0be4d] shrink-0 cursor-pointer"
                            >
                              <Plus className="w-3 h-3" />
                              <span>إضافة</span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex items-start">
                <div className="p-3 rounded-2xl rounded-bl-xs bg-[#171A26] border border-[#23293C] text-xs text-[#8E95A8] flex items-center gap-2">
                  <Loader2 className="w-3.5 h-3.5 text-[#D4AF37] animate-spin" />
                  <span>جاري مراجعة أطباق القائمة...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Suggestion Pills */}
          {!rateLimited && (
            <div className="p-2 bg-[#12141F] border-t border-[#1C202E] flex items-center gap-1.5 overflow-x-auto text-[11px]">
              {quickQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(q)}
                  disabled={loading}
                  className="px-2.5 py-1 rounded-full bg-[#181B27] border border-[#272D3E] text-[#8E95A8] hover:text-white hover:border-[#D4AF37] whitespace-nowrap shrink-0 transition-colors cursor-pointer"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* Input Bar */}
          <div className="p-2.5 bg-[#141722] border-t border-[#202534]">
            {rateLimited ? (
              <div className="p-2 text-center text-[11px] text-amber-300 bg-amber-950/20 rounded-lg">
                لقد وصلت للحد المؤقت لأسئلة المساعد. يمكنك متابعة تصفح القائمة مباشرة.
              </div>
            ) : (
              <form
                onSubmit={e => {
                  e.preventDefault();
                  handleSendMessage();
                }}
                className="flex items-center gap-1.5"
              >
                <input
                  type="text"
                  placeholder="اسأل عن أي طبق، مكوّن، أو اقتراح..."
                  value={inputMessage}
                  onChange={e => setInputMessage(e.target.value)}
                  disabled={loading}
                  className="flex-1 bg-[#0E1016] border border-[#222736] text-white text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-[#D4AF37]"
                />
                <Button
                  type="submit"
                  size="sm"
                  variant="primary"
                  disabled={!inputMessage.trim() || loading}
                  className="px-3 py-2"
                >
                  <Send className="w-3.5 h-3.5" />
                </Button>
              </form>
            )}
          </div>
        </div>
      )}
    </>
  );
};
