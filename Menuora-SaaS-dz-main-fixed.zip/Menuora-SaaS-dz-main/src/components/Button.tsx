import React from 'react';
import { Loader2 } from 'lucide-react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  icon,
  className = '',
  disabled,
  ...props
}) => {
  const baseStyles = 'inline-flex items-center justify-center font-medium transition-all duration-200 cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 select-none whitespace-nowrap shrink-0 active:scale-[0.98]';

  const sizeStyles = {
    sm: 'text-xs px-3 py-1.5 rounded-md gap-1.5',
    md: 'text-sm px-4 py-2 rounded-lg gap-2',
    lg: 'text-base px-6 py-2.5 rounded-xl gap-2.5'
  };

  const variantStyles = {
    primary: 'bg-[#D4AF37] text-[#0B0C10] font-semibold hover:bg-[#e0be4d] shadow-sm hover:shadow-[0_0_15px_rgba(212,175,55,0.25)]',
    secondary: 'bg-[#181B24] text-[#E0E2EC] border border-[#272B3A] hover:bg-[#202533] hover:border-[#3B4259]',
    outline: 'bg-transparent text-[#D4AF37] border border-[#D4AF37]/50 hover:bg-[#D4AF37]/10 hover:border-[#D4AF37]',
    danger: 'bg-rose-950/40 text-rose-300 border border-rose-800/50 hover:bg-rose-900/60',
    ghost: 'bg-transparent text-[#9CA3AF] hover:text-white hover:bg-white/5'
  };

  return (
    <button
      className={`${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <Loader2 className="w-4 h-4 animate-spin shrink-0" />
      ) : icon ? (
        <span className="shrink-0">{icon}</span>
      ) : null}
      <span>{children}</span>
    </button>
  );
};
