import React from 'react';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
  icon?: React.ReactNode;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, hint, icon, className = '', id, ...props }, ref) => {
    const inputId = id || (label ? label.replace(/\s+/g, '-').toLowerCase() : undefined);

    return (
      <div className="w-full flex flex-col gap-1.5 text-right">
        {label && (
          <label htmlFor={inputId} className="text-xs font-semibold text-[#C4C7D5]">
            {label}
            {props.required && <span className="text-rose-400 ms-1">*</span>}
          </label>
        )}
        <div className="relative flex items-center">
          {icon && (
            <div className="absolute start-3 text-[#6B7280] pointer-events-none flex items-center">
              {icon}
            </div>
          )}
          <input
            id={inputId}
            ref={ref}
            className={`w-full bg-[#12141C] border border-[#232736] text-[#F3F4F6] text-sm rounded-lg px-3.5 py-2.5 transition-colors placeholder:text-[#52586B] focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37] disabled:opacity-50 disabled:bg-[#0E1017] ${
              icon ? 'ps-10' : ''
            } ${error ? 'border-rose-500 focus:border-rose-500 focus:ring-rose-500' : ''} ${className}`}
            {...props}
          />
        </div>
        {error && <span className="text-xs text-rose-400">{error}</span>}
        {hint && !error && <span className="text-xs text-[#6B7280]">{hint}</span>}
      </div>
    );
  }
);

Input.displayName = 'Input';
