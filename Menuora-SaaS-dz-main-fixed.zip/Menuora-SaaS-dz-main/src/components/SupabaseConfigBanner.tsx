import React, { useState } from 'react';
import { Database, ExternalLink, Copy, Check, ChevronDown, ChevronUp } from 'lucide-react';
import { isSupabaseConfigured } from '../lib/supabase';
import { Button } from './Button';
import { Modal } from './Modal';

export const SupabaseConfigBanner: React.FC = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  if (isSupabaseConfigured) return null;

  const copyEnvSnippet = () => {
    navigator.clipboard.writeText(`VITE_SUPABASE_URL="https://your-project-ref.supabase.co"
VITE_SUPABASE_ANON_KEY="your-anon-key-here"`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <>
      <div className="bg-gradient-to-r from-amber-950/70 via-[#1F1708] to-amber-950/70 border-b border-amber-600/30 px-4 py-2.5 text-xs text-amber-200">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-[#D4AF37] shrink-0" />
            <span>
              <strong>تنبيه الإعداد السحابي:</strong> لم يتم ربط مشروع Supabase بعد. البيانات الحالية ستتصل تلقائياً بمجرد إضافة المفاتيح في ملف <code className="bg-black/40 px-1.5 py-0.5 rounded text-amber-300">.env</code>.
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setModalOpen(true)}
              className="text-xs py-1 px-2.5 h-auto border-amber-500/40 text-amber-300 hover:bg-amber-500/10"
            >
              تعليمات الربط وقاعدة البيانات
            </Button>
          </div>
        </div>
      </div>

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="دليل ربط Supabase وقاعدة البيانات PostgreSQL"
        description="خطوات سريعة لتفعيل الحسابات، الصور، وطلبات Realtime"
        maxWidth="lg"
      >
        <div className="space-y-4 text-xs text-[#C4C7D5] leading-relaxed">
          <div className="p-3 bg-[#151822] rounded-xl border border-[#272B3A]">
            <h5 className="font-bold text-white mb-1.5 text-sm">1. إنشاء مشروع على Supabase</h5>
            <p>سجل حساباً مجانياً على <a href="https://supabase.com" target="_blank" rel="noreferrer" className="text-[#D4AF37] underline inline-flex items-center gap-1">supabase.com <ExternalLink className="w-3 h-3" /></a> وأنشئ مشروعاً جديداً.</p>
          </div>

          <div className="p-3 bg-[#151822] rounded-xl border border-[#272B3A]">
            <div className="flex items-center justify-between mb-1.5">
              <h5 className="font-bold text-white text-sm">2. إضافة مفاتيح المشروع إلى .env</h5>
              <button
                onClick={copyEnvSnippet}
                className="text-xs text-[#D4AF37] hover:underline flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'تم النسخ' : 'نسخ المتغيرات'}
              </button>
            </div>
            <pre className="p-2.5 bg-black/50 rounded-lg text-emerald-300 font-mono text-[11px] overflow-x-auto text-left" dir="ltr">
{`VITE_SUPABASE_URL="https://your-project.supabase.co"
VITE_SUPABASE_ANON_KEY="your-anon-public-key"`}
            </pre>
          </div>

          <div className="p-3 bg-[#151822] rounded-xl border border-[#272B3A]">
            <h5 className="font-bold text-white mb-1.5 text-sm">3. تنفيذ مخطط الجداول (SQL Schema & RLS)</h5>
            <p>
              توجه إلى <strong>SQL Editor</strong> في لوحة تحكم Supabase، وقم بلصق محتويات الملف المجهز بالكامل في مشروعك:
              <br />
              <code className="text-[#D4AF37] font-mono font-bold mt-1 inline-block">supabase/schema.sql</code>
            </p>
            <p className="mt-1 text-[#8E95A8]">
              يتضمن الجداول (profiles, restaurants, menu_items, categories, tables, orders, ai_usage)، وصلاحيات الأمان RLS وقواعد مجلدات التخزين Storage Buckets.
            </p>
          </div>

          <div className="p-3 bg-[#151822] rounded-xl border border-[#272B3A]">
            <h5 className="font-bold text-white mb-1.5 text-sm">4. تفعيل أسرار الذكاء الاصطناعي (Edge Function Secrets)</h5>
            <p>
              تُحفظ مفاتيح الـ AI حصراً على السيرفر في <strong>Supabase Edge Function Secrets</strong> لحماية قصوى:
            </p>
            <pre className="p-2.5 bg-black/50 rounded-lg text-amber-300 font-mono text-[11px] overflow-x-auto text-left mt-1.5" dir="ltr">
{`supabase secrets set AI_PROVIDER="gemini"
supabase secrets set GEMINI_API_KEY="your-gemini-key"`}
            </pre>
          </div>
        </div>
      </Modal>
    </>
  );
};
