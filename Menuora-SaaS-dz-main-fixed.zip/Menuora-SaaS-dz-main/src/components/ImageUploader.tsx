import React, { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, RefreshCw, Trash2, Camera } from 'lucide-react';
import { validateImageFile } from '../utils/validators';
import { Button } from './Button';

export interface ImageUploaderProps {
  label?: string;
  initialImageUrl?: string | null;
  onFileSelect: (file: File | null) => void;
  error?: string;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({
  label = 'صورة المنتج',
  initialImageUrl,
  onFileSelect,
  error
}) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(initialImageUrl || null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleProcessFile = (file: File) => {
    setValidationError(null);
    const validation = validateImageFile(file);
    if (!validation.valid) {
      setValidationError(validation.error || 'الملف غير صالح');
      return;
    }

    // Create object URL for instant preview
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
    onFileSelect(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
  };

  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPreviewUrl(null);
    setValidationError(null);
    if (inputRef.current) inputRef.current.value = '';
    onFileSelect(null);
  };

  const handleTriggerPicker = () => {
    inputRef.current?.click();
  };

  return (
    <div className="w-full flex flex-col gap-2 text-right">
      {label && <label className="text-xs font-semibold text-[#C4C7D5]">{label}</label>}

      {/* Hidden file input */}
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/jpg"
        onChange={handleFileChange}
        className="hidden"
      />

      {previewUrl ? (
        /* Image Preview Box */
        <div className="relative group rounded-xl overflow-hidden border border-[#2B3042] bg-[#12141D] aspect-video sm:aspect-2/1 flex items-center justify-center">
          <img
            src={previewUrl}
            alt="معاينة الصورة"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          {/* Overlay Actions */}
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 p-3">
            <Button
              type="button"
              size="sm"
              variant="secondary"
              onClick={handleTriggerPicker}
              icon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              استبدال الصورة
            </Button>
            <Button
              type="button"
              size="sm"
              variant="danger"
              onClick={handleRemove}
              icon={<Trash2 className="w-3.5 h-3.5" />}
            >
              إزالة
            </Button>
          </div>
        </div>
      ) : (
        /* Empty Upload Dropzone */
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={handleTriggerPicker}
          className={`flex flex-col items-center justify-center p-5 rounded-xl border border-dashed transition-all cursor-pointer text-center bg-[#10121A] ${
            isDragging
              ? 'border-[#D4AF37] bg-[#D4AF37]/5'
              : 'border-[#272B3A] hover:border-[#3E455D] hover:bg-[#141722]'
          }`}
        >
          <div className="w-10 h-10 rounded-xl bg-[#191D28] border border-[#262C3C] flex items-center justify-center text-[#D4AF37] mb-2.5">
            <Upload className="w-5 h-5" />
          </div>

          <p className="text-xs sm:text-sm font-semibold text-white mb-1">
            اسحب الصورة هنا أو اضغط للاختيار
          </p>
          <p className="text-[11px] text-[#7E8597] mb-3">
            الصيغ المعتمدة: JPG, PNG, WEBP (بحد أقصى 5 ميجابايت)
          </p>

          {/* Quick Mobile Gallery / Camera Button */}
          <div className="sm:hidden w-full pt-1">
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="w-full"
              icon={<Camera className="w-4 h-4" />}
            >
              إضافة صورة من المعرض
            </Button>
          </div>
        </div>
      )}

      {(validationError || error) && (
        <span className="text-xs text-rose-400 font-medium">
          {validationError || error}
        </span>
      )}
    </div>
  );
};
