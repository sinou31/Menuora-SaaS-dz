import React from 'react';
import { Loader2 } from 'lucide-react';

export const LoadingSpinner: React.FC<{ message?: string; fullScreen?: boolean }> = ({
  message = 'جاري التحميل...',
  fullScreen = false
}) => {
  const content = (
    <div className="flex flex-col items-center justify-center gap-3 p-6 text-center">
      <Loader2 className="w-8 h-8 text-[#D4AF37] animate-spin" />
      <span className="text-xs text-[#8E95A8] font-medium">{message}</span>
    </div>
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 z-50 bg-[#0B0C10] flex items-center justify-center">
        {content}
      </div>
    );
  }

  return content;
};
