/**
 * Supabase Client Initialization
 * Strictly uses VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
 * NEVER include Service Role Key or database credentials in client code
 */
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL as string)?.trim() || '';
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string)?.trim() || '';

// Detect whether user has configured real Supabase credentials
export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  supabaseUrl.startsWith('https://') &&
  !supabaseUrl.includes('your-project-ref') &&
  !supabaseAnonKey.includes('your-anon-key')
);

// Fallback dummy URL to prevent createClient from crashing if env is not configured yet
const safeUrl = isSupabaseConfigured ? supabaseUrl : 'https://placeholder-instance.supabase.co';
const safeKey = isSupabaseConfigured ? supabaseAnonKey : 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.dummy';

export const supabase = createClient(safeUrl, safeKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: 'restaurant_qr_saas_auth_token'
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
});
