/**
 * Production QR Code Generator using QRCode library
 * Generates high-resolution data URLs and handles direct download
 */
import QRCode from 'qrcode';

export interface QRGenerationOptions {
  width?: number;
  margin?: number;
  color?: {
    dark: string;
    light: string;
  };
}

export async function generateQRDataUrl(
  text: string,
  options: QRGenerationOptions = {}
): Promise<string> {
  const {
    width = 600,
    margin = 2,
    color = {
      dark: '#0B0C10',
      light: '#FFFFFF'
    }
  } = options;

  try {
    return await QRCode.toDataURL(text, {
      width,
      margin,
      color,
      errorCorrectionLevel: 'H'
    });
  } catch (err) {
    console.error('Failed to generate QR Code:', err);
    throw new Error('فشل إنشاء رمز QR');
  }
}

export function downloadQRImage(dataUrl: string, fileName: string) {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = `${fileName}.png`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
