/**
 * Dashboard Real Statistics Service
 * Calculates actual metrics strictly from Supabase PostgreSQL tables
 * ZERO mock numbers or Math.random()
 */
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { DashboardStats } from '../types/database.types';

export const statsService = {
  /**
   * Fetch real aggregated stats for a restaurant
   */
  async getDashboardStats(restaurantId: string): Promise<DashboardStats> {
    if (!isSupabaseConfigured || !restaurantId) {
      return {
        todayOrdersCount: 0,
        totalOrdersCount: 0,
        productsCount: 0,
        categoriesCount: 0,
        tablesCount: 0,
        menuViewsCount: 0,
        todayRevenue: 0
      };
    }

    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const startOfTodayIso = startOfToday.toISOString();

    // 1. Total & Today's Orders & Today's Revenue
    const [
      totalOrdersRes,
      todayOrdersRes,
      productsRes,
      categoriesRes,
      tablesRes,
      viewsRes
    ] = await Promise.all([
      supabase.from('orders').select('*', { count: 'exact', head: true }).eq('restaurant_id', restaurantId),
      supabase.from('orders').select('total, status').eq('restaurant_id', restaurantId).gte('created_at', startOfTodayIso),
      supabase.from('menu_items').select('*', { count: 'exact', head: true }).eq('restaurant_id', restaurantId),
      supabase.from('categories').select('*', { count: 'exact', head: true }).eq('restaurant_id', restaurantId),
      supabase.from('tables').select('*', { count: 'exact', head: true }).eq('restaurant_id', restaurantId),
      supabase.from('menu_views').select('*', { count: 'exact', head: true }).eq('restaurant_id', restaurantId)
    ]);

    const totalOrdersCount = totalOrdersRes.count || 0;
    const todayOrders = todayOrdersRes.data || [];
    const todayOrdersCount = todayOrders.length;

    // Calculate revenue from non-cancelled orders today
    const todayRevenue = todayOrders
      .filter(o => o.status !== 'cancelled')
      .reduce((sum, o) => sum + Number(o.total || 0), 0);

    const productsCount = productsRes.count || 0;
    const categoriesCount = categoriesRes.count || 0;
    const tablesCount = tablesRes.count || 0;
    const menuViewsCount = viewsRes.count || 0;

    return {
      todayOrdersCount,
      totalOrdersCount,
      productsCount,
      categoriesCount,
      tablesCount,
      menuViewsCount,
      todayRevenue: Number(todayRevenue.toFixed(2))
    };
  },

  /**
   * Record a menu view hit (public analytics)
   */
  async recordMenuView(restaurantId: string, tableId?: string | null): Promise<void> {
    if (!isSupabaseConfigured || !restaurantId) return;

    try {
      await supabase.from('menu_views').insert({
        restaurant_id: restaurantId,
        table_id: tableId || null
      });
    } catch (err) {
      // Non-blocking telemetry
      console.warn('Could not record view:', err);
    }
  }
};
