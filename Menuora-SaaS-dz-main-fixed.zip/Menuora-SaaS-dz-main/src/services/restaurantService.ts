
/**
 * Restaurant Data Service
 * Supabase PostgreSQL integration
 *
 * All authorization must be enforced by Supabase RLS.
 * Never expose the service-role key in frontend code.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase';
import type {
  Restaurant,
  RestaurantStatus,
} from '../types/database.types';

const ALLOWED_RESTAURANT_STATUSES: RestaurantStatus[] = [
  'pending',
  'approved',
  'suspended',
  'rejected',
];

export const restaurantService = {
  /**
   * Get restaurant owned by user ID.
   */
  async getRestaurantByOwner(
    ownerId: string
  ): Promise<Restaurant | null> {
    if (!isSupabaseConfigured) {
      throw new Error('Supabase غير مهيأ. تحقق من إعدادات الاتصال.');
    }

    if (!ownerId) {
      throw new Error('لم يتم العثور على معرّف المستخدم المسجل دخوله.');
    }

    const { data, error } = await supabase
      .from('restaurants')
      .select('*')
      .eq('owner_id', ownerId)
      .maybeSingle();

    if (error) {
      console.error(
        '[RestaurantService] Failed to fetch restaurant:',
        error
      );
      throw new Error(`تعذر جلب بيانات المطعم: ${error.message}`);
    }

    return data as Restaurant | null;
  },

  /**
   * Get approved restaurant by slug for the public menu.
   */
  async getRestaurantBySlug(
    slug: string
  ): Promise<Restaurant | null> {
    if (!isSupabaseConfigured) {
      throw new Error('Supabase غير مهيأ.');
    }

    if (!slug?.trim()) {
      return null;
    }

    const { data, error } = await supabase
      .from('restaurants')
      .select('*')
      .eq('slug', slug.trim())
      .eq('status', 'approved')
      .maybeSingle();

    if (error) {
      console.error(
        '[RestaurantService] Error fetching restaurant:',
        error
      );
      throw new Error(`تعذر جلب المطعم: ${error.message}`);
    }

    return data as Restaurant | null;
  },

  /**
   * Create a new restaurant.
   * Keeps the existing owner registration flow.
   * Database RLS must validate owner_id against auth.uid().
   */
  async createRestaurant(
    ownerId: string,
    payload: {
      name: string;
      slug: string;
      city?: string;
      address?: string;
      description?: string;
      phone?: string;
    }
  ): Promise<Restaurant> {
    if (!isSupabaseConfigured) {
      throw new Error('Supabase غير مهيأ. تحقق من إعدادات الاتصال.');
    }

    if (!ownerId) {
      throw new Error('لا يمكن إنشاء مطعم دون معرّف مالك صالح.');
    }

    if (!payload.name?.trim()) {
      throw new Error('اسم المطعم مطلوب.');
    }

    if (!payload.slug?.trim()) {
      throw new Error('معرّف المطعم (Slug) مطلوب.');
    }

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      throw new Error('يجب تسجيل الدخول قبل إنشاء المطعم.');
    }

    if (user.id !== ownerId) {
      throw new Error('لا يمكنك إنشاء مطعم باسم مستخدم آخر.');
    }

    const { data, error } = await supabase
      .from('restaurants')
      .insert({
        owner_id: user.id,
        name: payload.name.trim(),
        slug: payload.slug.trim(),
        city: payload.city?.trim() || null,
        address: payload.address?.trim() || null,
        description: payload.description?.trim() || null,
        phone: payload.phone?.trim() || null,
        status: 'pending',
        currency: 'DZD',
        country: 'DZ',
      })
      .select('*')
      .single();

    if (error) {
      console.error(
        '[RestaurantService] Error creating restaurant:',
        error
      );

      if (error.code === '23505') {
        throw new Error('معرّف المطعم مستخدم بالفعل. اختر معرّفًا آخر.');
      }

      throw new Error(`خطأ في إنشاء المطعم: ${error.message}`);
    }

    return data as Restaurant;
  },

  /**
   * Update restaurant profile settings.
   * RLS must restrict updates to the restaurant owner.
   */
  async updateRestaurant(
    restaurantId: string,
    updates: Partial<Restaurant>
  ): Promise<Restaurant> {
    if (!isSupabaseConfigured) {
      throw new Error('Supabase غير مهيأ.');
    }

    if (!restaurantId) {
      throw new Error('معرّف المطعم غير موجود.');
    }

    const {
      id: _id,
      owner_id: _ownerId,
      created_at: _createdAt,
      ...safeUpdates
    } = updates;

    // Prevent profile editing from changing approval status.
    delete (safeUpdates as Partial<Restaurant>).status;

    const { data, error } = await supabase
      .from('restaurants')
      .update({
        ...safeUpdates,
        updated_at: new Date().toISOString(),
      })
      .eq('id', restaurantId)
      .select('*')
      .single();

    if (error) {
      console.error(
        '[RestaurantService] Error updating restaurant:',
        error
      );
      throw new Error(`فشل تحديث بيانات المطعم: ${error.message}`);
    }

    return data as Restaurant;
  },

  /**
   * Super Admin: Get all restaurants.
   * The database RLS policy must authorize super_admin access.
   */
  async getAllRestaurantsAdmin(): Promise<Restaurant[]> {
    if (!isSupabaseConfigured) {
      throw new Error('Supabase غير مهيأ.');
    }

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      throw new Error('يجب تسجيل الدخول للوصول إلى لوحة الإدارة.');
    }

    const { data, error } = await supabase
      .from('restaurants')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error(
        '[RestaurantService] Error fetching all restaurants:',
        error
      );

      if (error.code === '42501') {
        throw new Error(
          'ليس لديك صلاحية عرض جميع المطاعم. تحقق من دور المشرف وسياسات RLS.'
        );
      }

      throw new Error(`فشل جلب المطاعم: ${error.message}`);
    }

    return (data ?? []) as Restaurant[];
  },

  /**
   * Super Admin: Update restaurant status.
   * RLS remains the source of authorization.
   */
  async updateRestaurantStatusAdmin(
    restaurantId: string,
    status: RestaurantStatus
  ): Promise<void> {
    if (!isSupabaseConfigured) {
      throw new Error('Supabase غير مهيأ.');
    }

    if (!restaurantId?.trim()) {
      throw new Error('معرّف المطعم غير موجود.');
    }

    if (!ALLOWED_RESTAURANT_STATUSES.includes(status)) {
      throw new Error('حالة المطعم المطلوبة غير صالحة.');
    }

    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      throw new Error('انتهت جلسة الدخول أو تعذّر التحقق منها. سجّل الدخول مجددًا.');
    }

    const { data, error } = await supabase
      .from('restaurants')
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .eq('id', restaurantId)
      .select('id, status')
      .maybeSingle();

    if (error) {
      console.error(
        '[RestaurantService] Error updating restaurant status:',
        error
      );

      if (error.code === '42501') {
        throw new Error(
          'ليس لديك صلاحية تغيير حالة المطعم. تحقق من دور المشرف وسياسات RLS.'
        );
      }

      throw new Error(`فشل تحديث حالة المطعم: ${error.message}`);
    }

    if (!data) {
      throw new Error(
        'لم يتم تحديث المطعم. قد لا يكون موجودًا أو قد تمنع سياسات RLS هذا الإجراء.'
      );
    }
  },
};
