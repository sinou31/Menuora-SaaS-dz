/**
 * Orders Service
 * Real Supabase PostgreSQL database operations
 * Strict server-side price verification inside the database (Requirement 38)
 */
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Order, OrderStatus } from '../types/database.types';

export interface CartOrderEntry {
  menuItemId: string;
  quantity: number;
}

export const orderService = {
  /**
   * Get orders for restaurant with optional status filter
   */
  async getOrders(restaurantId: string, status?: OrderStatus): Promise<Order[]> {
    if (!isSupabaseConfigured || !restaurantId) return [];

    let query = supabase
      .from('orders')
      .select(`
        *,
        table:tables(id, name, number),
        order_items:order_items(id, menu_item_id, item_name, quantity, price)
      `)
      .eq('restaurant_id', restaurantId)
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    const { data, error } = await query;
    if (error) {
      console.error('Error fetching orders:', error);
      throw error;
    }
    return (data as Order[]) || [];
  },

  /**
   * Update order status
   */
  async updateOrderStatus(orderId: string, status: OrderStatus): Promise<void> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    const { error } = await supabase
      .from('orders')
      .update({
        status,
        updated_at: new Date().toISOString()
      })
      .eq('id', orderId);

    if (error) throw new Error(`فشل تحديث حالة الطلب: ${error.message}`);
  },

  /**
   * Secure Customer Order Creation
   * Delegates to the `create_customer_order` database function (see supabase/schema.sql).
   * Prices, availability, table ownership and the order total are all verified and
   * computed INSIDE the database in one transaction, so a modified client can never
   * change a price. (Anonymous customers also have no SELECT/INSERT access to the
   * orders tables, so a direct insert from the browser is not possible.)
   */
  async createCustomerOrder(payload: {
    restaurantId: string;
    tableId?: string | null;
    customerName: string;
    customerPhone: string;
    notes?: string;
    cart: CartOrderEntry[];
  }): Promise<Order> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    if (!payload.cart || payload.cart.length === 0) {
      throw new Error('سلة الطلبات فارغة');
    }

    const items = payload.cart.map(c => ({
      menu_item_id: c.menuItemId,
      quantity: Math.max(1, Math.floor(Number(c.quantity) || 1))
    }));

    const { data, error } = await supabase.rpc('create_customer_order', {
      p_restaurant_id: payload.restaurantId,
      p_table_id: payload.tableId || null,
      p_customer_name: payload.customerName?.trim() || '',
      p_customer_phone: payload.customerPhone?.trim() || '',
      p_notes: payload.notes?.trim() || '',
      p_items: items
    });

    if (error || !data) {
      console.error('create_customer_order failed:', error);
      throw new Error(error?.message || 'فشل إنشاء الطلب. حاول مرة أخرى.');
    }

    return data as unknown as Order;
  }
};
