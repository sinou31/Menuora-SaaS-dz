/**
 * Categories Service
 * Real Supabase PostgreSQL database operations
 */
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Category } from '../types/database.types';

export const categoryService = {
  async getCategories(restaurantId: string): Promise<Category[]> {
    if (!isSupabaseConfigured || !restaurantId) return [];

    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('restaurant_id', restaurantId)
      .order('sort_order', { ascending: true })
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Error fetching categories:', error);
      throw error;
    }
    return data || [];
  },

  async getActiveCategories(restaurantId: string): Promise<Category[]> {
    if (!isSupabaseConfigured || !restaurantId) return [];

    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('restaurant_id', restaurantId)
      .eq('is_active', true)
      .order('sort_order', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  async createCategory(restaurantId: string, payload: {
    name: string;
    description?: string | null;
    sort_order?: number;
    is_active?: boolean;
  }): Promise<Category> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    const { data, error } = await supabase
      .from('categories')
      .insert({
        restaurant_id: restaurantId,
        name: payload.name.trim(),
        description: payload.description?.trim() || null,
        sort_order: payload.sort_order ?? 0,
        is_active: payload.is_active ?? true
      })
      .select()
      .single();

    if (error) throw new Error(`فشل إنشاء التصنيف: ${error.message}`);
    return data;
  },

  async updateCategory(categoryId: string, updates: Partial<Category>): Promise<Category> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    const { data, error } = await supabase
      .from('categories')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', categoryId)
      .select()
      .single();

    if (error) throw new Error(`فشل تحديث التصنيف: ${error.message}`);
    return data;
  },

  async deleteCategory(categoryId: string): Promise<void> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    const { error } = await supabase
      .from('categories')
      .delete()
      .eq('id', categoryId);

    if (error) throw new Error(`فشل حذف التصنيف: ${error.message}`);
  }
};
