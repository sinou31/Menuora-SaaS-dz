/**
 * Menu Items Service
 * Real Supabase PostgreSQL database operations
 */
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { MenuItem } from '../types/database.types';
import { storageService } from './storageService';

export const menuItemService = {
  async getMenuItems(restaurantId: string): Promise<MenuItem[]> {
    if (!isSupabaseConfigured || !restaurantId) return [];

    const { data, error } = await supabase
      .from('menu_items')
      .select('*')
      .eq('restaurant_id', restaurantId)
      .order('sort_order', { ascending: true })
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching menu items:', error);
      throw error;
    }
    return data || [];
  },

  async getPublicMenuItems(restaurantId: string): Promise<MenuItem[]> {
    if (!isSupabaseConfigured || !restaurantId) return [];

    const { data, error } = await supabase
      .from('menu_items')
      .select('*')
      .eq('restaurant_id', restaurantId)
      .eq('is_available', true)
      .order('sort_order', { ascending: true })
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async createMenuItem(restaurantId: string, payload: {
    name: string;
    description?: string | null;
    price: number;
    category_id?: string | null;
    image_path?: string | null;
    image_url?: string | null;
    is_available?: boolean;
    is_featured?: boolean;
    sort_order?: number;
  }): Promise<MenuItem> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    if (payload.price < 0) {
      throw new Error('يجب أن يكون السعر رقماً موجباً أكبر من أو يساوي الصفر.');
    }

    const { data, error } = await supabase
      .from('menu_items')
      .insert({
        restaurant_id: restaurantId,
        name: payload.name.trim(),
        description: payload.description?.trim() || null,
        price: Number(payload.price),
        category_id: payload.category_id || null,
        image_path: payload.image_path || null,
        image_url: payload.image_url || null,
        is_available: payload.is_available ?? true,
        is_featured: payload.is_featured ?? false,
        sort_order: payload.sort_order ?? 0
      })
      .select()
      .single();

    if (error) throw new Error(`فشل حفظ المنتج: ${error.message}`);
    return data;
  },

  async updateMenuItem(id: string, updates: Partial<MenuItem>): Promise<MenuItem> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    if (updates.price !== undefined && updates.price < 0) {
      throw new Error('يجب أن يكون السعر رقماً موجباً.');
    }

    const { data, error } = await supabase
      .from('menu_items')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw new Error(`فشل تحديث المنتج: ${error.message}`);
    return data;
  },

  async toggleAvailability(id: string, currentStatus: boolean): Promise<boolean> {
    const nextStatus = !currentStatus;
    await this.updateMenuItem(id, { is_available: nextStatus });
    return nextStatus;
  },

  async toggleFeatured(id: string, currentStatus: boolean): Promise<boolean> {
    const nextStatus = !currentStatus;
    await this.updateMenuItem(id, { is_featured: nextStatus });
    return nextStatus;
  },

  async duplicateMenuItem(item: MenuItem): Promise<MenuItem> {
    return await this.createMenuItem(item.restaurant_id, {
      name: `${item.name} (نسخة)`,
      description: item.description,
      price: item.price,
      category_id: item.category_id,
      image_path: item.image_path,
      image_url: item.image_url,
      is_available: item.is_available,
      is_featured: false,
      sort_order: item.sort_order + 1
    });
  },

  async deleteMenuItem(id: string, imagePath?: string | null): Promise<void> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    const { error } = await supabase
      .from('menu_items')
      .delete()
      .eq('id', id);

    if (error) throw new Error(`فشل حذف المنتج: ${error.message}`);

    // Clean the image up from storage, but only if no other item (e.g. a duplicate
    // created with "نسخ مكرر") still points to the same file.
    if (imagePath) {
      const { count } = await supabase
        .from('menu_items')
        .select('id', { count: 'exact', head: true })
        .eq('image_path', imagePath);

      if (!count) {
        await storageService.deleteImage('menu-images', imagePath);
      }
    }
  }
};
