/**
 * Supabase Storage Service
 * Handles secure image uploads, compression, path generation, and cleanup
 */
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { validateImageFile } from '../utils/validators';
import { compressImage } from '../lib/imageCompressor';

export interface UploadResult {
  path: string;
  url: string;
}

export const storageService = {
  /**
   * Upload menu item image
   * Validates file -> compresses on client -> uploads to menu-images/restaurantId/...
   */
  async uploadProductImage(restaurantId: string, file: File): Promise<UploadResult> {
    if (!isSupabaseConfigured) {
      throw new Error('يرجى تهيئة بيانات Supabase (VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY) لتفعيل رفع الصور.');
    }

    const validation = validateImageFile(file);
    if (!validation.valid) {
      throw new Error(validation.error || 'الملف غير صالح');
    }

    // Client-side compression
    const compressed = await compressImage(file, {
      maxWidth: 1400,
      maxHeight: 1400,
      quality: 0.85,
      mimeType: 'image/webp'
    });

    const fileExt = compressed.type === 'image/png' ? 'png' : compressed.type === 'image/jpeg' ? 'jpg' : 'webp';
    const uniqueId = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 9);
    const filePath = `${restaurantId}/products/${Date.now()}_${uniqueId}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from('menu-images')
      .upload(filePath, compressed, {
        contentType: compressed.type || 'image/webp',
        upsert: false
      });

    if (uploadError) {
      console.error('Storage upload error:', uploadError);
      throw new Error(`فشل رفع الصورة: ${uploadError.message}`);
    }

    const { data: publicUrlData } = supabase.storage
      .from('menu-images')
      .getPublicUrl(filePath);

    return {
      path: filePath,
      url: publicUrlData.publicUrl
    };
  },

  /**
   * Upload restaurant logo or cover banner
   */
  async uploadRestaurantAsset(restaurantId: string, file: File, type: 'logo' | 'cover'): Promise<UploadResult> {
    if (!isSupabaseConfigured) {
      throw new Error('يرجى تهيئة بيانات Supabase لتفعيل رفع الملفات.');
    }

    const validation = validateImageFile(file);
    if (!validation.valid) {
      throw new Error(validation.error || 'الملف غير صالح');
    }

    const compressed = await compressImage(file, {
      maxWidth: type === 'logo' ? 600 : 1800,
      maxHeight: type === 'logo' ? 600 : 900,
      quality: 0.88,
      mimeType: 'image/webp'
    });

    const assetExt = compressed.type === 'image/png' ? 'png' : compressed.type === 'image/jpeg' ? 'jpg' : 'webp';
    const filePath = `${restaurantId}/${type}_${Date.now()}.${assetExt}`;

    const { error: uploadError } = await supabase.storage
      .from('restaurant-assets')
      .upload(filePath, compressed, {
        contentType: compressed.type || 'image/webp',
        upsert: true
      });

    if (uploadError) {
      throw new Error(`فشل رفع شعار أو غلاف المطعم: ${uploadError.message}`);
    }

    const { data: publicUrlData } = supabase.storage
      .from('restaurant-assets')
      .getPublicUrl(filePath);

    return {
      path: filePath,
      url: publicUrlData.publicUrl
    };
  },

  /**
   * Delete an image from storage
   */
  async deleteImage(bucket: 'menu-images' | 'restaurant-assets' | 'qr-codes', path: string): Promise<void> {
    if (!path || !isSupabaseConfigured) return;

    try {
      await supabase.storage.from(bucket).remove([path]);
    } catch (err) {
      console.warn('Storage delete warning:', err);
    }
  }
};
