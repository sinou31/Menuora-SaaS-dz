/**
 * Client-Side AI Service Layer
 * Communicates ONLY with Supabase Edge Functions
 * NO API keys or AI secrets are stored or called directly in Frontend
 */
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import {
  AIProductGeneratedResult,
  AITranslatedItem,
  AIMenuAssistantResponse,
  AIUsageSummary
} from '../types/database.types';

export interface GenerateDescriptionParams {
  restaurantId: string;
  productName: string;
  rawIngredients?: string;
  language?: string;
  tone?: string;
}

export interface TranslateMenuParams {
  restaurantId: string;
  sourceLang: string;
  targetLang: string;
  items: Array<{
    id: string;
    name: string;
    description?: string | null;
    ingredients?: string[];
  }>;
}

/**
 * supabase-js wraps non-2xx Edge Function replies in a FunctionsHttpError whose
 * `context` is the raw Response (there is NO `error.status`). Read the status and the
 * JSON body (our functions return { error } / { answer }) from it.
 */
async function readFunctionError(error: any): Promise<{ status?: number; message?: string; body?: any }> {
  const res = error?.context;
  if (res && typeof res.status === 'number') {
    let body: any = null;
    try {
      body = await res.clone().json();
    } catch {
      body = null;
    }
    return { status: res.status, message: body?.error || body?.message, body };
  }
  return { message: error?.message };
}

export const aiService = {
  /**
   * Request AI to generate a creative, structured product description
   * Output is strictly validated JSON
   */
  async generateProductDescription(
    params: GenerateDescriptionParams,
    signal?: AbortSignal
  ): Promise<AIProductGeneratedResult> {
    if (!isSupabaseConfigured) {
      throw new Error('يرجى ضبط بيانات Supabase لتفعيل ميزات الذكاء الاصطناعي.');
    }

    try {
      const { data, error } = await supabase.functions.invoke('ai-menu-manager', {
        body: {
          action: 'generate_product_description',
          restaurantId: params.restaurantId,
          productName: params.productName,
          rawIngredients: params.rawIngredients,
          language: params.language || 'ar',
          tone: params.tone || 'appetizing'
        },
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (error) {
        const info = await readFunctionError(error);
        if (info.status === 401) {
          throw new Error('انتهت صلاحية الجلسة، يرجى تسجيل الدخول مجدداً.');
        }
        if (info.status === 403) {
          throw new Error('غير مصرح لك بتوليد وصف منتج لهذا المطعم.');
        }
        if (info.status === 429) {
          throw new Error('تم تجاوز حد الطلبات المسموح به مؤقتاً. حاول لاحقاً.');
        }
        throw new Error(info.message || 'تعذر الحصول على نتيجة صحيحة من الذكاء الاصطناعي، حاول مرة أخرى.');
      }

      if (!data?.success || !data?.data) {
        throw new Error('استجابة غير صالحة من خدمة الذكاء الاصطناعي.');
      }

      const res = data.data as AIProductGeneratedResult;
      // Client-Side validation layer
      if (!res.name || !res.description) {
        throw new Error('البيانات المستلمة من الذكاء الاصطناعي غير مكتملة.');
      }

      return {
        name: String(res.name).trim(),
        short_description: String(res.short_description || '').trim(),
        description: String(res.description).trim(),
        ingredients: Array.isArray(res.ingredients) ? res.ingredients.map(String) : [],
        tags: Array.isArray(res.tags) ? res.tags.map(String) : []
      };
    } catch (err: any) {
      console.error('aiService.generateProductDescription error:', err);
      throw new Error(err.message || 'خدمة الذكاء الاصطناعي غير متاحة حالياً. حاول مرة أخرى لاحقاً.');
    }
  },

  /**
   * Request AI to translate a batch of menu items (without translating prices or IDs)
   */
  async translateMenuItems(
    params: TranslateMenuParams,
    signal?: AbortSignal
  ): Promise<AITranslatedItem[]> {
    if (!isSupabaseConfigured) {
      throw new Error('يرجى ضبط بيانات Supabase لتفعيل ميزات الذكاء الاصطناعي.');
    }

    try {
      const { data, error } = await supabase.functions.invoke('ai-menu-manager', {
        body: {
          action: 'translate_menu',
          restaurantId: params.restaurantId,
          sourceLang: params.sourceLang,
          targetLang: params.targetLang,
          items: params.items
        }
      });

      if (error) {
        const info = await readFunctionError(error);
        throw new Error(info.message || 'فشلت عملية الترجمة بالذكاء الاصطناعي.');
      }

      if (!data?.success || !Array.isArray(data?.data)) {
        throw new Error('استجابة غير صحيحة من خدمة الترجمة.');
      }

      return data.data as AITranslatedItem[];
    } catch (err: any) {
      console.error('aiService.translateMenuItems error:', err);
      throw new Error(err.message || 'خدمة الترجمة الذكية غير متاحة حالياً.');
    }
  },

  /**
   * Public Customer Menu Assistant
   * Strictly grounded to available items of the restaurant with anti-injection protections
   */
  async askMenuAssistant(
    restaurantSlug: string,
    userMessage: string,
    sessionKey: string,
    signal?: AbortSignal
  ): Promise<AIMenuAssistantResponse> {
    if (!isSupabaseConfigured) {
      return {
        answer: 'المساعد الذكي يتطلب إعداد مفاتيح السحابة Supabase Edge Functions للعمل.'
      };
    }

    try {
      const { data, error } = await supabase.functions.invoke('ai-menu-assistant', {
        body: {
          restaurantSlug,
          userMessage,
          sessionKey
        }
      });

      if (error) {
        const info = await readFunctionError(error);
        if (info.status === 429) {
          return {
            answer: info.body?.answer || 'لقد وصلت إلى الحد المؤقت لاستخدام المساعد. حاول لاحقاً.',
            rateLimited: true
          };
        }
        if (info.status === 404 && info.body?.answer) {
          return { answer: info.body.answer, suggestedItems: [] };
        }
        throw new Error(info.message || error.message);
      }

      return {
        answer: data?.answer || 'تفضل بتصفح القائمة لمعرفة كافة الأطباق المتوفرة.',
        suggestedItems: Array.isArray(data?.suggestedItems) ? data.suggestedItems : [],
        rateLimited: Boolean(data?.rateLimited)
      };
    } catch (err: any) {
      console.error('aiService.askMenuAssistant error:', err);
      return {
        answer: 'خدمة المساعد الذكي غير متاحة حالياً. تفضل بتصفح القائمة مباشرة واختيار أطباقك المفضلة.'
      };
    }
  },

  /**
   * Fetch real AI Usage statistics from Supabase database
   * ZERO fake numbers
   */
  async getAIUsageStats(restaurantId: string): Promise<AIUsageSummary> {
    if (!isSupabaseConfigured || !restaurantId) {
      return {
        totalRequests: 0,
        productDescriptionsCount: 0,
        translationsCount: 0,
        assistantQueriesCount: 0,
        tokensUsed: 0,
        monthlyQuota: 500
      };
    }

    try {
      const { data, error } = await supabase
        .from('ai_usage')
        .select('*')
        .eq('restaurant_id', restaurantId);

      if (error) {
        console.warn('Error fetching AI usage from database:', error.message);
        return {
          totalRequests: 0,
          productDescriptionsCount: 0,
          translationsCount: 0,
          assistantQueriesCount: 0,
          tokensUsed: 0,
          monthlyQuota: 500
        };
      }

      const records = data || [];
      const totalRequests = records.length;
      const productDescriptionsCount = records.filter(r => r.feature === 'product_description').length;
      const translationsCount = records.filter(r => r.feature === 'menu_translation').length;
      const assistantQueriesCount = records.filter(r => r.feature === 'menu_assistant').length;
      const tokensUsed = records.reduce((sum, r) => sum + (r.tokens_used || 0), 0);

      return {
        totalRequests,
        productDescriptionsCount,
        translationsCount,
        assistantQueriesCount,
        tokensUsed,
        monthlyQuota: 500
      };
    } catch (err) {
      console.error('getAIUsageStats exception:', err);
      return {
        totalRequests: 0,
        productDescriptionsCount: 0,
        translationsCount: 0,
        assistantQueriesCount: 0,
        tokensUsed: 0,
        monthlyQuota: 500
      };
    }
  }
};
