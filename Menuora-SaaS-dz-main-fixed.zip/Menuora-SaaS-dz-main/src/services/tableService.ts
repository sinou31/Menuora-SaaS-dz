/**
 * Tables Service
 * Real Supabase PostgreSQL database operations
 */
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Table } from '../types/database.types';
import { generateSlug } from '../utils/validators';

export const tableService = {
  async getTables(restaurantId: string): Promise<Table[]> {
    if (!isSupabaseConfigured || !restaurantId) return [];

    const { data, error } = await supabase
      .from('tables')
      .select('*')
      .eq('restaurant_id', restaurantId)
      .order('number', { ascending: true })
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Error fetching tables:', error);
      throw error;
    }
    return data || [];
  },

  async createTable(restaurantId: string, payload: {
    name: string;
    number: string;
  }): Promise<Table> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    const cleanNum = payload.number.trim();
    const cleanName = payload.name.trim();
    const slug = `table-${generateSlug(cleanNum)}`;

    const { data, error } = await supabase
      .from('tables')
      .insert({
        restaurant_id: restaurantId,
        name: cleanName,
        number: cleanNum,
        slug: slug,
        is_active: true
      })
      .select()
      .single();

    if (error) {
      if (error.code === '23505') {
        throw new Error('رقم الطاولة هذا مسجل بالفعل في مطعمك، يرجى إدخال رقم مختلف.');
      }
      throw new Error(`فشل إنشاء الطاولة: ${error.message}`);
    }

    return data;
  },

  async updateTable(tableId: string, updates: Partial<Table>): Promise<Table> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    const { data, error } = await supabase
      .from('tables')
      .update(updates)
      .eq('id', tableId)
      .select()
      .single();

    if (error) throw new Error(`فشل تحديث الطاولة: ${error.message}`);
    return data;
  },

  async deleteTable(tableId: string): Promise<void> {
    if (!isSupabaseConfigured) throw new Error('Supabase غير مهيأ');

    const { error } = await supabase
      .from('tables')
      .delete()
      .eq('id', tableId);

    if (error) throw new Error(`فشل حذف الطاولة: ${error.message}`);
  }
};
