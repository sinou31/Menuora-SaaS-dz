/**
 * Database and Domain Types for Restaurant QR SaaS
 */

export type UserRole = 'super_admin' | 'restaurant_owner' | 'restaurant_staff' | 'customer';

export type RestaurantStatus = 'pending' | 'approved' | 'rejected' | 'suspended';

export type OrderStatus = 'pending' | 'confirmed' | 'preparing' | 'ready' | 'completed' | 'cancelled';

export type SubscriptionPlan = 'free' | 'pro' | 'business';

export interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface Restaurant {
  id: string;
  owner_id: string;
  name: string;
  slug: string;
  description: string | null;
  logo_url: string | null;
  cover_url: string | null;
  phone: string | null;
  whatsapp: string | null;
  address: string | null;
  city: string | null;
  country: string;
  currency: string;
  status: RestaurantStatus;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  restaurant_id: string;
  name: string;
  description: string | null;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface MenuItem {
  id: string;
  restaurant_id: string;
  category_id: string | null;
  name: string;
  description: string | null;
  price: number;
  image_path: string | null;
  image_url: string | null;
  is_available: boolean;
  is_featured: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface Table {
  id: string;
  restaurant_id: string;
  name: string;
  number: string;
  slug: string;
  is_active: boolean;
  created_at: string;
}

export interface Order {
  id: string;
  restaurant_id: string;
  table_id: string | null;
  customer_name: string | null;
  customer_phone: string | null;
  notes: string | null;
  status: OrderStatus;
  total: number;
  created_at: string;
  updated_at: string;
  // joined relations
  table?: Table | null;
  order_items?: OrderItem[];
}

export interface OrderItem {
  id: string;
  order_id: string;
  menu_item_id: string | null;
  item_name?: string | null;
  quantity: number;
  price: number;
  created_at: string;
  menu_item?: MenuItem | null;
}

export interface Subscription {
  id: string;
  restaurant_id: string;
  plan: SubscriptionPlan;
  status: 'active' | 'past_due' | 'cancelled';
  started_at: string;
  renews_at: string | null;
}

export interface MenuView {
  id: string;
  restaurant_id: string;
  table_id: string | null;
  created_at: string;
}

export interface DashboardStats {
  todayOrdersCount: number;
  totalOrdersCount: number;
  productsCount: number;
  categoriesCount: number;
  tablesCount: number;
  menuViewsCount: number;
  todayRevenue: number;
}

export type AIFeatureType = 'product_description' | 'menu_translation' | 'menu_assistant' | 'image_enhancement';

export interface AIUsage {
  id: string;
  restaurant_id: string;
  user_id: string | null;
  feature: AIFeatureType;
  requests_count: number;
  tokens_used: number;
  created_at: string;
}

export interface AIProductGeneratedResult {
  name: string;
  short_description: string;
  description: string;
  ingredients: string[];
  tags: string[];
}

export interface AITranslatedItem {
  id: string;
  name: string;
  description: string;
  ingredients?: string[];
}

export interface AIMenuAssistantResponse {
  answer: string;
  suggestedItems?: string[];
  rateLimited?: boolean;
}

export interface AIUsageSummary {
  totalRequests: number;
  productDescriptionsCount: number;
  translationsCount: number;
  assistantQueriesCount: number;
  tokensUsed: number;
  monthlyQuota: number;
}

