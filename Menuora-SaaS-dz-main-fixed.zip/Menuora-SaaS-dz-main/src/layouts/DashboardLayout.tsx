import React, { useState } from 'react';
import {
  LayoutDashboard,
  ShoppingBag,
  UtensilsCrossed,
  FolderTree,
  QrCode,
  Store,
  User,
  CreditCard,
  ShieldCheck,
  LogOut,
  ExternalLink,
  Menu as MenuIcon,
  X,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useRealtimeOrders } from '../hooks/useRealtimeOrders';
import { SupabaseConfigBanner } from '../components/SupabaseConfigBanner';

export type DashboardTab =
  | 'overview'
  | 'orders'
  | 'menu'
  | 'categories'
  | 'tables'
  | 'ai'
  | 'settings'
  | 'profile'
  | 'subscription'
  | 'admin';

interface DashboardLayoutProps {
  currentTab: DashboardTab;
  onSelectTab: (tab: DashboardTab) => void;
  children: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  currentTab,
  onSelectTab,
  children
}) => {
  const { user, profile, restaurant, signOut } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Hook up realtime orders listener for restaurant
  useRealtimeOrders({
    restaurantId: restaurant?.id
  });

  const isSuperAdmin = profile?.role === 'super_admin';

  const navItems: { id: DashboardTab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'نظرة عامة', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'orders', label: 'الطلبات الحية', icon: <ShoppingBag className="w-4 h-4" /> },
    { id: 'menu', label: 'قائمة الطعام', icon: <UtensilsCrossed className="w-4 h-4" /> },
    { id: 'categories', label: 'التصنيفات', icon: <FolderTree className="w-4 h-4" /> },
    { id: 'tables', label: 'الطاولات و QR', icon: <QrCode className="w-4 h-4" /> },
    { id: 'ai', label: '✨ AI Menu Manager', icon: <Sparkles className="w-4 h-4 text-[#D4AF37]" /> },
    { id: 'settings', label: 'إعدادات المطعم', icon: <Store className="w-4 h-4" /> },
    { id: 'subscription', label: 'الاشتراك', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'profile', label: 'الملف الشخصي', icon: <User className="w-4 h-4" /> }
  ];

  if (isSuperAdmin) {
    navItems.push({
      id: 'admin',
      label: 'لوحة الإدارة العامة',
      icon: <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
    });
  }

  const handleNavClick = (tab: DashboardTab) => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  const getStatusText = (status?: string) => {
    switch (status) {
      case 'approved':
        return { label: 'معتمد ونشط', color: 'text-emerald-400' };
      case 'pending':
        return { label: 'قيد المراجعة', color: 'text-amber-400' };
      case 'suspended':
        return { label: 'معلّق مؤقتاً', color: 'text-rose-400' };
      case 'rejected':
        return { label: 'مرفوض', color: 'text-rose-500' };
      default:
        return { label: 'جديد', color: 'text-[#8E95A8]' };
    }
  };

  const statusInfo = getStatusText(restaurant?.status);

  return (
    <div className="min-h-screen bg-[#0B0C10] text-[#E0E2EC] flex flex-col">
      <SupabaseConfigBanner />

      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar (260px) */}
        <aside className="hidden lg:flex w-64 bg-[#0F1117] border-e border-[#1E222E] flex-col shrink-0 select-none">
          {/* Brand header */}
          <div className="p-5 border-b border-[#1E222E]">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#D4AF37] to-[#8C6D1F] flex items-center justify-center font-black text-black text-base shadow-sm">
                M
              </div>
              <div className="min-w-0">
                <h1 className="text-sm font-bold text-white tracking-wide truncate">
                  MENUORA
                </h1>
                <p className="text-[11px] text-[#8E95A8] truncate">
                  {restaurant?.name || 'لوحة تحكم المطعم'}
                </p>
              </div>
            </div>
          </div>

          {/* Nav links */}
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {navItems.map((item) => {
              const active = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    active
                      ? 'bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30'
                      : 'text-[#9AA1B2] hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <span className={active ? 'text-[#D4AF37]' : 'text-[#6E7587]'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Footer User Info & Signout */}
          <div className="p-4 border-t border-[#1E222E] bg-[#0C0E14]">
            <div className="flex items-center justify-between mb-3 text-xs">
              <div className="min-w-0">
                <p className="font-semibold text-white truncate">
                  {profile?.full_name || user?.email?.split('@')[0]}
                </p>
                <p className="text-[10px] text-[#787F92] truncate">{user?.email}</p>
              </div>
            </div>
            <button
              onClick={() => signOut()}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-rose-300 bg-rose-950/20 border border-rose-900/30 hover:bg-rose-900/40 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        </aside>

        {/* Main Content Viewport */}
        <div className="flex-1 flex flex-col min-w-0 overflow-y-auto pb-16 lg:pb-0">
          {/* Top Header */}
          <header className="h-16 px-4 md:px-6 bg-[#0E1016] border-b border-[#1E222E] flex items-center justify-between shrink-0 sticky top-0 z-20">
            {/* Left/Start side: mobile toggle & title */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg bg-[#181B24] border border-[#272B3A] text-[#9AA1B2] hover:text-white"
                aria-label="القائمة"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
              </button>

              <div className="flex items-center gap-2 text-xs">
                <span className="font-bold text-white text-sm md:text-base">
                  {restaurant?.name || 'المطعم'}
                </span>
                <span className="text-[#4E5467]" aria-hidden="true">·</span>
                <span className={`text-[11px] font-medium ${statusInfo.color}`}>
                  {statusInfo.label}
                </span>
              </div>
            </div>

            {/* Right/End side: Public Menu Link & Actions */}
            <div className="flex items-center gap-2">
              {restaurant?.slug && (
                <a
                  href={`#menu/${restaurant.slug}`}
                  onClick={(e) => {
                    e.preventDefault();
                    window.location.hash = `#/menu/${restaurant.slug}`;
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/30 hover:bg-[#D4AF37]/20 transition-colors"
                >
                  <span className="hidden sm:inline">معاينة القائمة الرقمية</span>
                  <span className="sm:hidden">القائمة</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          </header>

          {/* Page Body */}
          <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            {children}
          </main>
        </div>
      </div>

      {/* Mobile Drawer Navigation (when toggled) */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="fixed inset-y-0 start-0 w-64 bg-[#0F1117] border-e border-[#1E222E] flex flex-col p-4 z-50">
            <div className="flex items-center justify-between pb-4 border-b border-[#1E222E] mb-4">
              <span className="font-black text-sm text-white tracking-wide">MENUORA</span>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-1 rounded-lg text-[#8E95A8]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 space-y-1 overflow-y-auto">
              {navItems.map((item) => {
                const active = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold ${
                      active
                        ? 'bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30'
                        : 'text-[#9AA1B2]'
                    }`}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="pt-4 border-t border-[#1E222E]">
              <button
                onClick={() => signOut()}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-rose-300 bg-rose-950/20 border border-rose-900/30"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>تسجيل الخروج</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Bottom Tab Bar (Fixed at bottom for 1-hand reach) */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 bg-[#0E1016] border-t border-[#1E222E] flex items-center justify-around px-2 py-2 z-30">
        <button
          onClick={() => onSelectTab('overview')}
          className={`flex flex-col items-center gap-1 py-1 px-2 text-[10px] font-medium ${
            currentTab === 'overview' ? 'text-[#D4AF37]' : 'text-[#7B8296]'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>الرئيسية</span>
        </button>
        <button
          onClick={() => onSelectTab('orders')}
          className={`flex flex-col items-center gap-1 py-1 px-2 text-[10px] font-medium ${
            currentTab === 'orders' ? 'text-[#D4AF37]' : 'text-[#7B8296]'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>الطلبات</span>
        </button>
        <button
          onClick={() => onSelectTab('menu')}
          className={`flex flex-col items-center gap-1 py-1 px-2 text-[10px] font-medium ${
            currentTab === 'menu' ? 'text-[#D4AF37]' : 'text-[#7B8296]'
          }`}
        >
          <UtensilsCrossed className="w-4 h-4" />
          <span>القائمة</span>
        </button>
        <button
          onClick={() => onSelectTab('tables')}
          className={`flex flex-col items-center gap-1 py-1 px-2 text-[10px] font-medium ${
            currentTab === 'tables' ? 'text-[#D4AF37]' : 'text-[#7B8296]'
          }`}
        >
          <QrCode className="w-4 h-4" />
          <span>الطاولات</span>
        </button>
        <button
          onClick={() => onSelectTab('settings')}
          className={`flex flex-col items-center gap-1 py-1 px-2 text-[10px] font-medium ${
            currentTab === 'settings' ? 'text-[#D4AF37]' : 'text-[#7B8296]'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>المطعم</span>
        </button>
      </nav>
    </div>
  );
};
