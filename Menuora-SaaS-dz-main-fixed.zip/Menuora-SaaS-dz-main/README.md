# RESTAURANT QR SAAS

منصة SaaS سحابية متكاملة للمطاعم والمقاهي لإنشاء وإدارة القوائم الرقمية التفاعلية المرتبطة بـ رموز الاستجابة السريعة (QR Codes)، مع لوحة تحكم لإدارة المنتجات، التصنيفات، الطاولات، واستقبال الطلبات الحية في المطبخ.

---

## 🌟 مميزات المنصة (Features)

1. **قائمة طعام رقمية ذكية (Interactive Digital Menu):**
   - تعمل مباشرة في متصفح أي هاتف عبر مسح رمز QR بدون تحميل تطبيقات.
   - تصفية فورية حسب الأقسام والتصنيفات، وبحث سريع عن الأطباق.
   - دعم المنتجات المميزة، وحالة التوفر اللحظية (Available / Unavailable).
   - سلة طلبات متكاملة وحساب إجمالي الفاتورة بدقة.

2. **رموز QR مخصصة لكل طاولة (Table QR Codes):**
   - توليد رموز استجابة سريعة تلقائية وفريدة لكل طاولة في المطعم.
   - تحميل الرمز بصيغة صورة عالية الدقة PNG.
   - طباعة بطاقة طاولة مهيأة مباشرة (`@media print`) لوضعها على الطاولات.
   - نسخ الروابط المباشرة للقائمة مع معرف الطاولة.

3. **لوحة تحكم حية للمطعم (Restaurant Dashboard):**
   - إحصائيات حقيقية من قاعدة بيانات Supabase (طلبات اليوم، المبيعات، عدد الأطباق، الطاولات، زيارات القائمة).
   - إدارة كاملة للمنتجات (إضافة كاملة، إضافة سريعة، تعديل، نسخ مكرر، وحذف).
   - رفع صور المنتجات مع ضغط الصور التلقائي Client-Side على المتصفح إلى WebP بحجم خفيف وجودة عالية.
   - تنظيم التصنيفات والأقسام وإعادة ترتيبها.
   - استقبال الطلبات الحية مع تحديثات فورية عبر تقنية `Supabase Realtime`.
   - تغيير حالات الطلبات (قيد الانتظار -> جاري التحضير -> جاهز للتقديم -> مكتمل / ملغي).

4. **الأمان وصلاحيات الوصول (Security & RLS):**
   - حماية كاملة عبر Supabase Row Level Security (RLS).
   - التحقق من الأسعار في قاعدة البيانات عند إنشاء الطلب لمنع أي تلاعب بأسعار الأطباق من جانب العميل.
   - عزل كامل لبيانات كل صاحب مطعم عن المطاعم الأخرى.
   - صلاحيات خاصة بالمشرف العام `super_admin` للموافقة على المطاعم أو تعليقها.

5. **نظام التسجيل والمصادقة (Supabase Auth):**
   - تسجيل مطعم متعدد الخطوات (بيانات الحساب -> بيانات المطعم -> المراجعة).
   - مؤشر فحص قوة كلمة المرور (Weak, Medium, Strong).
   - تأكيد البريد الإلكتروني عبر صفحة `/verify-email` مع عداد إعادة الإرسال.
   - استعادة كلمة المرور بدون تسريب البريد (Protection against User Enumeration).

6. **طبقة الذكاء الاصطناعي السحابية (AI Menu Intelligence Layer):**
   - **توليد أوصاف الأطباق (AI Product Description):** صياغة أسماء وأوصاف شهية للمنتجات ومكونات ووسوم مع إمكانية التعديل والمراجعة قبل الحفظ.
   - **ترجمة القائمة الذكية (AI Menu Translation):** ترجمة الأطباق والمكونات بين العربية والإنجليزية والفرنسية دون المساس بالأسعار أو المعرفات الحساسة.
   - **مساعد القائمة الذكي للزبائن (AI Menu Assistant):** روبوت محادثة مدمج في القائمة العامة يجيب حصراً اعتماداً على الأطباق المتوفرة فعلياً في المطعم مع حماية من حقن الأوامر (Prompt Injection Defense).
   - **سجل الاستهلاك الفعلي (AI Usage Analytics):** تتبع عدد الطلبات واستخدام التوكنز من جدول `ai_usage` بدقة دون أرقام وهمية.
   - **معمارية سحابية آمنة ومزودات قابلة للتبديل:** عبر Supabase Edge Functions دون كشف أي مفتاح AI في الواجهة الأمامية.

---

## 🛠 التقنيات المستخدمة (Tech Stack)

- **Frontend:** React 19 + TypeScript + Vite
- **Styling:** Tailwind CSS (Luxury Gold Aesthetic `#0B0C10` & `#D4AF37`) + Cairo Font
- **Icons:** Lucide React
- **QR Engine:** `qrcode`
- **Database & Auth:** Supabase (PostgreSQL, Supabase Auth, Supabase Storage, Supabase Realtime)
- **AI Backend:** Supabase Edge Functions (Deno Runtime) + Swappable AI Providers (Gemini / OpenAI)
- **Deployment:** Cloudflare Pages / Static Hosting Ready

---

## 📁 هيكلية المشروع (Project Architecture)

```
├── .env.example              # نموذج متغيرات البيئة بدون أسرار
├── index.html                # نقطة البداية مع خط Cairo ووسوم SEO
├── metadata.json             # تعريف التطبيق وبياناته
├── supabase/
│   ├── schema.sql            # المخطط الكامل لقاعدة البيانات وسياسات RLS و ai_usage
│   └── functions/            # دوال Edge Functions السحابية للذكاء الاصطناعي
│       ├── _shared/          # مزود الذكاء الاصطناعي القابل للتبديل وحماية الأمان
│       │   ├── ai-provider.ts
│       │   ├── security.ts
│       │   └── cors.ts
│       ├── ai-menu-manager/  # إدارة وتوليد أوصاف الأطباق وترجمتها للمطعم
│       └── ai-menu-assistant/# مساعد الزبائن الذكي المبني على أطباق القائمة الحقيقية
├── src/
│   ├── components/           # عناصر الواجهة (Button, Modal, Input, AIMenuAssistantWidget, ...)
│   ├── context/              # AuthContext و ToastContext
│   ├── hooks/                # useAuth, useToast, useRealtimeOrders
│   ├── layouts/              # DashboardLayout (Sidebar & Mobile Nav)
│   ├── lib/                  # عميل Supabase، ضاغط الصور، مولد QR
│   ├── pages/                # صفحات التطبيق (Landing, Auth, Dashboard, AIMenuManager, Public Menu, Admin)
│   ├── services/             # خدمات Supabase، التخزين، و aiService
│   ├── types/                # واجهات TypeScript وأنواع البيانات
│   ├── utils/                # التحقق من المدخلات، التنسيق، ومساعد الترجمة i18n
│   ├── App.tsx               # الموجه الرئيسي للتطبيق وإدارة المسارات
│   ├── index.css             # تخصيصات Tailwind وأنماط الطباعة
│   └── main.tsx              # نقطة مدخل تطبيق React
└── README.md
```

---

## 🚀 التثبيت والتشغيل المحلي (Local Development)

### 1. تثبيت الحزم:
```bash
npm install
```

### 2. إعداد متغيرات البيئة:
قم بنسخ ملف `.env.example` إلى `.env`:
```bash
cp .env.example .env
```
أضف رابط مشروع Supabase والمفتاح العام `Anon Key`:
```env
VITE_SUPABASE_URL="https://YOUR_PROJECT_ID.supabase.co"
VITE_SUPABASE_ANON_KEY="YOUR_SUPABASE_ANON_KEY"
```

> **ملاحظة أمنية هامة:** لا تضع أبداً `Service Role Key` أو أي `AI API Key` داخل واجهة الـ Frontend أو داخل ملف `.env`. الواجهة تستخدم فقط `VITE_SUPABASE_ANON_KEY` بالاعتماد على سياسات الأمان RLS في قاعدة البيانات وEdge Functions.

### 3. تطبيق مخطط قاعدة البيانات (Supabase Migration):
1. افتح مشروعك على [Supabase Dashboard](https://supabase.com).
2. انتقل إلى **SQL Editor**.
3. افتح الملف `supabase/schema.sql` في هذا المشروع، وانسخ كافة محتوياته والصقها داخل الـ SQL Editor ثم اضغط **Run**.
4. سيتم إنشاء:
   - جداول `profiles`, `restaurants`, `categories`, `menu_items`, `tables`, `orders`, `order_items`, `subscriptions`, `menu_views`, `ai_usage`.
   - المشغل التلقائي `handle_new_user` الذي ينشئ الملف الشخصي **والمطعم والاشتراك المجاني** عند التسجيل.
   - الدالة `create_customer_order` التي تُنشئ طلبات الزبائن وتحسب الأسعار والمجموع داخل قاعدة البيانات.
   - تفعيل Realtime لجدول `orders` (للطلبات الحية في لوحة التحكم).
   - سياسات الأمان (RLS) لكل جدول بما فيها سجل استخدام الذكاء الاصطناعي.
   - مجلدات التخزين `menu-images`, `restaurant-assets`, `qr-codes` وسياسات الرفع.

#### إنشاء أول مشرف عام (Super Admin):
بعد تسجيل حسابك من التطبيق، نفّذ في SQL Editor:
```sql
UPDATE public.profiles SET role = 'super_admin' WHERE email = 'your-email@example.com';
```

#### إعداد المصادقة (Authentication → URL Configuration):
- **Site URL:** رابط موقعك (مثال: `https://your-site.pages.dev`).
- **Redirect URLs:** أضف `https://your-site.pages.dev/reset-password` (وللتطوير `http://localhost:3000/reset-password`)، وإلا لن يعمل رابط استعادة كلمة المرور.

### 4. إعداد أسرار ودوال الذكاء الاصطناعي (Supabase Edge Functions):
قم بإعداد مفاتيح مزود الذكاء الاصطناعي السحابية في إعدادات Supabase Secrets (تدعم Gemini أو OpenAI):
```bash
supabase secrets set AI_PROVIDER="gemini"
supabase secrets set GEMINI_API_KEY="your-gemini-api-key"
```
أو إذا كنت تفضل استخدام OpenAI:
```bash
supabase secrets set AI_PROVIDER="openai"
supabase secrets set OPENAI_API_KEY="your-openai-api-key"
```

ثم نشر دوال Edge Functions:
```bash
supabase functions deploy ai-menu-manager
supabase functions deploy ai-menu-assistant
```

### 5. تشغيل خادم التطوير:
```bash
npm run dev
```
افتح المتصفح على: `http://localhost:3000`

---

## ☁️ النشر على Cloudflare Pages

التطبيق مهيأ بالكامل للنشر السحابي الثابت (SPA) على Cloudflare Pages:

1. **Build command:**
   ```bash
   npm run build
   ```
2. **Build output directory:**
   ```
   dist
   ```
3. **Environment variables في لوحة Cloudflare:**
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

---

## 🔒 المراجعة والتدقيق الأمني (Security Audit)

- ✅ لا توجد أي أسرار، كلمات مرور، مفاتيح AI، أو مفاتيح Service Role في مجلد الكود المصدري للواجهة.
- ✅ جميع الجداول محمية بسياسات Row Level Security (RLS).
- ✅ أسعار أطباق الطلبات والمجموع يُحسبان داخل قاعدة البيانات (الدالة `create_customer_order`)، ولا يملك الزبون أي صلاحية إدخال مباشرة في جدولي الطلبات، مما يمنع التلاعب بالأسعار.
- ✅ لا يستطيع صاحب المطعم اعتماد مطعمه بنفسه أو تغيير مالكه؛ الاعتماد للمشرف العام فقط.
- ✅ مساعد القائمة الذكي محمي بـ Data Grounding صارم وفلترة للـ Prompt Injections، مع تحديد معدل الاستخدام (Rate Limiting).
- ✅ صور المنتجات يتم فحص نوعها (JPG, PNG, WEBP فقط) وضغطها لتفادي هجمات رفع الملفات الكبيرة.
- ✅ لوحة الإدارة العامة `/admin` وإدارة الـ AI محمية بالتحقق من الملكية والأدوار Server-side.

