-- ==============================================================================
-- RESTAURANT QR SAAS - Complete Production Database Migration
-- PostgreSQL & Supabase Database Schema, Row Level Security (RLS) & Storage
-- ==============================================================================

-- Enable UUID extension if not enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ------------------------------------------------------------------------------
-- 1. PROFILES TABLE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  role TEXT NOT NULL CHECK (role IN ('super_admin', 'restaurant_owner', 'restaurant_staff', 'customer')) DEFAULT 'restaurant_owner',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------------------------
-- 2. RESTAURANTS TABLE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.restaurants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  logo_url TEXT,
  cover_url TEXT,
  phone TEXT,
  whatsapp TEXT,
  address TEXT,
  city TEXT,
  country TEXT DEFAULT 'DZ',
  currency TEXT NOT NULL DEFAULT 'DZD',
  status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected', 'suspended')) DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_restaurants_owner_id ON public.restaurants(owner_id);
CREATE INDEX IF NOT EXISTS idx_restaurants_slug ON public.restaurants(slug);
CREATE INDEX IF NOT EXISTS idx_restaurants_status ON public.restaurants(status);

-- ------------------------------------------------------------------------------
-- 3. CATEGORIES TABLE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  sort_order INT NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_categories_restaurant_id ON public.categories(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_categories_sort_order ON public.categories(sort_order);

-- ------------------------------------------------------------------------------
-- 4. MENU ITEMS TABLE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.menu_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
  image_path TEXT,
  image_url TEXT,
  is_available BOOLEAN NOT NULL DEFAULT true,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_menu_items_restaurant_id ON public.menu_items(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_menu_items_category_id ON public.menu_items(category_id);
CREATE INDEX IF NOT EXISTS idx_menu_items_available ON public.menu_items(is_available);

-- ------------------------------------------------------------------------------
-- 5. TABLES TABLE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.tables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  number TEXT NOT NULL,
  slug TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(restaurant_id, slug),
  UNIQUE(restaurant_id, number)
);

CREATE INDEX IF NOT EXISTS idx_tables_restaurant_id ON public.tables(restaurant_id);

-- ------------------------------------------------------------------------------
-- 6. ORDERS TABLE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  table_id UUID REFERENCES public.tables(id) ON DELETE SET NULL,
  customer_name TEXT,
  customer_phone TEXT,
  notes TEXT,
  status TEXT NOT NULL CHECK (status IN ('pending', 'confirmed', 'preparing', 'ready', 'completed', 'cancelled')) DEFAULT 'pending',
  total NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (total >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_restaurant_id ON public.orders(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON public.orders(created_at);

-- ------------------------------------------------------------------------------
-- 7. ORDER ITEMS TABLE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  menu_item_id UUID REFERENCES public.menu_items(id) ON DELETE SET NULL,
  item_name TEXT,
  quantity INT NOT NULL CHECK (quantity > 0),
  price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON public.order_items(order_id);

-- ------------------------------------------------------------------------------
-- 8. SUBSCRIPTIONS TABLE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  plan TEXT NOT NULL CHECK (plan IN ('free', 'pro', 'business')) DEFAULT 'free',
  status TEXT NOT NULL CHECK (status IN ('active', 'past_due', 'cancelled')) DEFAULT 'active',
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  renews_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_restaurant_id ON public.subscriptions(restaurant_id);

-- ------------------------------------------------------------------------------
-- 9. MENU VIEWS TABLE (Analytics)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.menu_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  table_id UUID REFERENCES public.tables(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_menu_views_restaurant_id ON public.menu_views(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_menu_views_created_at ON public.menu_views(created_at);

-- ------------------------------------------------------------------------------
-- 10. AUTH TRIGGER: Auto-create Profile + Restaurant on SignUp & Prevent Role Escalation
-- ------------------------------------------------------------------------------

-- Helper function: Is Super Admin (defined first because other functions/policies use it)
CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'super_admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

-- Runs ONCE when a user signs up (AFTER INSERT only; never on UPDATE, otherwise
-- every login/token update of auth.users would overwrite the user's profile edits).
-- It creates the profile AND the restaurant (+ free subscription) from the sign-up
-- metadata, so registration works even when e-mail confirmation is enabled
-- (no session exists yet at that moment, so the client cannot insert it itself).
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
DECLARE
  v_name      TEXT;
  v_base_slug TEXT;
  v_slug      TEXT;
  v_suffix    INT := 0;
  v_rest_id   UUID;
BEGIN
  -- Strict Production Rule: Always default to 'restaurant_owner'.
  -- Never trust raw_user_meta_data for privileged roles (prevents client-side super_admin injection)
  INSERT INTO public.profiles (id, full_name, email, phone, role)
  VALUES (
    new.id,
    COALESCE(new.raw_user_meta_data->>'full_name', ''),
    new.email,
    COALESCE(new.raw_user_meta_data->>'phone', ''),
    'restaurant_owner'
  )
  ON CONFLICT (id) DO NOTHING;

  v_name := NULLIF(btrim(COALESCE(new.raw_user_meta_data->>'restaurant_name', '')), '');

  IF v_name IS NOT NULL
     AND NOT EXISTS (SELECT 1 FROM public.restaurants WHERE owner_id = new.id) THEN

    v_base_slug := NULLIF(btrim(COALESCE(new.raw_user_meta_data->>'restaurant_slug', '')), '');
    IF v_base_slug IS NULL THEN
      v_base_slug := 'restaurant-' || substr(replace(new.id::text, '-', ''), 1, 8);
    END IF;
    v_slug := v_base_slug;

    -- Guarantee slug uniqueness (append -2, -3, ... when taken)
    WHILE EXISTS (SELECT 1 FROM public.restaurants WHERE slug = v_slug) LOOP
      v_suffix := v_suffix + 1;
      v_slug := v_base_slug || '-' || (v_suffix + 1);
    END LOOP;

    INSERT INTO public.restaurants (owner_id, name, slug, city, address, description, phone, status)
    VALUES (
      new.id,
      v_name,
      v_slug,
      NULLIF(btrim(COALESCE(new.raw_user_meta_data->>'city', '')), ''),
      NULLIF(btrim(COALESCE(new.raw_user_meta_data->>'address', '')), ''),
      NULLIF(btrim(COALESCE(new.raw_user_meta_data->>'description', '')), ''),
      NULLIF(btrim(COALESCE(new.raw_user_meta_data->>'phone', '')), ''),
      'pending'
    )
    RETURNING id INTO v_rest_id;

    INSERT INTO public.subscriptions (restaurant_id, plan, status)
    VALUES (v_rest_id, 'free', 'active');
  END IF;

  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- Trigger to prevent users from escalating their own role via UPDATE
CREATE OR REPLACE FUNCTION public.prevent_role_escalation()
RETURNS trigger AS $$
BEGIN
  -- auth.uid() is NULL for trusted server-side contexts (Supabase SQL editor, service role),
  -- which is how the very first super admin is promoted; end users always carry a JWT.
  IF NEW.role <> OLD.role AND auth.uid() IS NOT NULL AND NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Security violation: Cannot modify user role without super admin authorization';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_prevent_role_escalation ON public.profiles;
CREATE TRIGGER trg_prevent_role_escalation
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE PROCEDURE public.prevent_role_escalation();

-- Trigger to stop restaurant owners from approving themselves or transferring ownership.
-- Only a super admin (or a trusted server-side context with no end-user JWT, e.g. the
-- SQL editor / service role / the sign-up trigger) may set status or change owner_id.
CREATE OR REPLACE FUNCTION public.guard_restaurant_changes()
RETURNS trigger AS $$
BEGIN
  IF auth.uid() IS NULL OR public.is_super_admin() THEN
    RETURN NEW;
  END IF;

  IF TG_OP = 'INSERT' THEN
    NEW.status := 'pending';
  ELSE
    IF NEW.status IS DISTINCT FROM OLD.status THEN
      RAISE EXCEPTION 'Security violation: only a super admin can change the restaurant status';
    END IF;
    IF NEW.owner_id IS DISTINCT FROM OLD.owner_id THEN
      RAISE EXCEPTION 'Security violation: restaurant ownership cannot be changed';
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_guard_restaurant_changes ON public.restaurants;
CREATE TRIGGER trg_guard_restaurant_changes
  BEFORE INSERT OR UPDATE ON public.restaurants
  FOR EACH ROW EXECUTE PROCEDURE public.guard_restaurant_changes();

-- ------------------------------------------------------------------------------
-- 11. ROW LEVEL SECURITY (RLS) POLICIES
-- ------------------------------------------------------------------------------

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.restaurants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tables ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_views ENABLE ROW LEVEL SECURITY;

-- PROFILES POLICIES
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id OR public.is_super_admin());

DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id OR public.is_super_admin())
  WITH CHECK (auth.uid() = id OR public.is_super_admin());

-- RESTAURANTS POLICIES
DROP POLICY IF EXISTS "Public can view approved restaurants" ON public.restaurants;
CREATE POLICY "Public can view approved restaurants"
  ON public.restaurants FOR SELECT
  USING (status = 'approved' OR owner_id = auth.uid() OR public.is_super_admin());

DROP POLICY IF EXISTS "Owners can insert their restaurant" ON public.restaurants;
CREATE POLICY "Owners can insert their restaurant"
  ON public.restaurants FOR INSERT
  WITH CHECK (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Owners can update their restaurant" ON public.restaurants;
CREATE POLICY "Owners can update their restaurant"
  ON public.restaurants FOR UPDATE
  USING (auth.uid() = owner_id OR public.is_super_admin())
  WITH CHECK (auth.uid() = owner_id OR public.is_super_admin());

DROP POLICY IF EXISTS "Owners can delete their restaurant" ON public.restaurants;
CREATE POLICY "Owners can delete their restaurant"
  ON public.restaurants FOR DELETE
  USING (auth.uid() = owner_id OR public.is_super_admin());

-- CATEGORIES POLICIES
DROP POLICY IF EXISTS "Public can view active categories of approved restaurants" ON public.categories;
CREATE POLICY "Public can view active categories of approved restaurants"
  ON public.categories FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = categories.restaurant_id
        AND (
          (r.status = 'approved' AND categories.is_active)
          OR r.owner_id = auth.uid()
          OR public.is_super_admin()
        )
    )
  );

DROP POLICY IF EXISTS "Owners can manage categories of their restaurant" ON public.categories;
CREATE POLICY "Owners can manage categories of their restaurant"
  ON public.categories FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = categories.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = categories.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

-- MENU ITEMS POLICIES
DROP POLICY IF EXISTS "Public can view available menu items of approved restaurants" ON public.menu_items;
CREATE POLICY "Public can view available menu items of approved restaurants"
  ON public.menu_items FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = menu_items.restaurant_id
        AND (r.status = 'approved' OR r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

DROP POLICY IF EXISTS "Owners can manage menu items of their restaurant" ON public.menu_items;
CREATE POLICY "Owners can manage menu items of their restaurant"
  ON public.menu_items FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = menu_items.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = menu_items.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

-- TABLES POLICIES
DROP POLICY IF EXISTS "Public can view tables of approved restaurants" ON public.tables;
CREATE POLICY "Public can view tables of approved restaurants"
  ON public.tables FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = tables.restaurant_id
        AND (r.status = 'approved' OR r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

DROP POLICY IF EXISTS "Owners can manage tables of their restaurant" ON public.tables;
CREATE POLICY "Owners can manage tables of their restaurant"
  ON public.tables FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = tables.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = tables.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

-- ORDERS POLICIES
-- Customers (anonymous) can NOT insert into orders / order_items directly:
-- they must call public.create_customer_order(...) (section 11b) which recomputes
-- every price and the total server-side. This also fixes the RLS error that
-- `insert(...).select()` raised for anonymous users (they cannot SELECT orders).
DROP POLICY IF EXISTS "Public can create orders for approved restaurants" ON public.orders;

DROP POLICY IF EXISTS "Owners and staff can view orders of their restaurant" ON public.orders;
CREATE POLICY "Owners and staff can view orders of their restaurant"
  ON public.orders FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = orders.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

DROP POLICY IF EXISTS "Owners and staff can update orders of their restaurant" ON public.orders;
CREATE POLICY "Owners and staff can update orders of their restaurant"
  ON public.orders FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = orders.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = orders.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

-- ORDER ITEMS POLICIES
DROP POLICY IF EXISTS "Public can insert order items" ON public.order_items;

DROP POLICY IF EXISTS "Owners and staff can view order items" ON public.order_items;
CREATE POLICY "Owners and staff can view order items"
  ON public.order_items FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.orders o
      JOIN public.restaurants r ON r.id = o.restaurant_id
      WHERE o.id = order_items.order_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

-- SUBSCRIPTIONS POLICIES
DROP POLICY IF EXISTS "Owners can view own subscription" ON public.subscriptions;
CREATE POLICY "Owners can view own subscription"
  ON public.subscriptions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = subscriptions.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

-- MENU VIEWS POLICIES
DROP POLICY IF EXISTS "Anyone can record a menu view" ON public.menu_views;
CREATE POLICY "Anyone can record a menu view"
  ON public.menu_views FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = menu_views.restaurant_id AND r.status = 'approved'
    )
  );

DROP POLICY IF EXISTS "Owners can view analytics of their restaurant" ON public.menu_views;
CREATE POLICY "Owners can view analytics of their restaurant"
  ON public.menu_views FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = menu_views.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

-- ------------------------------------------------------------------------------
-- 11b. SECURE CUSTOMER ORDER CREATION (RPC)
-- Validates restaurant / table / items and computes prices + total on the server.
-- Callable by anonymous customers; never trusts any price sent by the client.
-- ------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.create_customer_order(
  p_restaurant_id  UUID,
  p_table_id       UUID,
  p_customer_name  TEXT,
  p_customer_phone TEXT,
  p_notes          TEXT,
  p_items          JSONB
)
RETURNS public.orders
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_order  public.orders;
  v_item   JSONB;
  v_menu   public.menu_items;
  v_qty    INT;
  v_total  NUMERIC(10, 2) := 0;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.restaurants WHERE id = p_restaurant_id AND status = 'approved'
  ) THEN
    RAISE EXCEPTION 'هذا المطعم غير متاح لاستقبال الطلبات حالياً';
  END IF;

  IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array'
     OR jsonb_array_length(p_items) = 0 THEN
    RAISE EXCEPTION 'سلة الطلبات فارغة';
  END IF;

  IF jsonb_array_length(p_items) > 50 THEN
    RAISE EXCEPTION 'عدد الأصناف في الطلب كبير جداً';
  END IF;

  IF p_table_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.tables
    WHERE id = p_table_id AND restaurant_id = p_restaurant_id AND is_active
  ) THEN
    RAISE EXCEPTION 'الطاولة غير صالحة أو غير نشطة';
  END IF;

  INSERT INTO public.orders (restaurant_id, table_id, customer_name, customer_phone, notes, status, total)
  VALUES (
    p_restaurant_id,
    p_table_id,
    COALESCE(NULLIF(left(btrim(COALESCE(p_customer_name, '')), 100), ''), 'عميل الطاولة'),
    NULLIF(left(btrim(COALESCE(p_customer_phone, '')), 30), ''),
    NULLIF(left(btrim(COALESCE(p_notes, '')), 500), ''),
    'pending',
    0
  )
  RETURNING * INTO v_order;

  FOR v_item IN SELECT * FROM jsonb_array_elements(p_items)
  LOOP
    v_qty := LEAST(GREATEST(COALESCE((v_item->>'quantity')::INT, 1), 1), 99);

    SELECT * INTO v_menu
    FROM public.menu_items
    WHERE id = (v_item->>'menu_item_id')::UUID
      AND restaurant_id = p_restaurant_id;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'أحد المنتجات المطلوبة غير موجود في هذا المطعم';
    END IF;

    IF NOT v_menu.is_available THEN
      RAISE EXCEPTION 'المنتج "%" غير متوفر حالياً', v_menu.name;
    END IF;

    INSERT INTO public.order_items (order_id, menu_item_id, item_name, quantity, price)
    VALUES (v_order.id, v_menu.id, v_menu.name, v_qty, v_menu.price);

    v_total := v_total + (v_menu.price * v_qty);
  END LOOP;

  UPDATE public.orders SET total = v_total WHERE id = v_order.id
  RETURNING * INTO v_order;

  RETURN v_order;
END;
$$;

REVOKE ALL ON FUNCTION public.create_customer_order(UUID, UUID, TEXT, TEXT, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_customer_order(UUID, UUID, TEXT, TEXT, TEXT, JSONB) TO anon, authenticated;

-- ------------------------------------------------------------------------------
-- 11c. REALTIME: broadcast order changes to the dashboard
-- (Required for useRealtimeOrders; without it no live events are ever delivered.)
-- ------------------------------------------------------------------------------
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime')
     AND NOT EXISTS (
       SELECT 1 FROM pg_publication_tables
       WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'orders'
     ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
  END IF;
END $$;

-- ------------------------------------------------------------------------------
-- 12. STORAGE BUCKETS & POLICIES SETUP
-- ------------------------------------------------------------------------------
-- Create storage buckets if not already present in Supabase
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('menu-images', 'menu-images', true),
  ('restaurant-assets', 'restaurant-assets', true),
  ('qr-codes', 'qr-codes', true)
ON CONFLICT (id) DO NOTHING;

-- Storage Policy: Public Read on all 3 buckets
DROP POLICY IF EXISTS "Public can read menu images" ON storage.objects;
CREATE POLICY "Public can read menu images"
  ON storage.objects FOR SELECT
  USING (bucket_id IN ('menu-images', 'restaurant-assets', 'qr-codes'));

-- Storage Policy: Tenant-Isolated Upload
-- Users can only upload inside folders matching restaurant IDs that they own
DROP POLICY IF EXISTS "Authenticated users can upload images" ON storage.objects;
DROP POLICY IF EXISTS "Restaurant owners can upload assets for their restaurant" ON storage.objects;
CREATE POLICY "Restaurant owners can upload assets for their restaurant"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id IN ('menu-images', 'restaurant-assets', 'qr-codes')
    AND (
      public.is_super_admin()
      OR EXISTS (
        SELECT 1 FROM public.restaurants r
        WHERE r.id::text = (storage.foldername(name))[1]
          AND r.owner_id = auth.uid()
      )
    )
  );

-- Storage Policy: Tenant-Isolated Update
DROP POLICY IF EXISTS "Authenticated users can update their uploaded images" ON storage.objects;
DROP POLICY IF EXISTS "Restaurant owners can update assets for their restaurant" ON storage.objects;
CREATE POLICY "Restaurant owners can update assets for their restaurant"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id IN ('menu-images', 'restaurant-assets', 'qr-codes')
    AND (
      public.is_super_admin()
      OR EXISTS (
        SELECT 1 FROM public.restaurants r
        WHERE r.id::text = (storage.foldername(name))[1]
          AND r.owner_id = auth.uid()
      )
    )
  );

-- Storage Policy: Tenant-Isolated Delete
DROP POLICY IF EXISTS "Authenticated users can delete their uploaded images" ON storage.objects;
DROP POLICY IF EXISTS "Restaurant owners can delete assets for their restaurant" ON storage.objects;
CREATE POLICY "Restaurant owners can delete assets for their restaurant"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id IN ('menu-images', 'restaurant-assets', 'qr-codes')
    AND (
      public.is_super_admin()
      OR EXISTS (
        SELECT 1 FROM public.restaurants r
        WHERE r.id::text = (storage.foldername(name))[1]
          AND r.owner_id = auth.uid()
      )
    )
  );

-- ------------------------------------------------------------------------------
-- 13. AI USAGE TABLE & RLS POLICIES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.ai_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id UUID NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  feature TEXT NOT NULL CHECK (feature IN ('product_description', 'menu_translation', 'menu_assistant', 'image_enhancement')),
  requests_count INT NOT NULL DEFAULT 1,
  tokens_used INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ai_usage_restaurant_id ON public.ai_usage(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_ai_usage_created_at ON public.ai_usage(created_at);

ALTER TABLE public.ai_usage ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Owners can view AI usage of their restaurant" ON public.ai_usage;
CREATE POLICY "Owners can view AI usage of their restaurant"
  ON public.ai_usage FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = ai_usage.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    )
  );

DROP POLICY IF EXISTS "Authenticated users or service roles can insert AI usage" ON public.ai_usage;
CREATE POLICY "Authenticated users or service roles can insert AI usage"
  ON public.ai_usage FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.restaurants r
      WHERE r.id = ai_usage.restaurant_id AND (r.owner_id = auth.uid() OR public.is_super_admin())
    ) OR auth.role() = 'service_role'
  );

