/**
 * Server-Side Security, Prompt Injection Filtering, and Rate Limiting
 */

// Simple in-memory session rate limiter for public assistant
// Key: sessionKey / IP, Value: { count, resetAt }
const sessionLimitMap = new Map<string, { count: number; resetAt: number }>();
const MAX_PUBLIC_QUESTIONS_PER_WINDOW = 10;
const WINDOW_DURATION_MS = 15 * 60 * 1000; // 15 minutes

export function checkPublicRateLimit(identifier: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const record = sessionLimitMap.get(identifier);

  if (!record || now > record.resetAt) {
    sessionLimitMap.set(identifier, { count: 1, resetAt: now + WINDOW_DURATION_MS });
    return { allowed: true, remaining: MAX_PUBLIC_QUESTIONS_PER_WINDOW - 1 };
  }

  if (record.count >= MAX_PUBLIC_QUESTIONS_PER_WINDOW) {
    return { allowed: false, remaining: 0 };
  }

  record.count += 1;
  return { allowed: true, remaining: MAX_PUBLIC_QUESTIONS_PER_WINDOW - record.count };
}

// Common prompt injection attack signatures
const INJECTION_PATTERNS = [
  /ignore\s+(all\s+)?(previous|prior)\s+instructions/i,
  /system\s+prompt/i,
  /reveal\s+(the\s+)?(api\s+key|token|credentials|password)/i,
  /database\s+(schema|password|credentials|tables)/i,
  /select\s+\*\s+from/i,
  /drop\s+table/i,
  /show\s+me\s+the\s+prompt/i,
  /act\s+as\s+a\s+(dan|hacker|root|admin)/i,
  /override\s+(all\s+)?rules/i
];

export function detectPromptInjection(input: string): boolean {
  if (!input) return false;
  return INJECTION_PATTERNS.some(pattern => pattern.test(input));
}

export function sanitizeUserInput(input: string, maxLength = 400): string {
  if (!input) return '';
  return input
    .trim()
    .slice(0, maxLength)
    .replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F]/g, ''); // strip invisible control characters
}
