/**
 * Swappable Server-Side AI Provider Architecture
 * Supports Gemini, OpenAI, or any standard LLM provider
 * Secrets are ONLY loaded via Deno.env (server-side Edge Function secrets)
 */

export interface AIProviderConfig {
  providerName: 'gemini' | 'openai';
  apiKey: string;
  model?: string;
}

export interface AICompletionOptions {
  systemPrompt?: string;
  temperature?: number;
  maxTokens?: number;
  responseFormat?: 'text' | 'json';
}

export interface IAIProvider {
  name: string;
  generateText(prompt: string, options?: AICompletionOptions): Promise<string>;
  generateJson<T>(prompt: string, options?: AICompletionOptions): Promise<T>;
}

/**
 * Gemini Provider (Google AI)
 */
export class GeminiProvider implements IAIProvider {
  name = 'gemini';
  private apiKey: string;
  private model: string;

  constructor(apiKey: string, model = 'gemini-2.5-flash') {
    this.apiKey = apiKey;
    this.model = model;
  }

  async generateText(prompt: string, options: AICompletionOptions = {}): Promise<string> {
    // The API key goes in a header, not in the URL, so it never ends up in logs/error traces.
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${this.model}:generateContent`;

    const contents: any[] = [];
    if (prompt) {
      contents.push({
        role: 'user',
        parts: [{ text: prompt }]
      });
    }

    const bodyPayload: any = {
      contents,
      generationConfig: {
        temperature: options.temperature ?? 0.3,
        maxOutputTokens: options.maxTokens ?? 1000
      }
    };

    if (options.systemPrompt) {
      bodyPayload.systemInstruction = {
        parts: [{ text: options.systemPrompt }]
      };
    }

    if (options.responseFormat === 'json') {
      bodyPayload.generationConfig.responseMimeType = 'application/json';
    }

    // gemini-2.5-* "thinking" tokens are counted inside maxOutputTokens; with small limits
    // (e.g. 250 for the menu assistant) the reply came back empty or cut off.
    if (/gemini-2\.5/.test(this.model)) {
      bodyPayload.generationConfig.thinkingConfig = { thinkingBudget: 0 };
    }

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': this.apiKey
      },
      body: JSON.stringify(bodyPayload)
    });

    if (!res.ok) {
      const errBody = await res.text();
      console.error('Gemini API Error:', res.status, errBody);
      throw new Error(`AI Provider Error (${res.status})`);
    }

    const data = await res.json();
    const parts: Array<{ text?: string }> = data?.candidates?.[0]?.content?.parts || [];
    const text = parts.map(part => part?.text || '').join('');
    if (!text) {
      throw new Error('لم يتم استلام نص من مزود الذكاء الاصطناعي');
    }
    return text.trim();
  }

  async generateJson<T>(prompt: string, options: AICompletionOptions = {}): Promise<T> {
    const raw = await this.generateText(prompt, { ...options, responseFormat: 'json' });
    try {
      // Clean potential markdown wrap
      const cleanJson = raw.replace(/^```(json)?\s*/i, '').replace(/\s*```$/, '').trim();
      return JSON.parse(cleanJson) as T;
    } catch (err) {
      console.error('Failed to parse JSON from AI response:', raw);
      throw new Error('فشل معالجة استجابة الذكاء الاصطناعي كبيانات منظمة');
    }
  }
}

/**
 * OpenAI Provider
 */
export class OpenAIProvider implements IAIProvider {
  name = 'openai';
  private apiKey: string;
  private model: string;

  constructor(apiKey: string, model = 'gpt-4o-mini') {
    this.apiKey = apiKey;
    this.model = model;
  }

  async generateText(prompt: string, options: AICompletionOptions = {}): Promise<string> {
    const messages: any[] = [];
    if (options.systemPrompt) {
      messages.push({ role: 'system', content: options.systemPrompt });
    }
    messages.push({ role: 'user', content: prompt });

    const bodyPayload: any = {
      model: this.model,
      messages,
      temperature: options.temperature ?? 0.3,
      max_tokens: options.maxTokens ?? 1000
    };

    if (options.responseFormat === 'json') {
      bodyPayload.response_format = { type: 'json_object' };
    }

    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.apiKey}`
      },
      body: JSON.stringify(bodyPayload)
    });

    if (!res.ok) {
      const errBody = await res.text();
      console.error('OpenAI API Error:', res.status, errBody);
      throw new Error(`AI Provider Error (${res.status})`);
    }

    const data = await res.json();
    const content = data?.choices?.[0]?.message?.content;
    if (!content) throw new Error('استجابة فارغة من مزود الذكاء الاصطناعي');
    return content.trim();
  }

  async generateJson<T>(prompt: string, options: AICompletionOptions = {}): Promise<T> {
    const raw = await this.generateText(prompt, { ...options, responseFormat: 'json' });
    try {
      const cleanJson = raw.replace(/^```(json)?\s*/i, '').replace(/\s*```$/, '').trim();
      return JSON.parse(cleanJson) as T;
    } catch (err) {
      console.error('Failed to parse JSON from OpenAI response:', raw);
      throw new Error('فشل معالجة استجابة الذكاء الاصطناعي');
    }
  }
}

/**
 * Factory to get the configured AI Provider based on Edge Function Secrets
 */
export function getAIProvider(): IAIProvider {
  // Check Deno environment variables
  // (In Deno runtime: Deno.env.get)
  const envGetter = (key: string): string => {
    try {
      if (typeof Deno !== 'undefined' && Deno?.env?.get) {
        return Deno.env.get(key) || '';
      }
      if (typeof process !== 'undefined' && process?.env) {
        return (process.env as any)[key] || '';
      }
    } catch {
      // safe fallback
    }
    return '';
  };

  const configuredProvider = (envGetter('AI_PROVIDER') || 'gemini').toLowerCase();
  const geminiKey = envGetter('GEMINI_API_KEY');
  const openaiKey = envGetter('OPENAI_API_KEY');

  if (configuredProvider === 'openai' && openaiKey) {
    return new OpenAIProvider(openaiKey);
  }

  if (geminiKey) {
    return new GeminiProvider(geminiKey);
  }

  if (openaiKey) {
    return new OpenAIProvider(openaiKey);
  }

  throw new Error('لم يتم العثور على مفتاح مزود الذكاء الاصطناعي في إعدادات السيرفر (GEMINI_API_KEY أو OPENAI_API_KEY)');
}
