/**
 * Supabase Edge Function: ai-menu-manager
 * Handles authenticated AI tasks for restaurant owners:
 * - AI Product Description Generator
 * - AI Menu Translation
 * - Image Enhancement Architecture
 */
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.1';
import { corsHeaders, handleCors } from '../_shared/cors.ts';
import { getAIProvider } from '../_shared/ai-provider.ts';
import { detectPromptInjection, sanitizeUserInput } from '../_shared/security.ts';

Deno.serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';

    // 1. Verify User Authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'غير مصرح به. يرجى تسجيل الدخول أولاً.' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const token = authHeader.replace(/^Bearer\s+/i, '');
    const supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: `Bearer ${token}` } }
    });

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'انتهت صلاحية الجلسة، يرجى إعادة تسجيل الدخول.' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const body = await req.json();
    const { action, restaurantId } = body;

    if (!restaurantId) {
      return new Response(JSON.stringify({ error: 'معرف المطعم (restaurantId) مطلوب' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // 2. Server-Side Ownership and Role Verification
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);
    const { data: profile } = await adminClient
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .maybeSingle();

    const isSuperAdmin = profile?.role === 'super_admin';

    const { data: restaurant } = await adminClient
      .from('restaurants')
      .select('id, owner_id, name')
      .eq('id', restaurantId)
      .maybeSingle();

    if (!restaurant) {
      return new Response(JSON.stringify({ error: 'المطعم غير موجود' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (!isSuperAdmin && restaurant.owner_id !== user.id) {
      return new Response(JSON.stringify({ error: 'ليس لديك صلاحية لإجراء تعديلات ذكاء اصطناعي على هذا المطعم.' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const aiProvider = getAIProvider();

    // 3. ACTION: Generate Product Description
    if (action === 'generate_product_description') {
      const { productName, rawIngredients, language = 'ar', tone = 'appetizing' } = body;

      const cleanName = sanitizeUserInput(productName, 100);
      const cleanIngredients = sanitizeUserInput(rawIngredients, 250);

      if (!cleanName) {
        return new Response(JSON.stringify({ error: 'يرجى إدخال اسم الطبق أو المنتج الأساسي.' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      if (detectPromptInjection(cleanName) || detectPromptInjection(cleanIngredients)) {
        return new Response(JSON.stringify({ error: 'تم رفض النص لاحتوائه على مدخلات غير آمنة.' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const prompt = `
Generate a professional restaurant menu item entry in language "${language}".
Tone: "${tone}" (luxury, appetizing, professional).
Item Name hint: "${cleanName}"
Ingredients or notes hint: "${cleanIngredients || 'Standard authentic recipe'}"

You must return valid JSON with exactly this structure:
{
  "name": "Refined and attractive item name in ${language}",
  "short_description": "Crisp one-sentence teaser under 90 characters",
  "description": "Engaging, sensory culinary description between 150-250 characters highlighting taste and texture",
  "ingredients": ["ingredient 1", "ingredient 2", "ingredient 3"],
  "tags": ["tag1", "tag2"]
}
`;

      const aiResult = await aiProvider.generateJson<{
        name: string;
        short_description: string;
        description: string;
        ingredients: string[];
        tags: string[];
      }>(prompt, {
        systemPrompt: 'You are an award-winning executive chef and luxury menu copywriter. Respond strictly with valid JSON without markdown formatting.',
        temperature: 0.4
      });

      // Output Validation
      if (!aiResult.name || !aiResult.description) {
        throw new Error('استجابة غير مكتملة من الذكاء الاصطناعي');
      }

      // Record AI Usage
      await adminClient.from('ai_usage').insert({
        restaurant_id: restaurantId,
        user_id: user.id,
        feature: 'product_description',
        requests_count: 1,
        tokens_used: 350
      });

      return new Response(JSON.stringify({ success: true, data: aiResult }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // 4. ACTION: Translate Menu Items
    if (action === 'translate_menu') {
      const { items, sourceLang = 'ar', targetLang = 'en' } = body;

      if (!Array.isArray(items) || items.length === 0) {
        return new Response(JSON.stringify({ error: 'قائمة الأطباق المراد ترجمتها فارغة' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      // Cost & Safety Cap: Max 15 items per batch
      const boundedItems = items.slice(0, 15).map((it: any) => ({
        id: it.id,
        name: sanitizeUserInput(it.name, 100),
        description: sanitizeUserInput(it.description || '', 300),
        ingredients: Array.isArray(it.ingredients) ? it.ingredients.slice(0, 8).map((ing: string) => sanitizeUserInput(ing, 40)) : []
      }));

      const prompt = `
Translate the following restaurant menu items from "${sourceLang}" to "${targetLang}".
Maintain authentic culinary naming and appetizing descriptions.
Do NOT translate IDs.
Input items:
${JSON.stringify(boundedItems)}

Return valid JSON with an array of translated items:
{
  "translatedItems": [
    {
      "id": "original id",
      "name": "translated name",
      "description": "translated description",
      "ingredients": ["translated ingredient 1", "translated ingredient 2"]
    }
  ]
}
`;

      const result = await aiProvider.generateJson<{
        translatedItems: Array<{
          id: string;
          name: string;
          description: string;
          ingredients: string[];
        }>;
      }>(prompt, {
        systemPrompt: 'You are a professional culinary translator specializing in multilingual restaurant menus. Return valid JSON only.',
        temperature: 0.2
      });

      // Record AI Usage
      await adminClient.from('ai_usage').insert({
        restaurant_id: restaurantId,
        user_id: user.id,
        feature: 'menu_translation',
        requests_count: 1,
        tokens_used: boundedItems.length * 120
      });

      return new Response(JSON.stringify({ success: true, data: result.translatedItems || [] }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ error: 'Action not supported' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (err: any) {
    console.error('Edge Function Error:', err?.message || err);
    return new Response(JSON.stringify({
      error: 'خدمة الذكاء الاصطناعي غير متاحة حالياً. حاول مرة أخرى لاحقاً.'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
